# Copyright (c) 2026 Guruprasath Annadurai
# SPDX-License-Identifier: MIT
"""Enterprise webhook delivery system.

Features:
- HMAC-SHA256 payload signing (X-RAI-Signature-256 header)
- Exponential backoff retry (1 s / 5 s / 30 s / 2 min / 10 min)
- Concurrent fan-out via asyncio.gather
- Provider-specific payload formatting: Slack Block Kit, Teams Adaptive Card,
  PagerDuty Events API v2, generic JSON
- DB-persisted delivery log with retry recovery across server restarts
- In-memory fallback when no DB is configured (test / dev)
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import json
import logging
import socket
import time
from collections import deque
from typing import TYPE_CHECKING, Any
from urllib.parse import urlsplit

from responsibleai.net.egress import (
    DestinationPolicy,
    ForbiddenDestinationError,
    InvalidURLError,
    create_safe_async_client,
    is_address_allowed,
    validate_outbound_url,
)
from responsibleai.webhooks.models import (
    WebhookConfig,
    WebhookDelivery,
    WebhookEvent,
    WebhookProvider,
)

if TYPE_CHECKING:
    from responsibleai.db.webhook_repository import (
        WebhookConfigRepository,
        WebhookDeliveryRepository,
    )

logger = logging.getLogger(__name__)

_RETRY_DELAYS = [1.0, 5.0, 30.0, 120.0, 600.0]
_MAX_DELIVERY_LOG = 1_000
_RETRY_POLL_INTERVAL = 30.0


class UnsafeWebhookURLError(ValueError):
    """Raised when a webhook URL resolves to a non-public address (SSRF guard)."""


def validate_webhook_url(url: str) -> None:
    """Reject webhook URLs that target private/loopback/link-local networks,
    CGNAT, cloud-metadata endpoints, or any forbidden destination.
    Re-checked at every delivery (not just registration) since DNS can
    resolve differently between the two.
    """
    try:
        parsed = urlsplit(url)
    except Exception as exc:
        raise UnsafeWebhookURLError(f"malformed URL: {exc}") from exc

    if parsed.scheme not in ("http", "https"):
        raise UnsafeWebhookURLError(f"unsupported URL scheme: {parsed.scheme!r}")
    host = parsed.hostname
    if not host:
        raise UnsafeWebhookURLError("URL has no host")

    # Static URL / host / IP literal validation via egress boundary
    try:
        validate_outbound_url(url, DestinationPolicy.PUBLIC_ONLY)
    except (ForbiddenDestinationError, InvalidURLError) as exc:
        raise UnsafeWebhookURLError(
            f"webhook host {host!r} resolves to a non-public address ({exc})"
        ) from exc

    # Resolution-time check via socket.getaddrinfo
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror as exc:
        raise UnsafeWebhookURLError(f"could not resolve host: {host}") from exc

    for info in infos:
        addr = str(info[4][0])
        if not is_address_allowed(addr, DestinationPolicy.PUBLIC_ONLY):
            raise UnsafeWebhookURLError(
                f"webhook host {host!r} resolves to a non-public address ({addr})"
            )


class WebhookManager:
    """Register endpoints and fire events with HMAC signing and persistent retry logic."""

    def __init__(self) -> None:
        self._configs: dict[str, WebhookConfig] = {}
        self._delivery_log: deque[WebhookDelivery] = deque(maxlen=_MAX_DELIVERY_LOG)
        self._repo: WebhookDeliveryRepository | None = None
        self._config_repo: WebhookConfigRepository | None = None
        self._retry_task: asyncio.Task[None] | None = None
        self._stop_event: asyncio.Event = asyncio.Event()

    def set_repository(self, repo: WebhookDeliveryRepository) -> None:
        """Wire up the DB repository for persistent delivery log and retry queue."""
        self._repo = repo

    def set_config_repository(self, repo: WebhookConfigRepository) -> None:
        """Wire up the DB repository for persistent webhook registrations."""
        self._config_repo = repo

    async def load_configs(self) -> int:
        """Repopulate the in-memory registry from the DB. Call once at
        startup, after set_config_repository(). Returns the count loaded."""
        if self._config_repo is None:
            return 0
        configs = await self._config_repo.list_all()
        for cfg in configs:
            self._configs[cfg.id] = cfg
        return len(configs)

    def start_retry_worker(self) -> None:
        """Launch background retry worker (call after lifespan startup + repo attached)."""
        if self._repo is not None and self._retry_task is None:
            self._stop_event.clear()
            self._retry_task = asyncio.create_task(self._retry_worker())

    def stop_retry_worker(self) -> None:
        """Signal the background worker to stop."""
        self._stop_event.set()
        if self._retry_task is not None:
            self._retry_task.cancel()
            self._retry_task = None

    # ── Registration ──────────────────────────────────────────────────────────

    def register(self, config: WebhookConfig) -> WebhookConfig:
        """In-memory only. Use register_and_persist() from request handlers
        so a registered webhook survives a restart."""
        self._configs[config.id] = config
        return config

    def remove(self, webhook_id: str) -> bool:
        """In-memory only. Use remove_and_persist() from request handlers."""
        return self._configs.pop(webhook_id, None) is not None

    async def register_and_persist(self, config: WebhookConfig) -> WebhookConfig:
        self.register(config)
        if self._config_repo is not None:
            await self._config_repo.create(config)
        return config

    async def remove_and_persist(self, webhook_id: str, org_id: str | None = None) -> bool:
        """Remove a webhook. If org_id is given, only removes a config owned
        by that org (returns False otherwise) — enforces tenant isolation."""
        cfg = self._configs.get(webhook_id)
        if cfg is None:
            return False
        if org_id is not None and cfg.org_id != org_id:
            return False
        removed_locally = self.remove(webhook_id)
        if self._config_repo is not None:
            await self._config_repo.delete(webhook_id, org_id=org_id)
        return removed_locally

    def get(self, webhook_id: str) -> WebhookConfig | None:
        return self._configs.get(webhook_id)

    def list_webhooks(self, org_id: str | None = None) -> list[WebhookConfig]:
        """List registered webhooks. Pass org_id to scope to one tenant —
        omit only for legacy/super-admin cross-org visibility."""
        if org_id is None:
            return list(self._configs.values())
        return [c for c in self._configs.values() if c.org_id == org_id]

    def update(self, webhook_id: str, **kwargs: Any) -> WebhookConfig | None:
        cfg = self._configs.get(webhook_id)
        if cfg is None:
            return None
        for k, v in kwargs.items():
            if hasattr(cfg, k):
                setattr(cfg, k, v)
        return cfg

    # ── Delivery ──────────────────────────────────────────────────────────────

    async def fire(
        self,
        event: WebhookEvent,
        data: dict[str, Any],
        *,
        org_id: str | None = None,
    ) -> list[WebhookDelivery]:
        """Deliver a tenant event only to matching webhooks owned by that tenant.

        ``None`` is an explicit legacy/local tenant, not a wildcard. Production
        callers must pass the authenticated or persisted event owner so one
        tenant's payload can never be fanned out to another tenant (Checkpoint
        6). Also requires the durable lifecycle store to have admitted restore
        readiness before any delivery is attempted (Phase 5) -- merged from two
        independently-developed, non-overlapping fixes to this same method;
        neither is dropped in favor of the other.
        """
        from responsibleai.data_governance.backup_defense import assert_restore_readiness_admitted

        assert_restore_readiness_admitted()

        targets = [
            config
            for config in self._configs.values()
            if config.enabled and config.org_id == org_id and event in config.events
        ]
        if not targets:
            return []

        results = await asyncio.gather(
            *[self._deliver(cfg, event, data) for cfg in targets],
            return_exceptions=True,
        )
        deliveries: list[WebhookDelivery] = []
        for r in results:
            if isinstance(r, WebhookDelivery):
                self._delivery_log.append(r)
                deliveries.append(r)
        return deliveries

    async def _deliver(
        self,
        config: WebhookConfig,
        event: WebhookEvent,
        data: dict[str, Any],
        delivery_id: str | None = None,
        start_attempt: int = 0,
    ) -> WebhookDelivery:
        payload = self._format_payload(config.provider, event, data)
        delivery = WebhookDelivery(
            webhook_id=config.id,
            event=event,
            payload=payload,
            org_id=config.org_id,
        )
        if delivery_id:
            delivery.id = delivery_id

        if self._repo:
            try:
                await self._repo.create(
                    delivery_id=delivery.id,
                    webhook_id=config.id,
                    event=event.value,
                    payload=payload,
                    max_retries=config.max_retries,
                )
            except Exception:
                pass  # degraded — continue without persistence

        delays = [0.0] + _RETRY_DELAYS[: config.max_retries - 1]
        for i, delay in enumerate(delays):
            if i < start_attempt:
                continue
            if delay:
                await asyncio.sleep(delay)
            delivery.attempts += 1
            status_code: int | None = None
            error: str | None = None
            success = False
            try:
                validate_webhook_url(config.url)
                body = json.dumps(payload).encode()
                headers: dict[str, str] = {"Content-Type": "application/json"}
                if config.secret:
                    sig = hmac.new(config.secret.encode(), body, hashlib.sha256).hexdigest()
                    headers["X-RAI-Signature-256"] = f"sha256={sig}"

                # create_safe_async_client enforces destination policy at actual
                # TCP-connect time (TOCTOU defence): it re-resolves the hostname
                # inside SafeNetworkBackend.connect_tcp and verifies every
                # resolved IP before connecting — eliminating the window between
                # validate_webhook_url (static/DNS pre-check) and the real socket.
                async with create_safe_async_client(timeout=10.0) as http:
                    resp = await http.post(config.url, content=body, headers=headers)
                status_code = resp.status_code
                if resp.is_success:
                    delivery.status_code = status_code
                    delivery.success = True
                    success = True
                else:
                    error = f"HTTP {resp.status_code}"
                    delivery.last_error = error
            except Exception as exc:
                error = str(exc)
                delivery.last_error = error
                logger.warning(
                    "webhook_delivery_failed webhook_id=%s event=%s attempt=%d error=%s",
                    config.id,
                    event.value,
                    delivery.attempts,
                    exc,
                )

            if self._repo:
                try:
                    await self._repo.record_attempt(
                        delivery.id, delivery.attempts, status_code, error, success
                    )
                except Exception:
                    pass

            if success:
                return delivery

        return delivery

    async def _retry_worker(self) -> None:
        """Background task: pick up pending DB retries and re-deliver them."""
        while not self._stop_event.is_set():
            try:
                await asyncio.sleep(_RETRY_POLL_INTERVAL)
                if self._repo is None:
                    continue
                pending = await self._repo.pending_retries()
                for row in pending:
                    cfg = self._configs.get(row["webhook_id"])
                    if cfg is None:
                        continue
                    try:
                        event = WebhookEvent(row["event"])
                    except ValueError:
                        continue
                    asyncio.create_task(
                        self._deliver(
                            cfg,
                            event,
                            row["payload"],
                            delivery_id=row["id"],
                            start_attempt=row["attempts"],
                        )
                    )
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.warning("webhook_retry_worker_error: %s", exc)

    # ── Delivery log ──────────────────────────────────────────────────────────

    def delivery_log(self, limit: int = 100, org_id: str | None = None) -> list[dict[str, Any]]:
        if org_id is not None:
            entries = [d for d in self._delivery_log if d.org_id == org_id][-limit:]
        else:
            entries = list(self._delivery_log)[-limit:]
        return [d.to_dict() for d in reversed(entries)]

    def total_deliveries_for(self, org_id: str | None = None) -> int:
        if org_id is None:
            return len(self._delivery_log)
        return sum(1 for d in self._delivery_log if d.org_id == org_id)

    def failed_deliveries_for(self, org_id: str | None = None) -> int:
        if org_id is None:
            return sum(1 for d in self._delivery_log if not d.success)
        return sum(1 for d in self._delivery_log if d.org_id == org_id and not d.success)

    @property
    def total_deliveries(self) -> int:
        return self.total_deliveries_for(None)

    @property
    def failed_deliveries(self) -> int:
        return self.failed_deliveries_for(None)

    # ── Payload formatters ────────────────────────────────────────────────────

    def _format_payload(
        self,
        provider: WebhookProvider,
        event: WebhookEvent,
        data: dict[str, Any],
    ) -> dict[str, Any]:
        if provider == WebhookProvider.SLACK:
            return self._slack_payload(event, data)
        if provider == WebhookProvider.TEAMS:
            return self._teams_payload(event, data)
        if provider == WebhookProvider.PAGERDUTY:
            return self._pagerduty_payload(event, data)
        return {
            "event": event.value,
            "timestamp": int(time.time()),
            "source": "responsibleai",
            "data": data,
        }

    def _slack_payload(self, event: WebhookEvent, data: dict[str, Any]) -> dict[str, Any]:
        _emoji = {
            WebhookEvent.DRIFT_ALERT: ":warning:",
            WebhookEvent.BUDGET_EXCEEDED: ":money_with_wings:",
            WebhookEvent.GUARDRAIL_TRIGGERED: ":shield:",
            WebhookEvent.TRUST_SCORE_CHANGED: ":bar_chart:",
        }
        emoji = _emoji.get(event, ":bell:")
        title = event.value.replace("_", " ").title()
        fields = [{"type": "mrkdwn", "text": f"*{k}*\n{v}"} for k, v in list(data.items())[:6]]
        return {
            "blocks": [
                {
                    "type": "header",
                    "text": {
                        "type": "plain_text",
                        "text": f"{emoji}  ResponsibleAI — {title}",
                    },
                },
                {"type": "section", "fields": fields} if fields else {"type": "divider"},
                {
                    "type": "context",
                    "elements": [
                        {
                            "type": "mrkdwn",
                            "text": f"<!date^{int(time.time())}^{{date_short_pretty}} at {{time}}|{time.strftime('%Y-%m-%d %H:%M UTC')}>",
                        }
                    ],
                },
            ]
        }

    def _teams_payload(self, event: WebhookEvent, data: dict[str, Any]) -> dict[str, Any]:
        color = "FF6B6B" if "alert" in event.value or "exceeded" in event.value else "4CAF50"
        return {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": color,
            "summary": f"ResponsibleAI: {event.value}",
            "sections": [
                {
                    "activityTitle": f"**{event.value.replace('_', ' ').title()}**",
                    "activitySubtitle": "ResponsibleAI Governance Platform",
                    "facts": [{"name": k, "value": str(v)} for k, v in data.items()],
                    "markdown": True,
                }
            ],
        }

    def _pagerduty_payload(self, event: WebhookEvent, data: dict[str, Any]) -> dict[str, Any]:
        severity = (
            "critical"
            if event in (WebhookEvent.BUDGET_EXCEEDED, WebhookEvent.GUARDRAIL_TRIGGERED)
            else "warning"
        )
        return {
            "routing_key": data.get("routing_key", ""),
            "event_action": "trigger",
            "dedup_key": f"rai-{event.value}-{int(time.time() // 60)}",
            "payload": {
                "summary": f"ResponsibleAI: {event.value.replace('_', ' ').title()}",
                "severity": severity,
                "source": "responsibleai",
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "custom_details": {k: v for k, v in data.items() if k != "routing_key"},
            },
        }
