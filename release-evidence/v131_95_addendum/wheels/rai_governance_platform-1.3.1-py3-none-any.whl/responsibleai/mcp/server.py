# Copyright (c) 2026 Guruprasath Annadurai
# SPDX-License-Identifier: MIT
"""
WhitePact MCP Server (governance tools for Claude Code and MCP-compatible
AI assistants) — the governance engine behind WhitePact's runtime
authority layer. See MIGRATION_WHITEPACT_V2.md Section 6: the server's
protocol-level identity is `whitepact`; the console script names
(`responsibleai-mcp`/`responsibleai-mcp-http`) launching this exact
process are unchanged, kept for backward compatibility. MCP clients
treat the server name as an opaque display string, not a dependency, so
this rename carries no compatibility break.

Three transports:

1. **stdio** (default, free, self-hosted) — full unrestricted tool access.
   Configure Claude Code:
       {
         "mcpServers": {
           "whitepact": { "command": "responsibleai-mcp" }
         }
       }

2. **Streamable HTTP** (hosted, billed) — the modern MCP HTTP transport
   (spec 2025-03-26+): a single `/mcp` endpoint, Bearer-token authenticated,
   tools gated by the calling org's billing Plan (FREE/PRO/ENTERPRISE — see
   mcp/licensing.py). This is the **preferred** hosted transport — point new
   clients here. Run with: `responsibleai-mcp-http` (reads RAI_MCP_HTTP_*
   env vars).

   The Bearer credential is a static API key (`rai_...`, issued via
   `OrgRepository.create_key`), a short-lived opaque OAuth access token
   (`wp_at_...`) from WhitePact's optional MCP authorization server, or an
   OIDC-issued JWT when enterprise SSO is configured. OAuth discovery uses
   RFC 9728 protected-resource metadata, authorization code + PKCE S256,
   dynamic client registration for exact ChatGPT callbacks, and rotating
   refresh tokens. API keys remain available for server-to-server use.

3. **HTTP+SSE** (hosted, billed, legacy) — the original MCP HTTP transport
   (spec 2024-11-05): separate `/sse` + `/messages/` endpoints. Same auth and
   plan-gating as Streamable HTTP. Kept running, unmodified, for existing
   clients built against it — see MIGRATION_WHITEPACT_V2.md Section 7 for
   the deprecation posture (no removal date; migrate at your own pace).

Both hosted transports are served by the same `main_http()` process on the
same port; a client picks its transport by which path it connects to.

Environment variables (all optional):
    RAI_MCP_LOG_LEVEL                     Logging level: DEBUG | INFO | WARNING (default: WARNING)
    RAI_MCP_HTTP_HOST                     HTTP transport bind host (default: 0.0.0.0)
    RAI_MCP_HTTP_PORT                     HTTP transport bind port (default: 8766)
    RAI_MCP_HTTP_ALLOWED_HOSTS            Comma-separated Host header allowlist for DNS
                                           rebinding protection (e.g. "mcp.example.com,
                                           mcp.example.com:*"). Empty by default — see
                                           MIGRATION_WHITEPACT_V2.md Section on transport
                                           security for why that's the safe default.
    RAI_MCP_HTTP_ALLOWED_ORIGINS          Comma-separated Origin header allowlist, same
                                           DNS rebinding protection mechanism.
    RAI_MCP_HTTP_DNS_REBINDING_PROTECTION Force-enable/disable DNS rebinding protection
                                           (true/false). Defaults to enabled automatically
                                           once either allowlist above is non-empty.
    RAI_MCP_HTTP_AUTH_MAX_FAILURES        Failed Bearer-auth attempts allowed per client
                                           IP within the window below before 429s (default: 10).
    RAI_MCP_HTTP_AUTH_WINDOW_SECONDS      Sliding window for the above, in seconds (default: 60).
    RAI_MCP_OAUTH_ISSUER                  Public HTTPS authorization-server issuer; empty disables it.
    RAI_MCP_OAUTH_RESOURCE_URI            Exact public HTTPS /mcp resource identifier.
    RAI_MCP_OAUTH_SCOPES                  Comma-separated scopes (default: whitepact:review,offline_access).
"""

from __future__ import annotations

import asyncio
import html
import json
import logging
import os
import sys
from contextvars import ContextVar
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

import mcp.types as types
from mcp.server import Server
from mcp.server.stdio import stdio_server

from responsibleai import __version__
from responsibleai.mcp.licensing import (
    is_allowed,
    monthly_quota,
    quota_exceeded_message,
    upgrade_message,
)
from responsibleai.mcp.resources import RESOURCE_DEFS, dispatch_resource
from responsibleai.mcp.tools import (
    PRODUCTION_TOOL_DEFS,
    WHITEPACT_PURPOSE_ARGUMENT,
    dispatch_tool,
)
from responsibleai.rbac.models import OrgContext

if TYPE_CHECKING:
    from responsibleai.db.mcp_usage_repository import McpUsageRepository
    from responsibleai.mcp.governance_integration import GovernanceServices
    from responsibleai.webhooks.manager import WebhookManager

_log_level = os.environ.get("RAI_MCP_LOG_LEVEL", "WARNING").upper()
logging.basicConfig(level=getattr(logging, _log_level, logging.WARNING))
_logger = logging.getLogger("responsibleai.mcp")

server: Server = Server("whitepact")

# Legacy console-script name -> its preferred replacement, per
# pyproject.toml's [project.scripts] (Migration Section 4). Both sides
# of each pair launch the identical entry-point function.
_LEGACY_TO_PREFERRED_NAME = {
    "responsibleai-mcp": "whitepact-mcp",
    "responsibleai-mcp-http": "whitepact-mcp-http",
}


def _invoked_as() -> str:
    """The console-script name this process was actually launched under
    (e.g. "whitepact-mcp" or the legacy "responsibleai-mcp") — read from
    argv[0], not hardcoded, so it reflects reality regardless of which
    of the aliases in pyproject.toml's [project.scripts] launched it."""
    return os.path.basename(sys.argv[0]) if sys.argv else "unknown"


def _log_invocation_name(process_kind: str) -> None:
    """MIGRATION_WHITEPACT_V2.md Section 4: log which entry-point name
    launched this process, for observability during the transition —
    stderr/structured logging only, never stdout, since stdout is the
    stdio MCP transport itself and writing to it would corrupt the
    protocol on every `main()` (stdio) invocation."""
    invoked_as = _invoked_as()
    preferred = _LEGACY_TO_PREFERRED_NAME.get(invoked_as)
    if preferred is not None:
        _logger.info(
            "%s started via the legacy '%s' command — the preferred name is "
            "'%s'. Both keep working; see MIGRATION_WHITEPACT_V2.md.",
            process_kind,
            invoked_as,
            preferred,
        )
    else:
        _logger.info("%s started via '%s'.", process_kind, invoked_as)


# Set by the HTTP transport's auth middleware per-connection. None on stdio
# (self-hosted). Only local stdio may use unrestricted community dispatch;
# absent identity on a hosted request must instead fail closed.
_current_org: ContextVar[OrgContext | None] = ContextVar("_current_org", default=None)
# Transport identity is independent of authentication: losing an org context
# on an HTTP request must never turn it into unrestricted community stdio.
_current_hosted: ContextVar[bool] = ContextVar("_current_hosted", default=False)
_current_usage_repo: ContextVar[McpUsageRepository | None] = ContextVar(
    "_current_usage_repo", default=None
)
# None unless Settings.mcp_governance_enabled is True — see that field's
# docstring and governance_integration.py. Disabled service initialization
# no longer permits direct hosted dispatch.
_current_governance: ContextVar[GovernanceServices | None] = ContextVar(
    "_current_governance", default=None
)


def _month_start_iso() -> str:
    now = datetime.now(UTC)
    return now.replace(day=1, hour=0, minute=0, second=0, microsecond=0).isoformat()


@server.list_tools()
async def _list_tools() -> list[types.Tool]:
    from responsibleai.mcp.tools import advertised_tool_defs

    tools = advertised_tool_defs(hosted=_current_hosted.get())
    ctx = _current_org.get()
    if ctx is not None and ctx.key_id.startswith("oauth:"):
        return [_with_oauth_security(tool) for tool in tools]
    return tools


def _with_oauth_security(tool: types.Tool) -> types.Tool:
    """Add current and compatibility OAuth declarations to one tool descriptor."""
    security_schemes = [{"type": "oauth2", "scopes": ["whitepact:review"]}]
    metadata = dict(tool.meta or {})
    metadata["securitySchemes"] = security_schemes
    return tool.model_copy(update={"securitySchemes": security_schemes, "meta": metadata})


def _text_and_structured(
    payload: dict[str, Any],
) -> tuple[list[types.TextContent], dict[str, Any]]:
    """Every tool/error payload here is a JSON-native `dict[str, Any]`
    (verified: `dispatch_tool` is typed `-> dict[str, Any]`, and every
    inline error dict below is built from string/bool/None literals) —
    safe to hand to the SDK's `structuredContent` as-is. Still returning
    the serialized `TextContent` alongside it (not replacing it) per
    MIGRATION_WHITEPACT_V2.md's structured-output section: pre-2025-06-18
    clients that only read `content` keep working unchanged.
    """
    text = types.TextContent(type="text", text=json.dumps(payload, indent=2, default=str))
    return [text], payload


@server.call_tool()
async def _call_tool(
    name: str,
    arguments: dict[str, Any] | None,
) -> tuple[list[types.TextContent], dict[str, Any]]:
    _logger.debug(
        "tool_call name=%s arg_keys=%s",
        name,
        sorted((arguments or {}).keys()),
    )

    from responsibleai.data_governance.backup_defense import (
        RestoreReadinessState,
        get_restore_readiness_gate,
    )

    gate = get_restore_readiness_gate()
    if gate.state != RestoreReadinessState.READY:
        error = {
            "error": "restore_quarantine",
            "message": f"MCP tool execution blocked: system is in {gate.state.value} state pending restore reconciliation.",
            "status": gate.state.value,
        }
        return _text_and_structured(error)

    ctx = _current_org.get()
    usage_repo = _current_usage_repo.get()

    if ctx is not None:
        if not is_allowed(name, ctx.plan):
            if usage_repo is not None and ctx.org_id:
                await usage_repo.record_call(ctx.org_id, name, ctx.plan.value, allowed=False)
            error = {"error": "upgrade_required", "message": upgrade_message(name, ctx.plan)}
            return _text_and_structured(error)

        quota = monthly_quota(ctx.plan)
        if quota == 0:
            if usage_repo is not None and ctx.org_id:
                await usage_repo.record_call(ctx.org_id, name, ctx.plan.value, allowed=False)
            error = {
                "error": "hosted_access_unavailable",
                "message": (
                    f"The {ctx.plan.value} plan does not include hosted MCP access. "
                    "Use the free self-hosted stdio transport, or upgrade at "
                    "https://responsibleai.dev/pricing."
                ),
            }
            return _text_and_structured(error)

        if quota is not None and usage_repo is not None and ctx.org_id:
            used = await usage_repo.count_since(ctx.org_id, _month_start_iso())
            if used >= quota:
                await usage_repo.record_call(ctx.org_id, name, ctx.plan.value, allowed=False)
                error = {
                    "error": "quota_exceeded",
                    "message": quota_exceeded_message(ctx.plan, used, quota),
                }
                return _text_and_structured(error)

    call_arguments = arguments or {}
    governance = _current_governance.get()
    if (_current_hosted.get() or ctx is not None) and (
        governance is None or ctx is None or not ctx.org_id or ctx.is_legacy
    ):
        if usage_repo is not None and ctx is not None and ctx.org_id:
            await usage_repo.record_call(ctx.org_id, name, ctx.plan.value, allowed=False)
        return _text_and_structured(
            {
                "error": "governance_unavailable",
                "message": "Hosted tool execution requires tenant-scoped governance. No action was taken.",
            }
        )
    if usage_repo is not None and ctx is not None and ctx.org_id:
        await usage_repo.record_call(ctx.org_id, name, ctx.plan.value, allowed=True)
    if governance is not None and ctx is not None and ctx.org_id:
        # Local import: keeps the stdio transport's import graph free of
        # the DB/governance layer unless a hosted-HTTP connection with
        # mcp_governance_enabled=True actually populated this ContextVar
        # — see governance_integration.py's module docstring.
        from responsibleai.mcp.governance_integration import apply_governance

        purpose = call_arguments.get(WHITEPACT_PURPOSE_ARGUMENT)
        if not isinstance(purpose, str) or not purpose.strip():
            return _text_and_structured(
                {
                    "error": "governance_purpose_required",
                    "message": (
                        "Hosted WhitePact tool execution requires a human-readable "
                        "purpose string in the tool arguments under "
                        "'_whitepact_purpose' (for example: "
                        '"Approve vendor invoice batch for Q1 close"). '
                        "Session IDs, MCP connection metadata, or generic "
                        "placeholders are not valid purposes — the value is "
                        "recorded in the governance evidence chain as declared intent."
                    ),
                    "field": "_whitepact_purpose",
                    "documentation": "https://github.com/Guruprasath-Annadurai/Whitepact/blob/main/docs/MCP_HOSTED_PURPOSE.md",
                }
            )
        governed_arguments = dict(call_arguments)
        del governed_arguments[WHITEPACT_PURPOSE_ARGUMENT]
        outcome = await apply_governance(
            name, governed_arguments, ctx, governance, purpose=purpose.strip()
        )
        if not outcome.proceed:
            return _text_and_structured(outcome.blocked_response or {"error": "governance_blocked"})
        # apply_governance() already ran the tool via InternalToolExecutor
        # once it had a valid ExecutionAuthorization — outcome.result is
        # that result. Calling dispatch_tool() again here would both
        # double-execute the tool and reintroduce the exact bypass this
        # wiring exists to close.
        assert outcome.result is not None, "governed ALLOW outcome must carry an execution result"
        if outcome.outcome_status is not None and outcome.outcome_status.value == "UNKNOWN":
            outcome.result["_whitepact_evidence_outcome"] = "UNKNOWN"
            outcome.result["_whitepact_reconciliation_required"] = True
        return _text_and_structured(outcome.result)

    from responsibleai.mcp.tools import set_mcp_dispatch_hosted

    set_mcp_dispatch_hosted(_current_hosted.get())
    result = await dispatch_tool(name, call_arguments)
    return _text_and_structured(result)


@server.list_resources()
async def _list_resources() -> list[types.Resource]:
    return RESOURCE_DEFS


@server.read_resource()
async def _read_resource(uri: types.AnyUrl) -> str:
    _logger.debug("resource_read uri=%s", uri)
    return await dispatch_resource(str(uri))


# ── stdio transport (self-hosted, free, unrestricted) ──────────────────────────


async def _run_stdio() -> None:
    async with stdio_server() as (read_stream, write_stream):
        init_options = server.create_initialization_options()
        await server.run(read_stream, write_stream, init_options)


def main() -> None:
    """CLI entry point: whitepact-mcp / responsibleai-mcp (stdio, self-hosted)."""
    _logger.info("starting %s v1.2.0 (stdio)", server.name)
    _log_invocation_name("stdio server")
    asyncio.run(_run_stdio())


# ── HTTP/SSE transport (hosted, billed, plan-gated) ─────────────────────────────


def _split_csv(raw: str) -> list[str]:
    return [item.strip() for item in raw.split(",") if item.strip()]


def _env_bool(name: str, *, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


class HostedProductionSecurityError(RuntimeError):
    """Raised when a production hosted-MCP process would boot unsafely."""


def hosted_production_preflight(
    settings: Any,
    *,
    allowed_hosts: list[str] | None = None,
) -> None:
    """Fail closed before serving if production hosted MCP is misconfigured.

    Non-production environments are unchanged: developers may run without an
    allowlist, and hosted calls still refuse ungated dispatch_tool().
    """
    if not getattr(settings, "is_production", False):
        return
    if settings.mcp_http_allow_unauthenticated_demo:
        raise HostedProductionSecurityError(
            "mcp_http_allow_unauthenticated_demo is forbidden in production."
        )
    if getattr(settings, "phase7a_dispatcher_enabled", False):
        raise HostedProductionSecurityError(
            "Production Gate B is CLOSED. PHASE7A_DISPATCHER_ENABLED is forbidden in production."
        )
    if not settings.mcp_governance_enabled:
        raise HostedProductionSecurityError(
            "Production hosted MCP requires mcp_governance_enabled=true. "
            "Hosted execution must not start without tenant-scoped governance."
        )
    hosts = (
        allowed_hosts
        if allowed_hosts is not None
        else _split_csv(os.environ.get("RAI_MCP_HTTP_ALLOWED_HOSTS", ""))
    )
    if not hosts:
        raise HostedProductionSecurityError(
            "Production hosted MCP requires RAI_MCP_HTTP_ALLOWED_HOSTS so "
            "DNS-rebinding protection is active. Refusing to start with an "
            "empty Host allowlist."
        )
    if getattr(settings, "multi_replica", False):
        raise HostedProductionSecurityError(
            "V1 production hosted MCP is constrained to one authenticated "
            "application replica. _AuthFailureLimiter is per-process; extra "
            "replicas multiply the failure budget. Keep RAI_MULTI_REPLICA/"
            "WHITEPACT_MULTI_REPLICA unset until a shared limiter exists."
        )
    from types import SimpleNamespace

    from responsibleai.enterprise.preflight import (
        HostedEnterpriseSecurityError,
        assert_hosted_enterprise_boot_safe,
    )

    boot = SimpleNamespace(
        environment=getattr(settings, "environment", None) or "production",
        api_keys=list(getattr(settings, "api_keys", []) or []),
        is_production=True,
    )
    try:
        assert_hosted_enterprise_boot_safe(boot)
    except HostedEnterpriseSecurityError as exc:
        raise HostedProductionSecurityError(str(exc)) from exc


def _build_transport_security() -> Any:
    """DNS rebinding protection for both hosted transports (spec: MCP servers
    must validate Host/Origin headers to prevent a malicious webpage from
    reaching a server bound to localhost/an internal address via the
    victim's browser). Disabled by default — matching the underlying SDK's
    own backward-compatible default — unless the deployer actually
    configures an allowlist, since enabling it with empty allowlists would
    reject every request. See MIGRATION_WHITEPACT_V2.md's transport
    security section.
    """
    from mcp.server.transport_security import TransportSecuritySettings

    allowed_hosts = _split_csv(os.environ.get("RAI_MCP_HTTP_ALLOWED_HOSTS", ""))
    allowed_origins = _split_csv(os.environ.get("RAI_MCP_HTTP_ALLOWED_ORIGINS", ""))
    enabled = _env_bool(
        "RAI_MCP_HTTP_DNS_REBINDING_PROTECTION",
        default=bool(allowed_hosts or allowed_origins),
    )
    return TransportSecuritySettings(
        enable_dns_rebinding_protection=enabled,
        allowed_hosts=allowed_hosts,
        allowed_origins=allowed_origins,
    )


class _AuthFailureLimiter:
    """Per-process sliding-window limiter on failed Bearer-auth attempts.

    V1 production constraint: one authenticated MCP application replica.
    This limiter is not cluster-wide. Extra replicas multiply the budget.

    Dual-budget partitioning:
    - Credential-specific budget: Keyed by non-secret SHA-256 fingerprint of the supplied credential (`cred:<token_fp>`).
      Prevents an attacker using a bad token from exhausting the failure budget of other clients on the same proxy/IP.
    - Anonymous / IP budget: Keyed by peer host (`anon:<ip>`) for requests with no Authorization header.
    - Peer aggregate budget: An IP-level safety ceiling across multiple distinct failing credentials to prevent distributed brute-force.
    """

    def __init__(
        self,
        max_failures: int,
        window_seconds: float,
        peer_max_failures: int = 50,
    ) -> None:
        self._max_failures = max_failures
        self._window_seconds = window_seconds
        self._peer_max_failures = peer_max_failures
        self._failures: dict[str, list[float]] = {}
        self._lock = asyncio.Lock()

    def _prune(self, key: str, now: float) -> list[float]:
        attempts = [t for t in self._failures.get(key, []) if now - t < self._window_seconds]
        self._failures[key] = attempts
        return attempts

    async def is_blocked(self, key: str, peer_key: str | None = None) -> bool:
        async with self._lock:
            now = asyncio.get_running_loop().time()
            if len(self._prune(key, now)) >= self._max_failures:
                return True
            if (
                peer_key
                and len(self._prune(f"peer_agg:{peer_key}", now)) >= self._peer_max_failures
            ):
                return True
            return False

    async def record_failure(self, key: str, peer_key: str | None = None) -> None:
        async with self._lock:
            now = asyncio.get_running_loop().time()
            self._prune(key, now).append(now)
            if peer_key:
                self._prune(f"peer_agg:{peer_key}", now).append(now)


def _build_http_app() -> Any:
    """Construct the ASGI app for hosted MCP. Imports are local — this path
    pulls in Starlette + the DB layer, which self-hosted stdio users never need.

    Production startups fail closed via hosted_production_preflight().
    Serves both hosted transports on one app — see the module docstring:
    `/mcp` (Streamable HTTP, preferred) and `/sse` + `/messages/` (legacy
    HTTP+SSE, unmodified). Both share the same auth (`_authenticate`) and
    the same plan-gating contextvars consumed by `_call_tool`.
    """
    from contextlib import asynccontextmanager

    from mcp.server.sse import SseServerTransport
    from mcp.server.streamable_http_manager import StreamableHTTPSessionManager
    from starlette.applications import Starlette
    from starlette.requests import Request
    from starlette.responses import HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse
    from starlette.routing import Mount, Route
    from starlette.types import Receive, Scope, Send

    from responsibleai.auth.mcp_oauth import McpOAuthAuthorizationServer, OAuthProtocolError
    from responsibleai.auth.oidc import OIDCProvider
    from responsibleai.auth.verifiable_credential import (
        VerifiableCredentialProvider,
        looks_like_vc_jwt,
    )
    from responsibleai.dashboard.config import get_settings
    from responsibleai.db import (
        McpUsageRepository,
        OrgRepository,
        PrincipalRepository,
        create_engine,
    )
    from responsibleai.governance.principal import build_principal_claim
    from responsibleai.rbac.models import Plan, Role
    from responsibleai.rbac.permissions import role_from_str

    settings = get_settings()
    hosted_production_preflight(settings)
    _db_engine = create_engine(settings.effective_db_url)
    from responsibleai.governance.synthetic_counter import bind_counter_engine

    bind_counter_engine(_db_engine)
    _org_repo = OrgRepository(_db_engine)
    _usage_repo = McpUsageRepository(_db_engine)
    _mcp_oauth_server = (
        McpOAuthAuthorizationServer(
            _db_engine,
            _org_repo,
            issuer=settings.mcp_oauth_issuer,
            resource=settings.mcp_oauth_resource_uri,
            scopes=settings.mcp_oauth_scopes,
            access_token_ttl_seconds=settings.mcp_oauth_access_token_ttl_seconds,
            refresh_token_ttl_seconds=settings.mcp_oauth_refresh_token_ttl_seconds,
        )
        if settings.mcp_oauth_issuer
        else None
    )

    _governance_services: GovernanceServices | None = None
    _governance_webhook_manager: WebhookManager | None = None
    if settings.mcp_governance_enabled:
        from responsibleai.db import (
            ApprovalRepository,
            DelegationRepository,
            EvidenceRepository,
            IntentContractRepository,
            OrgAuthorityCeilingRepository,
            OrgAutonomyBudgetRepository,
            OutcomeRepository,
            PolicyRepository,
            WebhookConfigRepository,
            WebhookDeliveryRepository,
            WorkflowRuleRepository,
        )
        from responsibleai.db.consent_proof_repository import ConsentProofRepository
        from responsibleai.db.execution_nonce_repository import ExecutionNonceRepository
        from responsibleai.db.revocation_epoch_repository import RevocationEpochRepository
        from responsibleai.db.root_authority_repository import RootAuthorityRepository
        from responsibleai.governance import WhitePactRuntimeGateway
        from responsibleai.governance.authority_resolver import AuthorityResolver
        from responsibleai.integrations.client import DEFAULT_CACHE_TTL_MINUTES, TrustClient
        from responsibleai.mcp.governance_integration import (
            GovernanceServices as RuntimeGovernanceServices,
        )
        from responsibleai.webhooks.manager import WebhookManager as RuntimeWebhookManager

        _governance_webhook_manager = RuntimeWebhookManager()
        _governance_webhook_manager.set_repository(WebhookDeliveryRepository(_db_engine))
        _governance_webhook_manager.set_config_repository(WebhookConfigRepository(_db_engine))

        _governance_services = RuntimeGovernanceServices(
            nonce_repo=ExecutionNonceRepository(_db_engine),
            epoch_repo=RevocationEpochRepository(_db_engine),
            org_repo=_org_repo,
            authority_resolver=AuthorityResolver(
                RootAuthorityRepository(_db_engine),
                ConsentProofRepository(_db_engine),
                DelegationRepository(_db_engine),
            ),
            gateway=WhitePactRuntimeGateway(),
            evidence_repo=EvidenceRepository(_db_engine),
            approval_repo=ApprovalRepository(_db_engine),
            policy_repo=PolicyRepository(_db_engine),
            # Continuous MCP Trust: this is the hot governed-dispatch
            # path, making a live Trust Index HTTP call on every
            # governed call with a provider/model pair -- caching (with
            # bounded, re-verified staleness; see client.py's
            # TrustClient docstring) is worth it here specifically.
            trust_client=TrustClient(cache_ttl_minutes=DEFAULT_CACHE_TTL_MINUTES),
            webhook_manager=_governance_webhook_manager,
            ceiling_repo=OrgAuthorityCeilingRepository(_db_engine),
            workflow_rule_repo=WorkflowRuleRepository(_db_engine),
            delegation_repo=DelegationRepository(_db_engine),
            autonomy_budget_repo=OrgAutonomyBudgetRepository(_db_engine),
            outcome_repo=OutcomeRepository(_db_engine),
            intent_repo=IntentContractRepository(_db_engine),
        )
    # Reuses the exact same RAI_OIDC_* / Settings.oidc_* config the
    # dashboard API's SSO login already reads (dashboard/app.py's own
    # `_oidc_provider` construction) — a Bearer JWT obtained via the
    # existing `/api/auth/login/oidc` flow authenticates here too, making
    # the hosted MCP server an OAuth/OIDC *resource server* against
    # whichever Authorization Server the org's SSO already trusts, rather
    # than a second, MCP-specific OIDC config to keep in sync.
    _oidc_provider = (
        OIDCProvider(
            issuer=settings.oidc_issuer,
            client_id=settings.oidc_client_id,
            jwks_uri=settings.oidc_jwks_uri,
            skip_verification=settings.oidc_skip_verification,
        )
        if settings.oidc_issuer
        else None
    )
    # Verified Principal (Authority Everywhere Phase 3) — a Bearer VC-JWT
    # authenticates a non-human principal (service account, external
    # attested agent) rather than a human IdP session; see
    # auth/verifiable_credential.py's module docstring for scope. Empty
    # `vc_trusted_issuers` (the default) disables this path entirely, the
    # same "unset config -> feature off" posture `_oidc_provider` above
    # already uses.
    _vc_provider = (
        VerifiableCredentialProvider(
            trusted_issuers=settings.vc_trusted_issuers,
            skip_verification=settings.vc_skip_verification,
        )
        if settings.vc_trusted_issuers
        else None
    )
    _principal_repo = PrincipalRepository(_db_engine)
    transport_security = _build_transport_security()
    sse = SseServerTransport("/messages/", security_settings=transport_security)
    # stateless=True: each POST to /mcp is authenticated and dispatched
    # independently, mirroring the legacy /sse transport's per-connection
    # Bearer auth rather than introducing cross-request session affinity.
    streamable_http = StreamableHTTPSessionManager(
        app=server,
        stateless=True,
        security_settings=transport_security,
    )
    auth_limiter = _AuthFailureLimiter(
        max_failures=int(os.environ.get("RAI_MCP_HTTP_AUTH_MAX_FAILURES", "10")),
        window_seconds=float(os.environ.get("RAI_MCP_HTTP_AUTH_WINDOW_SECONDS", "60")),
    )

    @asynccontextmanager
    async def _lifespan(_app: Starlette) -> Any:
        await _db_engine.init(auto_create_tables=not settings.is_production)
        if _governance_webhook_manager is not None:
            await _governance_webhook_manager.load_configs()
            _governance_webhook_manager.start_retry_worker()
        try:
            async with streamable_http.run():
                yield
        finally:
            if _governance_webhook_manager is not None:
                _governance_webhook_manager.stop_retry_worker()

    trust_forwarded = _env_bool(
        "WHITEPACT_MCP_TRUST_FORWARDED_HEADERS", default=False
    ) or _env_bool("RAI_MCP_HTTP_TRUST_FORWARDED_HEADERS", default=False)

    def _peer_ip(request: Request) -> str:
        if trust_forwarded:
            xff = request.headers.get("x-forwarded-for")
            if xff:
                client = xff.split(",")[0].strip()
                if client:
                    return client
        return request.client.host if request.client else "unknown"

    def _client_key(request: Request) -> tuple[str, str]:
        """Returns (rate_limit_key, peer_ip) using non-secret credential fingerprinting.
        Never exposes or logs raw bearer tokens."""
        import hashlib

        peer = _peer_ip(request)
        auth_header = request.headers.get("authorization", "")
        if auth_header.lower().startswith("bearer "):
            token = auth_header[7:].strip()
            if token:
                token_fp = hashlib.sha256(token.encode("utf-8")).hexdigest()[:16]
                return f"cred:{token_fp}", peer
        return f"anon:{peer}", peer

    async def _resolve_oidc_context(token: str) -> OrgContext | None:
        """Validate an OIDC-issued Bearer JWT and map its claims to an
        OrgContext — same logic as dashboard/app.py's `_resolve_oidc_context`.
        Static API keys are prefixed `rai_` (see `_generate_raw_key` in
        org_repository.py); anything else is attempted as a JWT when an
        OIDC provider is configured, so a JWT and a static key are never
        ambiguous."""
        if _oidc_provider is None or token.startswith("rai_"):
            return None
        try:
            claims = await _oidc_provider.validate_token(token)
        except ValueError:
            return None

        org = await _org_repo.get_org(claims.org_id) if claims.org_id else None
        if org is None:
            # A valid IdP signature proves who issued the JWT, not membership
            # in a WhitePact tenant. Never manufacture a FREE tenant context
            # for an unknown or missing org claim.
            return None
        role = Role.VIEWER
        for raw_role in claims.roles:
            candidate = role_from_str(raw_role)
            if candidate.value == raw_role.upper():
                role = candidate
                break

        return OrgContext(
            key_id=f"oidc:{claims.sub}",
            role=role,
            org_id=claims.org_id,
            org_name=org.name,
            is_legacy=False,
            plan=org.plan,
            authentication_method="oidc",
        )

    async def _resolve_vc_context(token: str) -> OrgContext | None:
        """Verified Principal (Authority Everywhere Phase 3): validate a
        Bearer VC-JWT presentation and map it to an OrgContext, the same
        shape `_resolve_oidc_context` produces so every downstream
        governance call site (`IdentityContext.from_org_context`, RBAC,
        rate limiting) works unchanged. `looks_like_vc_jwt` decides
        *whether to attempt* VC verification without trusting anything
        it reads — full verification happens inside
        `validate_presentation`. Runs only after `_resolve_oidc_context`
        has already returned `None` for this token (see `_authenticate`),
        so an OIDC-issued JWT from this deployment's own IdP is never
        misrouted here even if it happens to carry a `vc` claim."""
        if _vc_provider is None or token.startswith("rai_"):
            return None
        if not looks_like_vc_jwt(token):
            return None
        try:
            claims = await _vc_provider.validate_presentation(token)
        except ValueError:
            return None

        try:
            claim = build_principal_claim(claims)
            await _principal_repo.record(claim)
        except Exception:
            # Audit-trail write only -- the principal is already fully
            # verified by this point (see auth/verifiable_credential.py);
            # a DB failure here must not block an otherwise-valid
            # authentication, matching OutcomeRecord's fail-open posture.
            _logger.exception(
                "verified_principal_audit_write_failed principal_sub=%s issuer=%s",
                claims.sub,
                claims.issuer,
            )

        org = await _org_repo.get_org(claims.org_id) if claims.org_id else None
        role = Role.VIEWER
        for raw_role in claims.roles:
            candidate = role_from_str(raw_role)
            if candidate.value == raw_role.upper():
                role = candidate
                break

        return OrgContext(
            key_id=f"vc:{claims.sub}",
            role=role,
            org_id=claims.org_id,
            org_name=org.name if org else None,
            is_legacy=False,
            plan=org.plan if org else Plan.FREE,
            authentication_method="vc",
        )

    async def _authenticate(request: Request) -> OrgContext | None:
        if settings.mcp_http_allow_unauthenticated_demo:
            # DANGER — demo/recording use only, see config.py's field
            # docstring. Grants read-only access with no key at all.
            # Plan.ENTERPRISE (not FREE): FREE gets zero hosted quota by
            # design (see licensing.py MONTHLY_CALL_QUOTA), which would
            # block a reviewer from exercising the full tool surface —
            # the opposite of what a demo should show. Role stays
            # VIEWER (read-only) regardless; plan and role are separate
            # axes, so this doesn't grant any write/admin capability.
            return OrgContext(
                key_id="demo:unauthenticated",
                role=Role.VIEWER,
                is_legacy=True,
                plan=Plan.ENTERPRISE,
            )
        auth_header = request.headers.get("authorization", "")
        if not auth_header.lower().startswith("bearer "):
            return None
        raw_key = auth_header[7:].strip()
        if not raw_key:
            return None
        if raw_key.startswith("wp_at_"):
            if _mcp_oauth_server is None:
                return None
            return await _mcp_oauth_server.resolve_access_token(raw_key)
        oidc_ctx = await _resolve_oidc_context(raw_key)
        if oidc_ctx is not None:
            return oidc_ctx
        vc_ctx = await _resolve_vc_context(raw_key)
        if vc_ctx is not None:
            return vc_ctx
        return await _org_repo.authenticate(raw_key)

    def _protected_resource_metadata_url(request: Request) -> str:
        if _mcp_oauth_server is not None:
            return f"{_mcp_oauth_server.issuer}/.well-known/oauth-protected-resource"
        return str(request.url.replace(path="/.well-known/oauth-protected-resource", query=""))

    async def _authenticate_or_error(
        request: Request,
    ) -> tuple[OrgContext | None, JSONResponse | None]:
        """Bearer auth gated by `auth_limiter`: blocks a client IP that's
        already exhausted its failure budget *before* touching the DB, then
        records a fresh failure on rejection. Shared by both hosted
        transports so a probe against one doesn't get a bigger budget by
        switching to the other."""
        client_key, peer_ip = _client_key(request)
        if await auth_limiter.is_blocked(client_key, peer_key=peer_ip):
            return None, JSONResponse(
                {
                    "error": "too_many_attempts",
                    "message": "Too many failed authentication attempts from this client. Try again later.",
                },
                status_code=429,
            )
        try:
            ctx = await _authenticate(request)
        except OAuthProtocolError as exc:
            if _mcp_oauth_server is not None:
                await _mcp_oauth_server.record_access_failure(exc.error)
            if exc.status_code == 403:
                return None, JSONResponse(
                    {"error": exc.error, "message": exc.description},
                    status_code=403,
                    headers={
                        "WWW-Authenticate": (
                            f'Bearer resource_metadata="{_protected_resource_metadata_url(request)}", '
                            f'error="insufficient_scope", scope="whitepact:review"'
                        )
                    },
                )
            ctx = None
        if ctx is None:
            await auth_limiter.record_failure(client_key, peer_key=peer_ip)
            headers = {}
            if _oidc_provider is not None or _mcp_oauth_server is not None:
                # RFC 9728 / MCP Authorization spec: point an OAuth-aware
                # client at where to discover the Authorization Server,
                # instead of leaving it to guess. Only advertised when an
                # OIDC provider is actually configured — advertising it
                # unconditionally would tell every client "use OAuth" even
                # for deployments that only support static API keys.
                headers["WWW-Authenticate"] = (
                    f'Bearer resource_metadata="{_protected_resource_metadata_url(request)}", '
                    f'scope="whitepact:review"'
                )
            return None, JSONResponse(
                {"error": "unauthorized", "message": "Provide a valid Bearer credential."},
                status_code=401,
                headers=headers,
            )
        return ctx, None

    async def handle_sse(request: Request) -> Any:
        ctx, error = await _authenticate_or_error(request)
        if error is not None:
            return error

        org_token = _current_org.set(ctx)
        usage_token = _current_usage_repo.set(_usage_repo)
        governance_token = _current_governance.set(_governance_services)
        hosted_token = _current_hosted.set(True)
        try:
            async with sse.connect_sse(request.scope, request.receive, request._send) as (
                read_stream,
                write_stream,
            ):
                init_options = server.create_initialization_options()
                await server.run(read_stream, write_stream, init_options)
        finally:
            _current_org.reset(org_token)
            _current_usage_repo.reset(usage_token)
            _current_governance.reset(governance_token)
            _current_hosted.reset(hosted_token)
        return JSONResponse({}, status_code=200)

    class _StreamableHttpEndpoint:
        """A plain `async def` here would make Starlette's `Route` treat it
        as a `func(request) -> Response` handler (see `Route.__init__`'s
        `inspect.isfunction` check) and wrap it in `request_response`,
        which is incompatible with `StreamableHTTPSessionManager.handle_request`'s
        raw `(scope, receive, send)` ASGI signature. A callable *instance*
        fails that isfunction/ismethod check, so Route mounts it as ASGI
        directly — and unlike `Mount`, `Route` matches the exact path with
        no wildcard remainder, so `/mcp` needs no trailing slash and never
        307-redirects the way `Mount("/mcp", ...)` would.
        """

        async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
            request = Request(scope, receive=receive)
            ctx, error = await _authenticate_or_error(request)
            if error is not None:
                await error(scope, receive, send)
                return

            org_token = _current_org.set(ctx)
            usage_token = _current_usage_repo.set(_usage_repo)
            governance_token = _current_governance.set(_governance_services)
            hosted_token = _current_hosted.set(True)
            try:
                await streamable_http.handle_request(scope, receive, send)
            finally:
                _current_org.reset(org_token)
                _current_usage_repo.reset(usage_token)
                _current_governance.reset(governance_token)
                _current_hosted.reset(hosted_token)

    handle_streamable_http = _StreamableHttpEndpoint()

    async def health(request: Request) -> JSONResponse:
        from responsibleai.mcp.tools import production_tool_count

        return JSONResponse(
            {
                "status": "ok",
                # "transport" (singular) is kept for existing consumers of this
                # diagnostics endpoint; "transports" is the new, complete list.
                "transport": "http+sse",
                "transports": ["streamable-http", "http+sse"],
                "tools": production_tool_count(),
            }
        )

    async def ready(request: Request) -> JSONResponse:
        db_ok = await _db_engine.ping(timeout_seconds=2.0)
        if db_ok:
            return JSONResponse(
                {
                    "status": "ready",
                    "database": "connected",
                }
            )
        return JSONResponse(
            {
                "status": "unavailable",
                "database": "disconnected",
            },
            status_code=503,
        )

    async def protected_resource_metadata(request: Request) -> JSONResponse:
        """RFC 9728 Protected Resource Metadata. 404 when no OIDC provider
        is configured — this deployment then only supports static API
        keys, and there's no Authorization Server to point a client at."""
        if _mcp_oauth_server is not None:
            return JSONResponse(_mcp_oauth_server.protected_resource_metadata())
        if _oidc_provider is None:
            return JSONResponse({"error": "not_found"}, status_code=404)
        resource_url = str(request.url.replace(path="/mcp", query=""))
        return JSONResponse(
            {
                "resource": resource_url,
                "authorization_servers": [settings.oidc_issuer],
                "bearer_methods_supported": ["header"],
            }
        )

    async def authorization_server_metadata(request: Request) -> JSONResponse:
        if _mcp_oauth_server is None:
            return JSONResponse({"error": "not_found"}, status_code=404)
        return JSONResponse(_mcp_oauth_server.authorization_server_metadata())

    def _oauth_error(exc: OAuthProtocolError) -> JSONResponse:
        return JSONResponse(
            {"error": exc.error, "error_description": exc.description},
            status_code=exc.status_code,
            headers={"Cache-Control": "no-store"},
        )

    def _body_too_large(request: Request) -> bool:
        try:
            return int(request.headers.get("content-length", "0") or 0) > 16_384
        except ValueError:
            return True

    async def _form(request: Request) -> dict[str, str]:
        from urllib.parse import parse_qs

        if _body_too_large(request):
            raise OAuthProtocolError("invalid_request", "Form body is too large", status_code=413)
        raw_body = await request.body()
        if len(raw_body) > 16_384:
            raise OAuthProtocolError("invalid_request", "Form body is too large", status_code=413)
        body = raw_body.decode("utf-8", errors="strict")
        return {key: values[-1] for key, values in parse_qs(body, keep_blank_values=True).items()}

    async def oauth_register(request: Request) -> JSONResponse:
        if _mcp_oauth_server is None:
            return JSONResponse({"error": "not_found"}, status_code=404)
        try:
            if _body_too_large(request):
                raise OAuthProtocolError(
                    "invalid_client_metadata", "Registration body is too large", status_code=413
                )
            raw_body = await request.body()
            if len(raw_body) > 16_384:
                raise OAuthProtocolError(
                    "invalid_client_metadata", "Registration body is too large", status_code=413
                )
            payload = json.loads(raw_body.decode("utf-8", errors="strict"))
            if not isinstance(payload, dict):
                raise OAuthProtocolError("invalid_client_metadata", "A JSON object is required")
            registered = await _mcp_oauth_server.register_client(payload)
        except (json.JSONDecodeError, UnicodeDecodeError):
            return _oauth_error(OAuthProtocolError("invalid_client_metadata", "Invalid JSON body"))
        except OAuthProtocolError as exc:
            return _oauth_error(exc)
        return JSONResponse(registered, status_code=201, headers={"Cache-Control": "no-store"})

    async def oauth_authorize_get(request: Request) -> HTMLResponse | JSONResponse:
        if _mcp_oauth_server is None:
            return JSONResponse({"error": "not_found"}, status_code=404)
        try:
            request_id, client_name = await _mcp_oauth_server.begin_authorization(
                dict(request.query_params)
            )
        except OAuthProtocolError as exc:
            return _oauth_error(exc)
        page = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>Authorize WhitePact</title></head><body><main>
<h1>Authorize WhitePact review access</h1>
<p><strong>{html.escape(client_name)}</strong> requests permission to run WhitePact review tools.</p>
<p>Use a dedicated VIEWER or ANALYST API key. Administrative keys are rejected.</p>
<form method="post" action="/oauth/authorize">
<input type="hidden" name="request_id" value="{html.escape(request_id, quote=True)}">
<label>WhitePact API key <input type="password" name="api_key" autocomplete="current-password" required></label>
<button type="submit" name="action" value="allow">Authorize</button>
<button type="submit" name="action" value="deny" formnovalidate>Deny</button>
</form></main></body></html>"""
        return HTMLResponse(
            page,
            headers={
                "Cache-Control": "no-store",
                "Content-Security-Policy": (
                    "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; "
                    "base-uri 'none'; frame-ancestors 'none'"
                ),
                "Referrer-Policy": "no-referrer",
                "X-Content-Type-Options": "nosniff",
                "X-WhitePact-OAuth-Request-ID": request_id,
            },
        )

    async def oauth_authorize_post(request: Request) -> RedirectResponse | JSONResponse:
        if _mcp_oauth_server is None:
            return JSONResponse({"error": "not_found"}, status_code=404)
        client_key, peer_ip = _client_key(request)
        if await auth_limiter.is_blocked(client_key, peer_key=peer_ip):
            return _oauth_error(
                OAuthProtocolError(
                    "temporarily_unavailable", "Too many failed login attempts", status_code=429
                )
            )
        try:
            form = await _form(request)
            location = await _mcp_oauth_server.complete_authorization(
                form.get("request_id", ""),
                form.get("api_key", ""),
                form.get("action", "deny"),
            )
        except (UnicodeDecodeError, OAuthProtocolError) as exc:
            protocol_error = (
                exc
                if isinstance(exc, OAuthProtocolError)
                else OAuthProtocolError("invalid_request", "Invalid form body")
            )
            if protocol_error.status_code in {401, 403}:
                await auth_limiter.record_failure(client_key, peer_key=peer_ip)
            return _oauth_error(protocol_error)
        return RedirectResponse(location, status_code=303, headers={"Cache-Control": "no-store"})

    async def oauth_token(request: Request) -> JSONResponse:
        if _mcp_oauth_server is None:
            return JSONResponse({"error": "not_found"}, status_code=404)
        client_key, peer_ip = _client_key(request)
        if await auth_limiter.is_blocked(client_key, peer_key=peer_ip):
            return _oauth_error(
                OAuthProtocolError(
                    "temporarily_unavailable", "Too many failed token attempts", status_code=429
                )
            )
        try:
            form = await _form(request)
            grant_type = form.get("grant_type")
            if grant_type == "authorization_code":
                payload = await _mcp_oauth_server.exchange_authorization_code(form)
            elif grant_type == "refresh_token":
                payload = await _mcp_oauth_server.refresh(form)
            else:
                raise OAuthProtocolError("unsupported_grant_type", "Unsupported grant type")
        except (UnicodeDecodeError, OAuthProtocolError) as exc:
            protocol_error = (
                exc
                if isinstance(exc, OAuthProtocolError)
                else OAuthProtocolError("invalid_request", "Invalid form body")
            )
            await auth_limiter.record_failure(client_key, peer_key=peer_ip)
            return _oauth_error(protocol_error)
        return JSONResponse(payload, headers={"Cache-Control": "no-store", "Pragma": "no-cache"})

    async def oauth_revoke(request: Request) -> JSONResponse:
        if _mcp_oauth_server is None:
            return JSONResponse({"error": "not_found"}, status_code=404)
        try:
            form = await _form(request)
            await _mcp_oauth_server.revoke(form.get("token", ""))
        except UnicodeDecodeError:
            return _oauth_error(OAuthProtocolError("invalid_request", "Invalid form body"))
        return JSONResponse({}, headers={"Cache-Control": "no-store"})

    async def mcp_server_card(request: Request) -> JSONResponse:
        """Static capability card for directories (e.g. Smithery) that
        can't complete a live authenticated scan against /mcp — this
        deployment has no OAuth authorization server configured (see
        protected_resource_metadata above), only static Bearer API
        keys, which a directory's automated crawler can't obtain on
        its own. Bypasses live scanning per the directory's own
        documented fallback rather than leaving the listing unscanned.
        Tool/resource data is generated from the same TOOL_DEFS/
        RESOURCE_DEFS the live server itself advertises — never a
        separately maintained, driftable copy."""
        return JSONResponse(
            {
                "serverInfo": {"name": "whitepact", "version": __version__},
                "authentication": {
                    "required": True,
                    "schemes": (["oauth2", "apiKey"] if _mcp_oauth_server else ["apiKey"]),
                },
                "tools": [
                    (_with_oauth_security(t) if _mcp_oauth_server else t).model_dump(
                        mode="json", exclude_none=True, by_alias=True
                    )
                    for t in PRODUCTION_TOOL_DEFS
                ],
                "resources": [
                    r.model_dump(mode="json", exclude_none=True, by_alias=True)
                    for r in RESOURCE_DEFS
                ],
                "prompts": [],
            }
        )

    async def openai_apps_challenge(request: Request) -> PlainTextResponse:
        """Plaintext token for OpenAI's plugin-submission domain-ownership
        check (see compliance/OPENAI_PLUGIN_SUBMISSION_PREP.md). Per their
        spec this endpoint must return *only* the raw token -- no JSON
        wrapper -- so PlainTextResponse, not JSONResponse. 404s when no
        token is configured rather than serving an empty/stale body."""
        if not settings.openai_apps_challenge_token:
            return PlainTextResponse("not configured", status_code=404)
        return PlainTextResponse(settings.openai_apps_challenge_token)

    app = Starlette(
        routes=[
            Route("/health", endpoint=health),
            Route("/ready", endpoint=ready),
            Route("/mcp", endpoint=handle_streamable_http),
            Route("/sse", endpoint=handle_sse),
            Mount("/messages/", app=sse.handle_post_message),
            Route("/.well-known/oauth-protected-resource", endpoint=protected_resource_metadata),
            Route(
                "/.well-known/oauth-authorization-server",
                endpoint=authorization_server_metadata,
            ),
            Route("/oauth/register", endpoint=oauth_register, methods=["POST"]),
            Route("/oauth/authorize", endpoint=oauth_authorize_get, methods=["GET"]),
            Route("/oauth/authorize", endpoint=oauth_authorize_post, methods=["POST"]),
            Route("/oauth/token", endpoint=oauth_token, methods=["POST"]),
            Route("/oauth/revoke", endpoint=oauth_revoke, methods=["POST"]),
            Route("/.well-known/mcp/server-card.json", endpoint=mcp_server_card),
            Route("/.well-known/openai-apps-challenge", endpoint=openai_apps_challenge),
        ],
        lifespan=_lifespan,
    )

    return app


def main_http() -> None:
    """CLI entry point: whitepact-mcp-http / responsibleai-mcp-http (hosted, Bearer-authenticated, plan-gated)."""
    import uvicorn

    # This process runs in a container (Render) that requires binding all
    # interfaces to be reachable at all; 127.0.0.1 would make the hosted
    # server unreachable and break the deployment. The actual security
    # boundary is the Bearer-key auth plus RAI_MCP_HTTP_ALLOWED_ORIGINS /
    # RAI_MCP_HTTP_ALLOWED_HOSTS enforced in _build_http_app(), not the bind
    # address -- see THREAT_MODEL.md.
    host = os.environ.get("RAI_MCP_HTTP_HOST", "0.0.0.0")  # nosec B104
    port = int(os.environ.get("RAI_MCP_HTTP_PORT", "8766"))
    _logger.info("starting %s v1.2.0 (http+sse) on %s:%s", server.name, host, port)
    _log_invocation_name("http+sse server")
    uvicorn.run(_build_http_app(), host=host, port=port)


if __name__ == "__main__":
    main()
