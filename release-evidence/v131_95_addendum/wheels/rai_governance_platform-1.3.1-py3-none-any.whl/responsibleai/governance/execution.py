# Copyright (c) 2026 Guruprasath Annadurai
# SPDX-License-Identifier: MIT
"""Decision -> execution binding and the executor abstraction — closes
the gap the WhitePact v3 authority-layer review flagged as the highest
priority after the approval-mutation fix: nothing previously stopped a
caller from running `dispatch_tool()` directly, bypassing whatever
`WhitePactRuntimeGateway.evaluate()` actually decided. That direct-call
path still exists (see `THREAT_MODEL.md`'s "governance gateway is a
chosen integration point, not an unbypassable boundary" entry — this
module doesn't change that for arbitrary Python callers), but the one
path this platform itself controls — `mcp/server.py`'s dispatch of its
own 27 tools — is wired through `InternalToolExecutor` below, which
structurally cannot execute without a matching, unexpired, single-use
`ExecutionAuthorization`.

**Deliberately not cryptographically signed.** `ExecutionAuthorization`
is a structural binding (digest + org + expiry + single-use consumed
flag), not an HMAC-signed token. This is the audited, correct call as
long as the object never crosses a trust boundary — the gateway
constructs it and `InternalToolExecutor.execute()` consumes it within
the same async call stack, in the same process, never serialized or
sent over a network. Signing it would add real complexity (key
management, verification, clock-skew handling) for a threat model that
doesn't exist yet — an attacker able to forge an in-process Python
object already has arbitrary code execution in this process, at which
point HMAC verification protects nothing. If a future executor lives
in a separate process/service (a real `MCPExecutor` proxying to a
different host, per the v3 spec's Section 28), *that* is exactly when
signing becomes load-bearing, and this module says so rather than
signing prematurely — see the module docstring's own "do not invent
cryptography" instruction from the v3 spec review.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from responsibleai.db.execution_nonce_repository import ExecutionNonceRepository

from responsibleai.governance.approval import compute_action_digest
from responsibleai.governance.models import ActionRequest, DecisionResult, GovernanceDecision

DEFAULT_AUTHORIZATION_TTL_SECONDS = 30


class ExecutionNotAuthorizedError(Exception):
    """Base class for every reason `Executor.execute()` refuses to run
    an action — callers that only care "was this refused" can catch
    this instead of enumerating every subclass."""


class DecisionNotExecutableError(ExecutionNotAuthorizedError):
    """`authorize_execution()` was called with a decision that isn't
    ALLOW/ALLOW_WITH_REDACTION — DENY, QUARANTINE, and REQUIRE_APPROVAL
    never produce an `ExecutionAuthorization` at all; there is nothing
    for an executor to consume."""

    def __init__(self, decision: GovernanceDecision) -> None:
        self.decision = decision
        super().__init__(f"GovernanceDecision.{decision.value} does not authorize execution.")


class AuthorizationExpiredError(ExecutionNotAuthorizedError):
    def __init__(self, authorization_id: str) -> None:
        self.authorization_id = authorization_id
        super().__init__(f"ExecutionAuthorization {authorization_id!r} has expired.")


class AuthorizationAlreadyConsumedError(ExecutionNotAuthorizedError):
    """Replay protection — the same authorization presented twice."""

    def __init__(self, authorization_id: str) -> None:
        self.authorization_id = authorization_id
        super().__init__(f"ExecutionAuthorization {authorization_id!r} was already consumed.")


class AuthorizationActionMismatchError(ExecutionNotAuthorizedError):
    """The mutation invariant for direct (non-approval) execution: the
    action presented to the executor is not byte-identical to the one
    the gateway authorized — same shape as
    `db.approval_repository.ApprovalActionMismatchError`, for the
    ALLOW/ALLOW_WITH_REDACTION path rather than the REQUIRE_APPROVAL
    path."""

    def __init__(self, authorization_id: str) -> None:
        self.authorization_id = authorization_id
        super().__init__(
            f"ExecutionAuthorization {authorization_id!r} does not match the action "
            "presented for execution."
        )


class AuthorizationOrganizationMismatchError(ExecutionNotAuthorizedError):
    def __init__(self, authorization_id: str) -> None:
        self.authorization_id = authorization_id
        super().__init__(
            f"ExecutionAuthorization {authorization_id!r} belongs to a different organization."
        )


class AuthorizationTargetDriftError(ExecutionNotAuthorizedError):
    """Execution Permit v2 (Authority Everywhere Phase 9): the resolved
    identity of *where this action actually goes* has changed since the
    decision was made. ``action_digest`` binds to the action's own
    shape (agent, action_type, target string, arguments) but never
    captured anything about what a target *string* like
    ``server_id::tool_name`` currently resolves to -- an upstream
    server's URL, enabled state, or credential can change between
    decision time and execution time without the action digest moving
    at all, since ``UpstreamServer.server_id`` stays the same. A permit
    that was granted against one resolved target must not silently
    authorize execution against a different one that now sits behind
    the same target string."""

    def __init__(self, authorization_id: str) -> None:
        self.authorization_id = authorization_id
        super().__init__(
            f"ExecutionAuthorization {authorization_id!r} was granted against a different "
            "resolved target than the one now being executed against (target configuration "
            "drifted between authorization and execution)."
        )


@dataclass
class ExecutionAuthorization:
    """What `authorize_execution()` hands an executor — the structural
    proof that a specific action was actually decided ALLOW or
    ALLOW_WITH_REDACTION, for this exact action, this exact org, within
    a short validity window, and not yet spent.

    Hosted executors persist `nonce` at admission against `revocation_epoch`.
    This is single-use admission, not exactly-once external side effects and
    not proof that canonical authority has been resolved. Database-free local
    helpers retain only in-process consumption; epoch-bound permits cannot use
    that fallback. This object is never accepted as a network credential.

    `target_fingerprint` is Execution Permit v2 (Authority Everywhere
    Phase 9): an optional, executor-supplied hash of whatever the
    action's target string currently resolves to — `None` for executors
    with no external resolution step (`InternalToolExecutor`: the
    action_type *is* the identity, already fully covered by
    `action_digest`). When set, `execute()` must recompute the same
    fingerprint from the target as it exists *right now* and refuse to
    run on any mismatch — see `AuthorizationTargetDriftError`.
    """

    action_digest: str
    organization_id: str | None
    decision: GovernanceDecision
    target_fingerprint: str | None = None
    authorization_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    nonce: str = field(default_factory=lambda: uuid.uuid4().hex)
    issued_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    expires_at: datetime = field(
        default_factory=lambda: (
            datetime.now(UTC) + timedelta(seconds=DEFAULT_AUTHORIZATION_TTL_SECONDS)
        )
    )
    consumed: bool = False
    principal_id: str | None = None
    revocation_epoch: int | None = None

    @property
    def is_expired(self) -> bool:
        return datetime.now(UTC) >= self.expires_at

    def matches_action(self, action: ActionRequest) -> bool:
        return (
            self.principal_id == action.agent.identity.identity_id
            and self.action_digest == compute_action_digest(action)
        )


def authorize_execution(
    decision: DecisionResult,
    action: ActionRequest,
    *,
    ttl_seconds: int = DEFAULT_AUTHORIZATION_TTL_SECONDS,
    target_fingerprint: str | None = None,
    revocation_epoch: int | None = None,
) -> ExecutionAuthorization:
    """Turn a gateway decision into an `ExecutionAuthorization` — the
    only place one is ever constructed. Raises `DecisionNotExecutableError`
    for anything other than ALLOW/ALLOW_WITH_REDACTION; DENY/QUARANTINE
    end the flow with nothing to authorize, and REQUIRE_APPROVAL's
    binding is `db.approval_repository.ApprovalRepository.consume()`,
    not this function — that path resolves asynchronously, potentially
    long after the original `ActionRequest` object is gone, which is
    exactly why it needs its own persisted binding (`action_digest` on
    `ApprovalRequest`) rather than a short-lived in-memory object like
    this one.

    *action* must already reflect what will actually execute — for
    `ALLOW_WITH_REDACTION`, that means the caller passes an `ActionRequest`
    built from `decision.redacted_arguments`, not the original
    arguments, so the digest binds to what the executor will really run.

    *target_fingerprint* is Execution Permit v2 (Phase 9) — pass it when
    the caller already resolved the action's target to something
    concrete (e.g. `upstream_executor.compute_upstream_target_fingerprint()`
    for an `UpstreamServer`) at decision time, so `execute()` can detect
    drift between that resolution and what the target resolves to when
    the permit is actually consumed. Leave `None` when there's nothing
    to resolve (internal tools).
    """
    if decision.decision not in (GovernanceDecision.ALLOW, GovernanceDecision.ALLOW_WITH_REDACTION):
        raise DecisionNotExecutableError(decision.decision)

    return ExecutionAuthorization(
        action_digest=compute_action_digest(action),
        organization_id=action.agent.organization_id,
        decision=decision.decision,
        principal_id=action.agent.identity.identity_id,
        target_fingerprint=target_fingerprint,
        revocation_epoch=revocation_epoch,
        expires_at=datetime.now(UTC) + timedelta(seconds=ttl_seconds),
    )


class Executor(Protocol):
    """What every concrete executor implements. `execute()` must not
    run *action* without first validating *authorization* — see
    `InternalToolExecutor` for the reference implementation of that
    validation; a future `MCPExecutor`/`HTTPExecutor` (v3 spec Section
    28, not built yet) would perform the identical checks before doing
    whatever's specific to that transport."""

    async def execute(
        self, authorization: ExecutionAuthorization, action: ActionRequest
    ) -> Any: ...


def _validate_authorization(authorization: ExecutionAuthorization, action: ActionRequest) -> None:
    """Shared validation every `Executor.execute()` implementation
    must run first — pulled out as its own function so a future
    executor can't accidentally reimplement (and get wrong) the same
    four checks. Deliberately does not check `target_fingerprint` (see
    `check_target_fingerprint()`) — that check needs the *current*
    resolved target, which an executor can only produce after it has
    already looked the target up, and this function's four checks must
    still run (and take precedence) even when that lookup hasn't
    happened yet."""
    if authorization.consumed:
        raise AuthorizationAlreadyConsumedError(authorization.authorization_id)
    if authorization.decision not in (
        GovernanceDecision.ALLOW,
        GovernanceDecision.ALLOW_WITH_REDACTION,
    ):
        raise DecisionNotExecutableError(authorization.decision)
    if authorization.is_expired:
        raise AuthorizationExpiredError(authorization.authorization_id)
    if authorization.organization_id != action.agent.organization_id:
        raise AuthorizationOrganizationMismatchError(authorization.authorization_id)
    if not authorization.matches_action(action):
        raise AuthorizationActionMismatchError(authorization.authorization_id)


def check_target_fingerprint(
    authorization: ExecutionAuthorization, current_target_fingerprint: str | None
) -> None:
    """Execution Permit v2's drift check — call this *after*
    `_validate_authorization()` has already passed and *after* the
    executor has resolved *action.target* to something concrete (e.g.
    an `UpstreamServer`). Skipped entirely when
    `authorization.target_fingerprint is None` (nothing was resolved at
    decision time — `InternalToolExecutor`'s case), so an executor that
    never sets a fingerprint never needs to call this at all."""
    if authorization.target_fingerprint is None:
        return
    if authorization.target_fingerprint != current_target_fingerprint:
        raise AuthorizationTargetDriftError(authorization.authorization_id)


async def admit_execution(
    authorization: ExecutionAuthorization,
    action: ActionRequest,
    nonce_repo: ExecutionNonceRepository | None,
) -> None:
    """Consume before dispatch; database failure never falls back to memory.

    An epoch-bound permit cannot be downgraded to a local executor. The database
    transaction is the admission point, not an exactly-once side-effect promise.
    Revalidate after its await: expiry and mutable action binding may have changed.
    """
    _validate_authorization(authorization, action)
    if nonce_repo is not None:
        if authorization.revocation_epoch is None or not authorization.organization_id:
            raise ExecutionNotAuthorizedError("Durable execution requires a tenant and epoch")
        await nonce_repo.consume(
            authorization.nonce,
            authorization_id=authorization.authorization_id,
            organization_id=authorization.organization_id,
            expected_epoch=authorization.revocation_epoch,
        )
        _validate_authorization(authorization, action)
    elif authorization.revocation_epoch is not None:
        raise ExecutionNotAuthorizedError("Durable admission repository is unavailable")
    authorization.consumed = True


class InternalToolExecutor:
    """Executes one of this platform's own MCP tools
    (`mcp.tools.dispatch_tool`). In Phase 2, can route execution through
    the independent `IsolationBroker` to enforce OS/container-level
    containment.
    """

    def __init__(
        self,
        *,
        nonce_repo: ExecutionNonceRepository | None = None,
        broker: Any | None = None,
    ) -> None:
        self._nonce_repo = nonce_repo
        self._broker: Any = broker
        if broker is None:
            # In production or hosted execution, automatically initialize IsolationBroker
            import os

            is_prod = os.environ.get("ENVIRONMENT", "").lower() == "production"
            if is_prod or os.environ.get("WHITEPACT_ISOLATION_BACKEND"):
                from responsibleai.isolation.broker import IsolationBroker

                self._broker = IsolationBroker()
            else:
                self._broker = None

    async def execute(self, authorization: ExecutionAuthorization, action: ActionRequest) -> Any:
        from responsibleai.data_governance.backup_defense import assert_restore_readiness_admitted

        assert_restore_readiness_admitted()

        await admit_execution(authorization, action, self._nonce_repo)

        if self._broker is not None:
            return await self._broker.execute(authorization, action)

        import os

        if os.environ.get("ENVIRONMENT", "").lower() == "production":
            from responsibleai.isolation.errors import IsolationError

            raise IsolationError(
                "Same-process tool execution is strictly forbidden in production. "
                "An IsolationBroker is mandatory."
            )

        from responsibleai.governance.synthetic_counter import SYNTHETIC_COUNTER_TOOL
        from responsibleai.mcp.tools import dispatch_tool

        dispatch_args = dict(action.arguments)
        if action.action_type == SYNTHETIC_COUNTER_TOOL:
            dispatch_args["_whitepact_organization_id"] = action.agent.organization_id or ""
        return await dispatch_tool(
            action.action_type,
            dispatch_args,
            channel="governance_admitted",
        )
