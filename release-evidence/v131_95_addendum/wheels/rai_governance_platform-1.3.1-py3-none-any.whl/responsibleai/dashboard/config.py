# Copyright (c) 2026 Guruprasath Annadurai
# SPDX-License-Identifier: MIT
"""Runtime configuration — every value overridable via env var or .env file."""

from __future__ import annotations

import os
import warnings
from pathlib import Path
from typing import Annotated, Any, Literal

from pydantic import AliasChoices, Field, field_validator, model_validator
from pydantic_settings import (
    BaseSettings,
    NoDecode,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
)
from pydantic_settings.sources import EnvSettingsSource

# See MIGRATION_WHITEPACT_V2.md Section 5. WHITEPACT_ is the preferred
# prefix; RAI_ is the legacy prefix, kept fully functional for backward
# compatibility. Neither is hardcoded elsewhere -- both are derived from
# these two constants so the precedence rule stays in one place.
WHITEPACT_ENV_PREFIX = "WHITEPACT_"
LEGACY_ENV_PREFIX = "RAI_"
PRODUCTION_ENVIRONMENTS = frozenset({"production", "prod"})


def is_production_environment(environment: str) -> bool:
    """True only for explicit production identifiers — never inferred from infra."""
    return environment.strip().lower() in PRODUCTION_ENVIRONMENTS


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix=LEGACY_ENV_PREFIX,
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        """Give WHITEPACT_-prefixed env vars priority over RAI_-prefixed
        ones, per MIGRATION_WHITEPACT_V2.md Section 5's precedence rule:
        if both WHITEPACT_FOO and RAI_FOO are set, WHITEPACT_FOO wins.

        pydantic-settings resolves fields using the *first* source in this
        tuple that provides a value, falling through to later sources for
        anything the earlier ones don't set -- so prepending a
        WHITEPACT_-prefixed source ahead of the existing RAI_-prefixed
        `env_settings` gives exactly that precedence without touching how
        any individual field is declared.
        """
        whitepact_env_settings = EnvSettingsSource(
            settings_cls,
            case_sensitive=False,
            env_prefix=WHITEPACT_ENV_PREFIX,
        )
        return (
            init_settings,
            whitepact_env_settings,
            env_settings,
            dotenv_settings,
            file_secret_settings,
        )

    # Database
    db_path: str = Field(
        default_factory=lambda: str(Path.home() / ".responsibleai" / "data.db"),
        description="SQLite database path. Use ':memory:' for stateless/testing.",
    )

    # Authentication
    #
    # Annotated with NoDecode on purpose: for a plain `list[str]`-typed
    # field, pydantic-settings tries to JSON-decode the raw env var *before*
    # our `_parse_keys` validator below ever runs — so the documented
    # comma-separated format (`RAI_API_KEYS=key1,key2`, see .env.example /
    # DEPLOY_RUNBOOK.md) isn't valid JSON and crashes the whole app at
    # startup with a SettingsError. `NoDecode` tells pydantic-settings to
    # skip that JSON pre-decode and hand the raw string straight to our
    # validator instead. Confirmed via a clean-env repro before this fix;
    # same pattern applied to allowed_origins and oidc_scopes below.
    api_keys: Annotated[list[str], NoDecode] = Field(
        default=[],
        description="Comma-separated list of valid API keys. Empty = auth disabled (dev only).",
    )
    auth_enabled: bool = Field(
        default=True,
        description="Set to false to disable auth (development only).",
    )

    # Rate limiting
    rate_limit_default: str = Field(
        default="100/minute",
        description="Default rate limit applied to all endpoints.",
    )
    rate_limit_evaluate: str = Field(
        default="30/minute",
        description="Rate limit for the /api/evaluate endpoint.",
    )

    # CORS
    # NoDecode: see api_keys above for why — same pydantic-settings
    # env-parsing pitfall, same fix.
    allowed_origins: Annotated[list[str], NoDecode] = Field(
        default=["http://localhost:8765", "http://127.0.0.1:8765"],
        description="Allowed CORS origins.",
    )
    allow_all_origins: bool = Field(
        default=False,
        description="Set true to allow all origins (dev/demo only).",
    )

    # Governance
    alert_threshold: float = Field(
        default=5.0,
        description="Trust score drop (points) that triggers a DriftAlert.",
        ge=0.1,
        le=50.0,
    )
    monthly_budget_usd: float = Field(
        default=10_000.0,
        description="Monthly AI spending budget for budget enforcement.",
        ge=0.0,
    )

    # Logging
    log_level: str = Field(
        default="INFO",
        description="Logging level: DEBUG, INFO, WARNING, ERROR.",
    )
    log_json: bool = Field(
        default=True,
        description="Emit structured JSON logs (recommended for production).",
    )

    # Deployment Environment
    environment: str = Field(
        default="development",
        validation_alias=AliasChoices(
            "WHITEPACT_ENV",
            "RAI_ENV",
            "ENVIRONMENT",
            "ENV",
            "environment",
        ),
        description="Deployment environment (development, staging, production).",
    )

    # PostgreSQL (optional — defaults to SQLite via db_path)
    database_url: str | None = Field(
        default=None,
        validation_alias=AliasChoices(
            "WHITEPACT_DATABASE_URL",
            "DATABASE_URL",
            "RAI_DATABASE_URL",
            "database_url",
        ),
        description=(
            "Full database URL for async engine. "
            "postgresql://user:pass@host/db or leave unset to use SQLite."
        ),
    )

    # Schema migrations
    auto_migrate: bool = Field(
        default=True,
        description=(
            "Run `alembic upgrade head` automatically at startup. "
            "create_all() only creates brand-new tables — it never ALTERs "
            "existing ones, so without this, upgrading an existing self-hosted "
            "install to a version with schema changes leaves old columns "
            "missing and endpoints 500ing at runtime instead of failing at "
            "startup. Disable only if you run migrations explicitly as a "
            "separate deploy step (recommended for multi-replica hosted "
            "deployments, to avoid concurrent migration runs — see "
            "DEPLOY_RUNBOOK.md)."
        ),
    )

    # Governance service initialization. Hosted execution fails closed when disabled.
    # Production hosted MCP *startup* requires this to be true (see
    # mcp.server.hosted_production_preflight). Non-production may leave it
    # false; hosted tool calls then return governance_unavailable rather than
    # raw dispatch_tool().
    mcp_governance_enabled: bool = Field(
        default=False,
        description=(
            "Initialize WhitePactRuntimeGateway on the hosted-MCP process and "
            "route org-scoped Streamable HTTP/SSE tool calls through it. "
            "Hosted calls never fall through to ungated dispatch_tool() even "
            "when this is false — they fail closed with governance_unavailable. "
            "Production hosted startup refuses to boot if this is false. "
            "The self-hosted stdio transport has no organizational identity "
            "and remains a distinct, documented trust domain."
        ),
    )

    # Redis (optional — falls back to in-memory rate limiting)
    redis_url: str | None = Field(
        default=None,
        description="Redis URL for distributed rate limiting, e.g. redis://localhost:6379/0.",
    )

    # Deployment topology self-declaration
    multi_replica: bool = Field(
        default=False,
        description=(
            "Set true when running more than one instance of this process "
            "(load-balanced replicas, Kubernetes with replicas>1, etc.). "
            "Purely a self-declaration for a startup readiness check — it "
            "does not itself change any behavior. In-memory rate limiting "
            "and SQLite each give per-instance-only state, which is silently "
            "wrong (not just slow) once more than one instance shares "
            "traffic: each replica enforces its own separate rate-limit "
            "counter and its own separate database. Declaring this lets "
            "startup warn loudly about that instead of the failure mode "
            "being 'requests occasionally get 2x the intended rate limit "
            "and no one knows why.'"
        ),
    )

    # OpenTelemetry (optional)
    otel_endpoint: str | None = Field(
        default=None,
        description="OTLP HTTP endpoint, e.g. http://otel-collector:4318. Unset = disabled.",
    )
    otel_service_name: str = Field(
        default="responsibleai",
        description="Service name reported to the OTLP collector.",
    )
    otel_headers: str = Field(
        default="",
        description="Comma-separated key=value pairs sent as OTLP headers (e.g. Datadog API key).",
    )

    # OIDC / OAuth2 Single Sign-On (optional — leave unset to use API key auth only)
    oidc_issuer: str | None = Field(
        default=None,
        description="OIDC issuer URL, e.g. https://accounts.google.com or https://login.microsoftonline.com/<tenant>.",
    )
    oidc_client_id: str = Field(
        default="",
        description="OAuth2 client ID registered with the OIDC provider.",
    )
    oidc_client_secret: str = Field(
        default="",
        description="OAuth2 client secret (kept server-side only).",
    )
    oidc_redirect_uri: str = Field(
        default="http://localhost:8765/api/auth/callback",
        description="Callback URL registered with the OIDC provider.",
    )
    # NoDecode: see api_keys above for why — same pydantic-settings
    # env-parsing pitfall, same fix.
    oidc_scopes: Annotated[list[str], NoDecode] = Field(
        default=["openid", "email", "profile"],
        description="OAuth2 scopes to request.",
    )
    oidc_jwks_uri: str | None = Field(
        default=None,
        description="JWKS endpoint override. Auto-discovered from oidc_issuer if unset.",
    )
    oidc_skip_verification: bool = Field(
        default=False,
        description="Skip JWT signature verification (test/dev only — never use in production).",
    )

    # Verified Principal (Authority Everywhere Phase 3) — Verifiable
    # Credential (JWT-VC) bearer auth for non-human principals (service
    # accounts, external attested agents). Separate from OIDC above: an
    # OIDC issuer is one trusted party (this deployment's own IdP); a VC
    # deployment may need to trust several credential issuers at once,
    # hence a list rather than a single issuer/client_id pair.
    vc_trusted_issuers: Annotated[list[str], NoDecode] = Field(
        default=[],
        description="Comma-separated list of trusted Verifiable Credential issuer URLs. "
        "Empty (default) disables Verified Principal auth entirely.",
    )
    vc_skip_verification: bool = Field(
        default=False,
        description="Skip VC-JWT signature verification (test/dev only — never use in production).",
    )

    # SAML 2.0 Single Sign-On (optional — separate from OIDC above; some
    # enterprise IdPs support only one or the other, so both are wired
    # independently rather than one being built on top of the other).
    saml_idp_entity_id: str | None = Field(
        default=None,
        description="The identity provider's SAML entity ID. Setting this is what enables the SAML routes.",
    )
    saml_idp_sso_url: str = Field(
        default="",
        description="The identity provider's SSO redirect-binding URL (where AuthnRequests are sent).",
    )
    saml_idp_x509_cert: str = Field(
        default="",
        description="The identity provider's signing certificate, PEM-encoded (with or without the BEGIN/END header lines). Used to verify every SAMLResponse's signature.",
    )
    saml_sp_entity_id: str = Field(
        default="https://whitepact.com/saml/metadata",
        description="This service provider's own SAML entity ID, advertised in SP metadata and checked as the Audience on every assertion.",
    )
    saml_acs_url: str = Field(
        default="http://localhost:8765/api/auth/acs",
        description="The Assertion Consumer Service URL registered with the IdP — where it POSTs the SAMLResponse back.",
    )
    saml_session_secret: str = Field(
        default="",
        description=(
            "HMAC secret WhitePact uses to sign its own short-lived session "
            "token after a successful SAML login (SAML itself has no bearer-"
            "token concept — the assertion is a one-time browser ceremony, "
            "not a repeatable API credential, so the SP mints its own). "
            "Required if saml_idp_entity_id is set; generate with "
            '`python -c "import secrets; print(secrets.token_urlsafe(32))"`.'
        ),
    )
    openai_apps_challenge_token: str | None = Field(
        default=None,
        description=(
            "Verification token for OpenAI's plugin-submission domain "
            "check, served plaintext at "
            "/.well-known/openai-apps-challenge. Generated by OpenAI's "
            "submission portal per-draft -- rotates if the draft is "
            "recreated, so this is expected to change over time, not a "
            "long-lived secret."
        ),
    )
    mcp_http_allow_unauthenticated_demo: bool = Field(
        default=False,
        description=(
            "DANGER — local demo/recording only. When true, whitepact-mcp-http "
            "accepts requests with no Bearer key as a VIEWER. Production and "
            "prod environments refuse to start if this is true. Hosted tool "
            "execution still requires tenant-scoped governance (demo identity "
            "is not an organization)."
        ),
    )
    phase7a_dispatcher_enabled: bool = Field(
        default=False,
        validation_alias=AliasChoices(
            "PHASE7A_DISPATCHER_ENABLED",
            "WHITEPACT_PHASE7A_DISPATCHER_ENABLED",
            "RAI_PHASE7A_DISPATCHER_ENABLED",
        ),
        description=(
            "Development/staging Phase 7A dispatcher. Default false. "
            "Production Gate B is CLOSED; production must refuse activation."
        ),
    )
    mcp_oauth_issuer: str = Field(
        default="",
        description=(
            "Canonical HTTPS issuer for WhitePact's hosted-MCP OAuth 2.1 authorization "
            "server. Empty disables the built-in authorization server."
        ),
    )
    mcp_oauth_resource_uri: str = Field(
        default="",
        description="Canonical HTTPS resource identifier for the hosted /mcp endpoint.",
    )
    mcp_oauth_scopes: Annotated[list[str], NoDecode] = Field(
        default=["whitepact:review", "offline_access"],
        description="OAuth scopes available to hosted MCP clients.",
    )
    mcp_oauth_access_token_ttl_seconds: int = Field(
        default=900,
        ge=300,
        le=3600,
        description="Lifetime of an OAuth MCP access token in seconds.",
    )
    mcp_oauth_refresh_token_ttl_seconds: int = Field(
        default=2_592_000,
        ge=3600,
        le=7_776_000,
        description="Lifetime of a rotating OAuth MCP refresh token in seconds.",
    )

    # Stripe billing (optional — leave unset to disable paid-tier checkout)
    stripe_secret_key: str | None = Field(
        default=None,
        description="Stripe secret key (sk_live_... / sk_test_...). Unset = billing endpoints disabled.",
    )
    stripe_webhook_secret: str | None = Field(
        default=None,
        description="Stripe webhook signing secret (whsec_...) for verifying incoming events.",
    )
    stripe_price_id_pro: str | None = Field(
        default=None,
        description="Stripe Price ID for the PRO plan subscription.",
    )
    stripe_price_id_enterprise: str | None = Field(
        default=None,
        description="Stripe Price ID for the ENTERPRISE plan subscription.",
    )
    billing_success_url: str = Field(
        default="http://localhost:8765/billing/success",
        description="Redirect URL after successful Stripe checkout.",
    )
    billing_cancel_url: str = Field(
        default="http://localhost:8765/billing/cancel",
        description="Redirect URL after cancelled Stripe checkout.",
    )

    # Paddle billing (optional — leave unset to disable Paddle webhook handling)
    paddle_api_key: str | None = Field(
        default=None,
        description="Paddle API key for server-to-server operations.",
    )
    paddle_env: Literal["sandbox", "production"] | None = Field(
        default=None,
        description="Explicit Paddle API environment. Required when Paddle API access is configured.",
    )
    paddle_webhook_secret: str | None = Field(
        default=None,
        description="Paddle webhook signing secret for verifying incoming events.",
    )
    paddle_price_id_pro: str | None = Field(
        default=None,
        description="Paddle Price ID for the PRO plan subscription.",
    )
    paddle_price_id_enterprise: str | None = Field(
        default=None,
        description="Paddle Price ID for the ENTERPRISE plan subscription.",
    )
    paddle_signature_tolerance_seconds: int = Field(
        default=300,
        description="Paddle webhook signature timestamp drift tolerance in seconds.",
    )

    # Browser identity. Human sessions are deliberately independent from
    # workload API keys and use hashed opaque tokens in Secure cookies.
    web_public_url: str = Field(
        default="http://localhost:8765",
        description="Canonical public origin used in email verification links.",
    )
    web_session_ttl_hours: int = Field(default=12, ge=1, le=168)
    web_session_secure: bool = Field(
        default=True,
        description="Set false only for local HTTP development; production must keep Secure cookies.",
    )
    web_verification_delivery_url: str | None = Field(
        default=None,
        description="HTTPS webhook that accepts transactional verification-email payloads.",
    )
    web_verification_delivery_token: str | None = Field(
        default=None,
        description="Bearer credential for the verification delivery webhook.",
    )
    web_auth_dev_tokens: bool = Field(
        default=False,
        description="Local-only escape hatch that returns verification URLs in API responses.",
    )

    # Alertmanager → incident bridge (optional — leave unset to disable)
    alerts_webhook_token: str | None = Field(
        default=None,
        description=(
            "Shared-secret bearer token Prometheus Alertmanager must present "
            "(via webhook_configs' http_config.authorization) to "
            "POST /api/alerts/webhook. Unset = the endpoint returns 503, "
            "same pattern as Stripe billing being disabled until configured."
        ),
    )

    # Leaderboard — provider credentials for POST /api/leaderboard/run and
    # scripts/run_leaderboard_eval.py (optional per-provider; a model whose
    # provider has no key configured is skipped, not a hard failure, so a
    # deployer can track e.g. only OpenAI + Anthropic without also holding a
    # Google key). None of these gate the public read endpoints.
    leaderboard_openai_api_key: str | None = Field(
        default=None,
        description="OpenAI API key used only for leaderboard evaluation runs.",
    )
    leaderboard_anthropic_api_key: str | None = Field(
        default=None,
        description="Anthropic API key used only for leaderboard evaluation runs.",
    )
    leaderboard_google_api_key: str | None = Field(
        default=None,
        description="Google (Gemini) API key used only for leaderboard evaluation runs.",
    )
    leaderboard_azure_openai_api_key: str | None = Field(
        default=None,
        description="Azure OpenAI Service API key used only for leaderboard evaluation runs.",
    )
    leaderboard_azure_openai_endpoint: str | None = Field(
        default=None,
        description="Azure OpenAI resource endpoint, e.g. https://your-resource.openai.azure.com/ "
        "— required alongside the key; Azure OpenAI has no default shared endpoint.",
    )
    leaderboard_azure_openai_api_version: str = Field(
        default="2024-10-21",
        description="Azure OpenAI REST API version.",
    )

    # Server
    host: str = Field(default="127.0.0.1")
    port: int = Field(default=8765, ge=1, le=65535)
    workers: int = Field(default=1, ge=1, le=32)

    # White-label branding (optional — for OEM/white-label deployments, see
    # compliance/OEM_LICENSING.md). Defaults produce the standard
    # ResponsibleAI-branded experience; an OEM licensee sets these via env
    # vars to replace the sidebar name, logo, and browser tab title across
    # every served page without forking the frontend. Deliberately just a
    # display-layer swap — it doesn't touch licensing/entitlement, which is
    # a separate, out-of-band agreement per `compliance/OEM_LICENSING.md`.
    brand_name: str = Field(
        default="ResponsibleAI",
        description="Product name shown in the dashboard sidebar and browser tab title.",
    )
    brand_logo_url: str = Field(
        default="",
        description="Optional logo image URL shown in the sidebar instead of the brand name text.",
    )

    @property
    def is_production(self) -> bool:
        return is_production_environment(self.environment)

    @property
    def leaderboard_api_keys(self) -> dict[str, str | None]:
        return {
            "openai": self.leaderboard_openai_api_key,
            "anthropic": self.leaderboard_anthropic_api_key,
            "google": self.leaderboard_google_api_key,
            "azure-openai": self.leaderboard_azure_openai_api_key,
        }

    @field_validator("oidc_scopes", "mcp_oauth_scopes", mode="before")
    @classmethod
    def _parse_scopes(cls, v: Any) -> list[str]:
        if isinstance(v, str):
            return [s.strip() for s in v.split(",") if s.strip()]
        return list(v) if v else ["openid", "email", "profile"]

    @field_validator("api_keys", mode="before")
    @classmethod
    def _parse_keys(cls, v: Any) -> list[str]:
        if isinstance(v, str):
            return [k.strip() for k in v.split(",") if k.strip()]
        return list(v) if v else []

    @field_validator("vc_trusted_issuers", mode="before")
    @classmethod
    def _parse_vc_trusted_issuers(cls, v: Any) -> list[str]:
        if isinstance(v, str):
            return [i.strip() for i in v.split(",") if i.strip()]
        return list(v) if v else []

    @field_validator("allowed_origins", mode="before")
    @classmethod
    def _parse_origins(cls, v: Any) -> list[str]:
        if isinstance(v, str):
            return [o.strip() for o in v.split(",") if o.strip()]
        return list(v) if v else []

    @field_validator("web_verification_delivery_url")
    @classmethod
    def _verification_delivery_requires_https(cls, value: str | None) -> str | None:
        """Keep email-verification tokens off plaintext production transports."""
        if value is None:
            return None
        normalized = value.strip()
        if not normalized:
            return None
        if normalized.startswith("https://"):
            return normalized
        if normalized.startswith(("http://localhost", "http://127.0.0.1", "http://[::1]")):
            return normalized
        raise ValueError("web_verification_delivery_url must use HTTPS outside local development")

    @model_validator(mode="after")
    def _enforce_paddle_environment(self) -> Settings:
        """Keep Paddle credentials and API traffic in one explicit environment."""
        if not self.paddle_api_key:
            return self
        if self.paddle_env is None:
            raise ValueError(
                "WHITEPACT_PADDLE_ENV must be explicitly set to sandbox or production "
                "when WHITEPACT_PADDLE_API_KEY is configured."
            )
        api_key = self.paddle_api_key.strip()
        if self.paddle_env == "sandbox" and api_key.startswith("pdl_live_"):
            raise ValueError("Paddle API credential does not match sandbox environment.")
        if self.paddle_env == "production" and api_key.startswith("pdl_sdbx_"):
            raise ValueError("Paddle API credential does not match production environment.")
        return self

    @model_validator(mode="after")
    def _enforce_production_database(self) -> Settings:
        """Fail closed if production environment is configured without a valid database URL,
        and validate conflicts across database URL environment variables."""
        # Detect multiple different database URLs configured simultaneously
        db_vars: dict[str, str] = {}
        for key in ("WHITEPACT_DATABASE_URL", "DATABASE_URL", "RAI_DATABASE_URL"):
            for env_k, env_v in os.environ.items():
                if env_k.upper() == key and env_v:
                    db_vars[key] = env_v
                    break

        unique_urls = set(db_vars.values())
        if len(unique_urls) > 1:
            configured_names = ", ".join(db_vars)
            conflict_msg = (
                f"Conflicting database URLs configured simultaneously in: {configured_names}. "
                "Canonical precedence selected the highest-priority variable."
            )
            if self.environment.lower() in {"production", "prod"}:
                raise ValueError(
                    f"{conflict_msg} Multiple conflicting database URLs are not allowed in production."
                )
            warnings.warn(conflict_msg, UserWarning, stacklevel=2)

        if self.environment.lower() in {"production", "prod"}:
            if not self.database_url:
                raise ValueError(
                    "Production environment requires DATABASE_URL (or WHITEPACT_DATABASE_URL / RAI_DATABASE_URL). "
                    "Refusing to fall back to SQLite in production."
                )
            if not self.database_url.startswith(("postgresql://", "postgresql+asyncpg://")):
                raise ValueError(
                    f"Production environment requires a PostgreSQL database URL, got: {self.database_url.split('://')[0]}://"
                )
            from responsibleai.db.encryption import field_encryption_is_configured

            if not field_encryption_is_configured():
                raise ValueError(
                    "Production environment requires WHITEPACT_FIELD_ENCRYPTION_KEY "
                    "or RAI_FIELD_ENCRYPTION_KEY. MFA seeds, webhook HMAC secrets, "
                    "upstream auth tokens, and approval arguments use EncryptedString "
                    "and must not start in plaintext."
                )
            from responsibleai.runtime.gate import refuse_production_phase7a

            refuse_production_phase7a(
                environment=self.environment,
                enabled=self.phase7a_dispatcher_enabled,
            )
        return self

    @property
    def otel_headers_dict(self) -> dict[str, str]:
        if not self.otel_headers:
            return {}
        result: dict[str, str] = {}
        for pair in self.otel_headers.split(","):
            if "=" in pair:
                k, _, v = pair.strip().partition("=")
                result[k.strip()] = v.strip()
        return result

    @property
    def effective_db_url(self) -> str:
        """Postgres URL if set, else derive SQLite URL from db_path."""
        return self.database_url or self.db_path

    @property
    def db_dir(self) -> Path:
        p = Path(self.db_path)
        if p.name == ":memory:":
            return Path(".")
        return p.parent


def multi_replica_problems(db_backend: str, rate_limit_backend: str) -> list[str]:
    """Return a human-readable problem per backend that can't safely be
    shared across more than one replica of this process. Empty list means
    the current db_backend/rate_limit_backend combination is multi-replica
    safe. Pure function (no I/O) specifically so the startup readiness
    check in dashboard/app.py's lifespan is unit-testable without booting
    a real app instance.
    """
    problems = []
    if db_backend != "postgresql":
        problems.append(
            "SQLite is a single-file database — concurrent writes from "
            "multiple replicas will serialize and can corrupt under load. "
            "Set RAI_DATABASE_URL to a shared PostgreSQL instance."
        )
    if rate_limit_backend != "redis":
        problems.append(
            "In-memory rate limiting is per-process — each replica "
            "enforces its own separate counter, so the real aggregate "
            "rate limit silently becomes (limit × replica count), not "
            "the configured limit. Set RAI_REDIS_URL to share counters "
            "across replicas."
        )
    return problems


_settings: Settings | None = None


def warn_deprecated_env_vars(environ: dict[str, str] | None = None) -> list[str]:
    """Warn once per legacy RAI_ variable that's actually in effect (its
    WHITEPACT_ counterpart is absent, so RAI_ is the value being used, not
    silently overridden). Returns the list of legacy variable names found,
    mainly so tests can assert on it without parsing warning output.

    Scoped to `Settings`'s real field names rather than a blind scan for
    any RAI_-prefixed key in the environment — an unrelated variable that
    happens to start with RAI_ but doesn't map to an actual setting
    (typo, or something else entirely) isn't "a legacy variable being
    used to satisfy a setting," so it shouldn't warn as one.

    Uses `warnings.warn` rather than the structlog-based app logger
    deliberately: config.py has no dependency today on
    `dashboard.logging_config`, and this must run correctly during
    `get_settings()`'s very first call, which can happen before
    `configure_logging()` has run. `warnings.warn`'s default handler
    writes to stderr -- satisfying MIGRATION_WHITEPACT_V2.md Section 4's
    "never stdout" requirement (stdout is the MCP stdio transport in the
    `whitepact-mcp` process) -- without depending on logging setup order.
    """
    env = environ if environ is not None else os.environ
    env_upper = {k.upper() for k in env}
    found: list[str] = []
    for field_name in Settings.model_fields:
        suffix = field_name.upper()
        legacy_key = LEGACY_ENV_PREFIX + suffix
        whitepact_key = WHITEPACT_ENV_PREFIX + suffix
        if legacy_key in env_upper and whitepact_key not in env_upper:
            found.append(legacy_key)
            warnings.warn(
                f"{legacy_key} is a deprecated environment variable name. "
                f"Use {whitepact_key} instead — see MIGRATION_WHITEPACT_V2.md. "
                f"{legacy_key} will keep working for the full v2.x series.",
                DeprecationWarning,
                stacklevel=2,
            )
    return found


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        warn_deprecated_env_vars()
        _settings = Settings()
        _ensure_db_dir(_settings)
    return _settings


def _ensure_db_dir(s: Settings) -> None:
    if s.db_path != ":memory:":
        Path(s.db_path).parent.mkdir(parents=True, exist_ok=True)
