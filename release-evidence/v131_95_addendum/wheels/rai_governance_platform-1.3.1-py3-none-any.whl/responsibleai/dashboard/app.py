# Copyright (c) 2026 Guruprasath Annadurai
# SPDX-License-Identifier: MIT
"""Governance Dashboard — production FastAPI application (v1.0.0)."""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import time
from contextlib import asynccontextmanager
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Literal, TypeVar
from urllib.parse import quote

from fastapi import Depends, FastAPI, HTTPException, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import (
    HTMLResponse,
    JSONResponse,
    PlainTextResponse,
    RedirectResponse,
    Response,
)
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, EmailStr, Field, field_validator
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.util import get_remote_address
from starlette.middleware.base import BaseHTTPMiddleware

from responsibleai import __version__
from responsibleai.auth import mfa
from responsibleai.auth.crypto_policy import validate_webhook_secret
from responsibleai.auth.oidc import OIDCProvider
from responsibleai.auth.saml import (
    SAMLConfig,
    SAMLError,
    build_authn_request,
    build_sp_metadata,
    mint_session_token,
    parse_and_validate_response,
    peek_in_response_to,
    validate_session_token,
)
from responsibleai.billing import (
    PADDLE_SUBSCRIPTION_ENTITLEMENT_EVENTS,
    PaddleBillingError,
    PaddleBillingService,
    PaddleCheckoutRequest,
    PaddleNotConfiguredError,
    StripeBillingError,
    StripeNotConfiguredError,
    StripeService,
)
from responsibleai.compliance.engine import ComplianceEngine
from responsibleai.cost.analyzer import CostAnalyzer
from responsibleai.cost.models import BudgetPolicy, TokenUsage
from responsibleai.cost.router import ModelRouter
from responsibleai.dashboard.config import get_settings, multi_replica_problems
from responsibleai.dashboard.logging_config import configure_logging, get_logger
from responsibleai.dashboard.middleware import (
    AuthFailureLimiter,
    MaxBodySizeMiddleware,
    RequestIDMiddleware,
    RequestLoggingMiddleware,
    RestoreReadinessMiddleware,
    SecurityHeadersMiddleware,
    global_exception_handler,
    http_exception_handler,
)
from responsibleai.dashboard.plan_rate_limiter import PlanRateLimiter
from responsibleai.dashboard.prometheus import (
    get_metrics_output,
    observe_cost,
    observe_drift_alert,
    observe_governance_approval,
    observe_guardrail,
    observe_trust_score,
    observe_webhook_delivery,
    observe_websocket_connections,
)
from responsibleai.dashboard.saml_transactions import (
    DurableSamlAuthnStore,
    SamlTransactionUnavailableError,
)
from responsibleai.dashboard.signup_guard import (
    SignupRateWindow,
    dwell_time_ok,
    is_disposable_email_domain,
)
from responsibleai.dashboard.telemetry import (
    record_cost,
    record_evaluation,
    record_guardrail_scan,
    setup_telemetry,
)
from responsibleai.dashboard.transactional_email import (
    AuthenticatedWebhookEmailProvider,
    EmailDeliveryError,
    invitation_email,
    password_reset_email,
    verification_email,
)
from responsibleai.dashboard.web_governance_contracts import (
    CHAIN_INTEGRITY_NOTE,
    KNOWN_SUCCESS_MESSAGE,
    UNKNOWN_EXECUTION_MESSAGE,
    approval_detail_payload,
    web_execution_payload,
)
from responsibleai.dashboard.websocket_manager import ConnectionManager
from responsibleai.data_governance.legal_hold import LegalHoldActiveError
from responsibleai.db import (
    AlreadyVotedError,
    ApprovalActionMismatchError,
    ApprovalAlreadyResolvedError,
    ApprovalExpiredError,
    ApprovalNotApprovedError,
    ApprovalNotFoundError,
    ApprovalRepository,
    AuditRepository,
    AuthorityPassportNotFoundError,
    AuthorityPassportRepository,
    BillingEventRepository,
    CostRepository,
    CredentialIssuanceRepository,
    DelegationEscalationError,
    DelegationRepository,
    DuplicateWebUserError,
    EvalRepository,
    EvidenceRepository,
    IncidentRepository,
    IntentContractRepository,
    InvitationError,
    LeaderboardRepository,
    McpUsageRepository,
    OrgAuthorityCeilingRepository,
    OrgAutonomyBudgetRepository,
    OrgRepository,
    OutcomeRepository,
    PaddleBillingEventRepository,
    PassportRepository,
    PolicyRepository,
    PolicyRuleNotFoundError,
    PublicIncidentRepository,
    SelfApprovalError,
    SoleOwnerError,
    SSORequiredError,
    ToolTrustRepository,
    TrustRepository,
    UpstreamServerNotFoundError,
    UpstreamServerRepository,
    WebhookConfigRepository,
    WebhookDeliveryRepository,
    WebIdentityRepository,
    WebPrincipal,
    WorkflowRuleAlreadyExistsError,
    WorkflowRuleNotFoundError,
    WorkflowRuleRepository,
    create_engine,
)
from responsibleai.db.consent_proof_repository import ConsentProofRepository
from responsibleai.db.engine import DatabaseEngine
from responsibleai.db.execution_nonce_repository import ExecutionNonceRepository
from responsibleai.db.migrate import MigrationError, run_migrations_or_raise
from responsibleai.db.revocation_epoch_repository import RevocationEpochRepository
from responsibleai.db.root_authority_repository import RootAuthorityRepository
from responsibleai.enterprise.router import router as enterprise_router
from responsibleai.enterprise.security.rate_limit import DurableIdentityRateLimiter
from responsibleai.enterprise.security.router import router as enterprise_security_router
from responsibleai.eval import (
    BenchmarkRunner,
    BenchmarkSuite,
    DatasetBiasScanner,
    EvalPrompt,
    ModelComparator,
    ModelResponse,
    RegressionDetector,
)
from responsibleai.governance.approval import ApprovalStatus
from responsibleai.governance.attestation import build_attestation_record
from responsibleai.governance.authority_passport import (
    build_authority_passport_from_ceiling,
    build_authority_passport_from_delegation,
    verify_passport,
)
from responsibleai.governance.authority_resolver import AuthorityResolver
from responsibleai.governance.autonomy_budget import AutonomyBudgetPolicy
from responsibleai.governance.ceiling import OrgAuthorityCeiling
from responsibleai.governance.evidence_bundle import build_evidence_bundle, verify_evidence_bundle
from responsibleai.governance.gateway import WhitePactRuntimeGateway
from responsibleai.governance.intent import build_intent_contract
from responsibleai.governance.models import GovernanceDecision
from responsibleai.governance.outcome import OutcomeStatus, build_outcome_record
from responsibleai.governance.policy import PolicyRule
from responsibleai.governance.risk import RiskTier
from responsibleai.governance.synthetic_counter import (
    SYNTHETIC_COUNTER_TOOL,
)
from responsibleai.governance.synthetic_counter import (
    snapshot as counter_snapshot,
)
from responsibleai.governance.tool_trust import (
    ToolTrustTier,
    apply_admin_override,
    compute_trust_score,
    unscanned_score,
)
from responsibleai.governance.upstream import UnsafeUpstreamServerURLError
from responsibleai.governance.upstream_discovery import discover_upstream_tools
from responsibleai.governance.upstream_executor import (
    UpstreamMCPExecutor,
    UpstreamServerNotAvailableError,
)
from responsibleai.governance.workflow import WorkflowSequenceRule
from responsibleai.guardrails.engine import GuardrailsEngine
from responsibleai.hallucination.detector import HallucinationDetector
from responsibleai.iam.enums import PrivilegeRiskTier, StepUpMethod
from responsibleai.iam.errors import (
    StepUpRequiredError,
    StepUpVerificationFailedError,
)
from responsibleai.iam.models import StepUpProof
from responsibleai.iam.step_up import StepUpVerifier
from responsibleai.incidents.logic import build_incident_record
from responsibleai.integrations.client import TrustClient
from responsibleai.leaderboard.models import METHODOLOGY_VERSION
from responsibleai.leaderboard.providers import ProviderNotConfiguredError, get_adapter
from responsibleai.leaderboard.runner import LeaderboardRunner
from responsibleai.mcp.governance_integration import (
    ApprovalAuthorizationDeniedError,
    GovernanceServices,
    apply_governance,
    resume_approval,
)
from responsibleai.mcp.licensing import monthly_quota, plan_catalog
from responsibleai.mcp.upstream_dispatch import apply_upstream_governance
from responsibleai.rbac import (
    AuditEntry,
    OrgContext,
    Plan,
    Role,
    has_permission,
    has_plan,
    role_from_str,
)
from responsibleai.redteam.simulator import RedTeamSimulator
from responsibleai.sovereign.api_deps import bind_sovereign_engine, bind_web_identity_repository
from responsibleai.sovereign.router import router as sovereign_router
from responsibleai.sovereign.router import web_router as sovereign_web_router
from responsibleai.supplychain import McpServerManifest, McpToolDescriptor, SupplyChainScanner
from responsibleai.trust.badge import render_badge_svg
from responsibleai.trust.passport import PassportGenerator
from responsibleai.trust.score import TrustScoreEngine
from responsibleai.webhooks import (
    UnsafeWebhookURLError,
    WebhookConfig,
    WebhookEvent,
    WebhookManager,
    WebhookProvider,
    validate_webhook_url,
)

_START_TIME = time.monotonic()
_REQUEST_COUNTER: dict[str, int] = {"total": 0, "errors": 0}

settings = get_settings()
configure_logging(level=settings.log_level, json_logs=settings.log_json)
logger = get_logger("app")

# ── Per-org rate limiter ───────────────────────────────────────────────────────


def _get_rate_limit_key(request: Request) -> str:
    """Rate limit by API key (per org / per key) when present, IP address otherwise.

    Using the API key as the bucket key means each organisation gets its own
    quota rather than sharing a pool with all other tenants on the same IP
    (common in cloud-hosted or NAT environments).
    """
    import hashlib as _hashlib

    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        token = auth[7:].strip()
        if token:
            return "key:" + _hashlib.sha256(token.encode()).hexdigest()[:24]
    return get_remote_address(request)


_limiter_kwargs: dict[str, Any] = {
    "key_func": _get_rate_limit_key,
    "default_limits": [settings.rate_limit_default],
}
if settings.redis_url:
    _limiter_kwargs["storage_uri"] = settings.redis_url

limiter = Limiter(**_limiter_kwargs)

# IP-keyed protection against credential guessing across changing Bearer tokens.
# Production attaches DurableIdentityRateLimiter (identity_rate_counters) —
# the same atomic table as Layer 2 identity security, not a second authority.
# Generic slowapi per-route limits remain convenience padding only.
_auth_failure_limiter = AuthFailureLimiter(max_failures=20, window_seconds=60.0)

# Site-wide cap on self-serve signups, independent of per-IP rate
# limiting — see signup_guard.py's own docstring for why and its
# honest single-process scope.
_signup_window = SignupRateWindow(max_per_window=30, window_seconds=3600.0)

# ── Audit log org/key attribution ──────────────────────────────────────────────
# Deliberately NOT a ContextVar: AuditLogMiddleware is a BaseHTTPMiddleware,
# and Starlette runs the downstream app (including every dependency, e.g.
# get_org_context below) in a separate task via its internal task group so
# StreamingResponse/background-task support works correctly. A ContextVar
# set inside that inner task does not propagate back to the middleware's
# own scope after `call_next()` returns — its mutations are invisible one
# task boundary up, so every audit entry silently recorded org_id=None
# regardless of the real caller. `request.state` sidesteps this because
# it's an attribute on the same `Request` object instance shared across
# that task boundary, not a per-task context var — see AuditLogMiddleware
# and get_org_context below for where it's read/written.

# ── Module singletons ──────────────────────────────────────────────────────────
_trust_engine: TrustScoreEngine | None = None
_passport_gen: PassportGenerator | None = None
_passport_repo: PassportRepository | None = None
_public_incident_repo: PublicIncidentRepository | None = None
_guardrails: GuardrailsEngine | None = None
_hallucination: HallucinationDetector | None = None
_compliance: ComplianceEngine | None = None
_cost_repo: CostRepository | None = None
_cost_analyzer: CostAnalyzer | None = None
_router: ModelRouter | None = None
_trust_repo: TrustRepository | None = None
_org_repo: OrgRepository | None = None
_web_identity_repo: WebIdentityRepository | None = None
_audit_repo: AuditRepository | None = None
_incident_repo: IncidentRepository | None = None
_leaderboard_repo: LeaderboardRepository | None = None
_leaderboard_runner: LeaderboardRunner | None = None
_mcp_usage_repo: McpUsageRepository | None = None
_evidence_repo: EvidenceRepository | None = None
_approval_repo: ApprovalRepository | None = None
_ceiling_repo: OrgAuthorityCeilingRepository | None = None
_autonomy_budget_repo: OrgAutonomyBudgetRepository | None = None
_workflow_rule_repo: WorkflowRuleRepository | None = None
_delegation_repo: DelegationRepository | None = None
_policy_repo: PolicyRepository | None = None
_upstream_registry: UpstreamServerRepository | None = None
_tool_trust_repo: ToolTrustRepository | None = None
_credential_issuance_repo: CredentialIssuanceRepository | None = None
_outcome_repo: OutcomeRepository | None = None
_intent_repo: IntentContractRepository | None = None
_authority_passport_repo: AuthorityPassportRepository | None = None
_upstream_gateway: WhitePactRuntimeGateway = WhitePactRuntimeGateway()
_db_engine: DatabaseEngine | None = None
_ws_manager: ConnectionManager = ConnectionManager()
_webhook_manager: WebhookManager = WebhookManager()
_supplychain_scanner: SupplyChainScanner = SupplyChainScanner()
_eval_repo: EvalRepository | None = None
_comparator: ModelComparator | None = None
_benchmark_runner: BenchmarkRunner | None = None
_regression_detector: RegressionDetector = RegressionDetector()
_dataset_scanner: DatasetBiasScanner | None = None
_oidc_provider: OIDCProvider | None = None
_saml_config: SAMLConfig | None = None
_saml_txn_store: DurableSamlAuthnStore | None = None
_SAML_REQUEST_TTL = 300.0  # seconds — matches OIDC's state window
_stripe_service: StripeService | None = None
_paddle_billing_service: PaddleBillingService | None = None
_billing_event_repo: BillingEventRepository | None = None
_paddle_event_repo: PaddleBillingEventRepository | None = None
_plan_rate_limiter: PlanRateLimiter | None = None
_pending_audit_writes: set[asyncio.Task[Any]] = set()

_T = TypeVar("_T")


def _ready(value: _T | None) -> _T:
    """Narrow a lifespan-initialized singleton for type checkers.

    These singletons are always assigned during the `lifespan` startup phase
    before any route can receive traffic. A None here means a route ran
    before startup completed — a programming/wiring error, not a runtime
    condition callers should handle gracefully.
    """
    assert value is not None, "accessed before application startup completed"
    return value


@asynccontextmanager
async def lifespan(application: FastAPI):
    global _trust_engine, _passport_gen, _guardrails, _hallucination
    global _compliance, _cost_repo, _cost_analyzer, _router, _trust_repo
    global \
        _org_repo, \
        _web_identity_repo, \
        _audit_repo, \
        _incident_repo, \
        _leaderboard_repo, \
        _leaderboard_runner
    global _passport_repo, _public_incident_repo, _db_engine, _mcp_usage_repo
    global _evidence_repo, _approval_repo, _policy_repo, _upstream_registry, _ceiling_repo
    global _tool_trust_repo, _credential_issuance_repo, _outcome_repo
    global _workflow_rule_repo, _delegation_repo, _autonomy_budget_repo, _intent_repo
    global _authority_passport_repo
    global _eval_repo, _comparator, _benchmark_runner, _dataset_scanner
    global \
        _oidc_provider, \
        _saml_config, \
        _saml_txn_store, \
        _stripe_service, \
        _paddle_billing_service, \
        _plan_rate_limiter, \
        _billing_event_repo, \
        _paddle_event_repo

    from responsibleai.enterprise.preflight import assert_hosted_enterprise_boot_safe

    assert_hosted_enterprise_boot_safe(settings)

    setup_telemetry(
        service_name=settings.otel_service_name,
        otlp_endpoint=settings.otel_endpoint,
        otlp_headers=settings.otel_headers_dict,
    )

    if settings.auto_migrate:
        try:
            await run_migrations_or_raise(settings.effective_db_url)
        except MigrationError as exc:
            logger.error("db_migration_failed", error=str(exc))
            raise RuntimeError(
                "Startup aborted: database migrations failed. Fix the "
                "underlying issue (see log above) or set RAI_AUTO_MIGRATE=false "
                "and run `alembic upgrade head` manually. Refusing to serve "
                "traffic against a schema that may be missing columns the "
                "code expects."
            ) from exc

    _db_engine = create_engine(settings.effective_db_url)
    # Production: Alembic owns the schema; never metadata.create_all.
    # Non-prod SQLite: create_all remains the test/dev convenience path.
    # PostgreSQL with auto_migrate=False: migrations were applied out of band
    # (real-PG tests call run_migrations_or_raise first). Repeating create_all
    # inspects every mapped table against information_schema and can exceed
    # ASGI lifespan's default 5s startup bound under concurrent PG load.
    # Issuance policy, webhook fail-closed, and Gate B are unchanged.
    auto_create_tables = (not settings.is_production) and not (
        (not settings.auto_migrate) and str(settings.effective_db_url).startswith("postgresql")
    )
    await _db_engine.init(auto_create_tables=auto_create_tables)
    from responsibleai.governance.synthetic_counter import bind_counter_engine

    bind_counter_engine(_db_engine)
    bind_sovereign_engine(_db_engine)
    _plan_rate_limiter = PlanRateLimiter(redis_url=settings.redis_url)
    _auth_failure_limiter.attach_durable(
        DurableIdentityRateLimiter(_db_engine),
        require_durable=settings.is_production,
    )
    _saml_txn_store = DurableSamlAuthnStore(_db_engine)
    if settings.is_production and settings.saml_idp_entity_id:
        db_url = str(settings.effective_db_url)
        if ":memory:" in db_url:
            raise RuntimeError(
                "Production SAML requires a durable shared database; "
                "in-memory SQLite is not multi-replica safe."
            )

    policy = BudgetPolicy(monthly_limit_usd=settings.monthly_budget_usd)
    _cost_repo = CostRepository(_db_engine, policy=policy)
    _trust_repo = TrustRepository(_db_engine, alert_threshold=settings.alert_threshold)
    _org_repo = OrgRepository(_db_engine)
    _billing_event_repo = BillingEventRepository(_db_engine)
    _paddle_event_repo = PaddleBillingEventRepository(_db_engine)
    _web_identity_repo = WebIdentityRepository(_db_engine)
    bind_web_identity_repository(_web_identity_repo)
    from responsibleai.enterprise.runtime import configure_enterprise

    configure_enterprise(_db_engine)
    _audit_repo = AuditRepository(_db_engine)
    _incident_repo = IncidentRepository(_db_engine)
    _leaderboard_repo = LeaderboardRepository(_db_engine)
    _leaderboard_runner = LeaderboardRunner()
    _mcp_usage_repo = McpUsageRepository(_db_engine)
    _trust_engine = TrustScoreEngine()
    _passport_gen = PassportGenerator()
    _passport_repo = PassportRepository(_db_engine)
    _public_incident_repo = PublicIncidentRepository(_db_engine)
    _evidence_repo = EvidenceRepository(_db_engine)
    _approval_repo = ApprovalRepository(_db_engine)
    _policy_repo = PolicyRepository(_db_engine)
    _upstream_registry = UpstreamServerRepository(_db_engine)
    _tool_trust_repo = ToolTrustRepository(_db_engine)
    _credential_issuance_repo = CredentialIssuanceRepository(_db_engine)
    _outcome_repo = OutcomeRepository(_db_engine)
    _ceiling_repo = OrgAuthorityCeilingRepository(_db_engine)
    _workflow_rule_repo = WorkflowRuleRepository(_db_engine)
    _delegation_repo = DelegationRepository(_db_engine)
    _autonomy_budget_repo = OrgAutonomyBudgetRepository(_db_engine)
    _intent_repo = IntentContractRepository(_db_engine)
    _authority_passport_repo = AuthorityPassportRepository(_db_engine)
    _guardrails = GuardrailsEngine()
    _hallucination = HallucinationDetector()
    _compliance = ComplianceEngine()
    _cost_analyzer = CostAnalyzer()
    _router = ModelRouter()
    _eval_repo = EvalRepository(_db_engine)
    _comparator = ModelComparator(
        trust_engine=_trust_engine,
        guardrails=_guardrails,
        hallucination=_hallucination,
    )
    _benchmark_runner = BenchmarkRunner(guardrails=_guardrails)
    _dataset_scanner = DatasetBiasScanner(guardrails=_guardrails)

    if settings.oidc_issuer:
        _oidc_provider = OIDCProvider(
            issuer=settings.oidc_issuer,
            client_id=settings.oidc_client_id,
            jwks_uri=settings.oidc_jwks_uri,
            skip_verification=settings.oidc_skip_verification,
        )

    if settings.saml_idp_entity_id:
        if not settings.saml_session_secret:
            raise RuntimeError(
                "RAI_SAML_SESSION_SECRET must be set when RAI_SAML_IDP_ENTITY_ID is "
                "configured — generate one with: "
                'python -c "import secrets; print(secrets.token_urlsafe(32))"'
            )
        _saml_config = SAMLConfig(
            idp_entity_id=settings.saml_idp_entity_id,
            idp_sso_url=settings.saml_idp_sso_url,
            idp_x509_cert=settings.saml_idp_x509_cert,
            sp_entity_id=settings.saml_sp_entity_id,
            acs_url=settings.saml_acs_url,
            session_secret=settings.saml_session_secret,
        )

    if settings.paddle_api_key:
        try:
            _paddle_billing_service = PaddleBillingService(
                api_key=settings.paddle_api_key,
                price_ids={
                    Plan.PRO: settings.paddle_price_id_pro or "",
                    Plan.ENTERPRISE: settings.paddle_price_id_enterprise or "",
                },
                environment=settings.paddle_env,
            )
        except PaddleNotConfiguredError as exc:
            logger.warning("paddle_billing_init_skipped", reason=str(exc))

    if settings.stripe_secret_key and not settings.is_production:
        try:
            _stripe_service = StripeService(
                secret_key=settings.stripe_secret_key,
                webhook_secret=settings.stripe_webhook_secret,
                price_ids={
                    Plan.PRO: settings.stripe_price_id_pro or "",
                    Plan.ENTERPRISE: settings.stripe_price_id_enterprise or "",
                },
            )
        except StripeNotConfiguredError as exc:
            logger.warning("stripe_init_skipped", reason=str(exc))
    elif settings.stripe_secret_key and settings.is_production:
        logger.warning(
            "stripe_checkout_disabled_in_production",
            reason="Production checkout uses Paddle; Stripe keys are ignored.",
        )

    # Attach DB-backed delivery log + start persistent retry worker
    _webhook_delivery_repo = WebhookDeliveryRepository(_db_engine)
    _webhook_manager.set_repository(_webhook_delivery_repo)
    # Attach DB-backed config storage and reload any previously registered
    # webhooks — without this they only ever lived in memory and vanished
    # on every restart (see db/webhook_repository.py:WebhookConfigRepository).
    _webhook_config_repo = WebhookConfigRepository(_db_engine)
    _webhook_manager.set_config_repository(_webhook_config_repo)
    loaded_webhooks = await _webhook_manager.load_configs()
    _webhook_manager.start_retry_worker()

    _ws_manager.start()

    auth_status = "enabled" if (settings.auth_enabled and settings.api_keys) else "disabled"
    db_backend = (
        "postgresql" if (settings.database_url or "").startswith("postgresql") else "sqlite"
    )
    rl_backend = "redis" if settings.redis_url else "memory"
    logger.info(
        "startup_complete",
        version=__version__,
        db_backend=db_backend,
        rate_limit_backend=rl_backend,
        otel=bool(settings.otel_endpoint),
        auth=auth_status,
        webhooks_loaded=loaded_webhooks,
    )

    if settings.multi_replica:
        problems = multi_replica_problems(db_backend, rl_backend)
        if problems:
            logger.warning(
                "multi_replica_misconfigured",
                replica_declared=True,
                problems=problems,
                guidance=(
                    "RAI_MULTI_REPLICA=true was set but this instance's "
                    "backends can't safely be shared across replicas. See "
                    "DEPLOY_RUNBOOK.md's multi-region/HA section."
                ),
            )

    yield

    _webhook_manager.stop_retry_worker()
    _ws_manager.stop()
    if _plan_rate_limiter:
        await _plan_rate_limiter.close()
    if _pending_audit_writes:
        # Drain fire-and-forget audit writes before the engine (and this
        # event loop) go away — see AuditLogMiddleware's docstring.
        await asyncio.gather(*_pending_audit_writes, return_exceptions=True)
    if _db_engine:
        await _db_engine.close()
    _auth_failure_limiter.detach_durable()
    _saml_txn_store = None
    logger.info("shutdown_complete")


# ── App ────────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="ResponsibleAI Governance Platform",
    description=(
        "Enterprise AI Governance API — Trust Scoring, Compliance, Guardrails, "
        "Hallucination Detection, Red Team, Cost Intelligence, Drift Monitoring, "
        "WebSocket live dashboard, Webhooks, Prometheus metrics, "
        "Multi-tenant RBAC, Org management, Audit log, "
        "Model Evaluation Framework (A/B compare, benchmarks, regression, dataset scan), "
        "Single Sign-On (OAuth2/OIDC), versioned stable API."
    ),
    version="1.1.0",
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
    contact={"name": "Guruprasath Annadurai", "email": "annaduraiguruprasath7@gmail.com"},
    license_info={"name": "MIT"},
)

app.include_router(enterprise_router)
app.include_router(enterprise_security_router)
app.include_router(sovereign_router)
app.include_router(sovereign_web_router)


# ── Audit log middleware ───────────────────────────────────────────────────────


class AuditLogMiddleware(BaseHTTPMiddleware):
    """Capture every HTTP request as an audit log entry.

    - Skips /metrics and /static (noise)
    - Reads request.state.audit_org_id/audit_key_id, set by get_org_context
      (the auth dependency) — deliberately request.state, not a ContextVar,
      since BaseHTTPMiddleware runs the downstream app in a separate task
      and a ContextVar set there doesn't propagate back to this scope.
    - Writes to DB non-blockingly (asyncio.ensure_future), but the task is
      tracked in _pending_audit_writes and drained during shutdown -- an
      untracked fire-and-forget task can still be running (or queued on
      aiosqlite's background worker thread) when the app's event loop
      closes, which surfaces as "Cannot operate on a closed database" /
      "Event loop is closed" from a thread trying to signal completion
      back to a loop that no longer exists. Real, previously-latent bug:
      rare under normal request volume, reliable under the fast
      request-then-shutdown cycle every test in the suite performs.
    """

    async def dispatch(self, request: Request, call_next: Any) -> Any:
        start = time.monotonic()

        response = await call_next(request)

        path = request.url.path
        if (
            path.startswith("/static")
            or path == "/metrics"
            or path.endswith("/webhook")
            or "/identity/verification/webhook" in path
        ):
            return response

        duration_ms = round((time.monotonic() - start) * 1000, 2)

        if _audit_repo:
            entry = AuditEntry(
                endpoint=path,
                method=request.method,
                timestamp=datetime.now(UTC).isoformat(),
                org_id=getattr(request.state, "audit_org_id", None),
                key_id=getattr(request.state, "audit_key_id", None),
                status_code=response.status_code,
                ip_address=request.client.host if request.client else None,
                request_id=getattr(request.state, "request_id", None),
                duration_ms=duration_ms,
                user_agent=(request.headers.get("user-agent", "")[:512] or None),
            )
            # Non-blocking write — don't delay the response. Tracked (not a
            # bare ensure_future) so shutdown can drain it — see class
            # docstring for why an untracked task is a real bug, not just
            # defensive caution.
            task = asyncio.ensure_future(_ready(_audit_repo).write(entry))
            _pending_audit_writes.add(task)
            task.add_done_callback(_pending_audit_writes.discard)

        return response


# ── Exception handlers ─────────────────────────────────────────────────────────
# Starlette's add_exception_handler stub requires Callable[[Request, Exception], ...],
# but the standard FastAPI/Starlette convention is handlers typed to their specific
# exception class — Starlette dispatches by the registered type, so this is safe.
app.add_exception_handler(Exception, global_exception_handler)
app.add_exception_handler(HTTPException, http_exception_handler)  # type: ignore[arg-type]
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)  # type: ignore[arg-type]


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(
    request: Request, exc: RequestValidationError
) -> JSONResponse:
    # Pydantic's exc.errors() embeds the *raw* exception object in each
    # error's "ctx" field (e.g. {"ctx": {"error": ValueError(...)}}) when
    # the failure came from a @field_validator raising ValueError — not
    # JSON-serializable on its own, and json.dumps() would 500 here
    # rather than return the intended 422. jsonable_encoder() (FastAPI's
    # own recommended tool for exactly this) stringifies anything it
    # can't natively serialize, so the human-readable message still
    # reaches the client instead of the response itself crashing.
    return JSONResponse(
        status_code=422,
        content={"error": "validation_error", "detail": jsonable_encoder(exc.errors())},
    )


# ── API version header middleware ─────────────────────────────────────────────


class APIVersionMiddleware(BaseHTTPMiddleware):
    """Stamps every response with X-API-Version and routes /api/v1/* → /api/*."""

    async def dispatch(self, request: Request, call_next: Any) -> Any:
        # Transparent rewrite: /api/v1/foo → /api/foo
        path = request.url.path
        if path.startswith("/api/v1/"):
            new_path = "/api/" + path[len("/api/v1/") :]
            request.scope["path"] = new_path
            request.scope["raw_path"] = new_path.encode()

        response = await call_next(request)
        response.headers["X-API-Version"] = __version__
        response.headers["X-API-Min-Version"] = "1.0.0"
        return response


# ── Middleware (outermost first) ───────────────────────────────────────────────
origins = ["*"] if settings.allow_all_origins else settings.allowed_origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["Authorization", "Content-Type", "X-Request-ID"],
)
app.state.limiter = limiter
app.add_middleware(AuditLogMiddleware)
app.add_middleware(RestoreReadinessMiddleware)
app.add_middleware(APIVersionMiddleware)
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(RequestLoggingMiddleware)
app.add_middleware(RequestIDMiddleware)
app.add_middleware(MaxBodySizeMiddleware)

# ── Static files ───────────────────────────────────────────────────────────────
_static_dir = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=str(_static_dir)), name="static")


# ── Auth / RBAC dependencies ───────────────────────────────────────────────────


async def _resolve_oidc_context(token: str) -> OrgContext | None:
    """Validate an OIDC-issued Bearer JWT and map its claims to an OrgContext.

    Static API keys are prefixed "rai_"; anything else is attempted as a JWT
    when an OIDC provider is configured. This is what makes SSO login
    actually usable as an API credential — previously /api/auth/callback
    returned claims but nothing accepted the resulting token afterward.
    """
    if _oidc_provider is None or token.startswith("rai_"):
        return None
    try:
        claims = await _oidc_provider.validate_token(token)
    except ValueError:
        return None

    org = await _org_repo.get_org(claims.org_id) if (_org_repo and claims.org_id) else None
    role = Role.VIEWER
    for raw_role in claims.roles:
        candidate = role_from_str(raw_role)
        if candidate.value == raw_role.upper():
            role = candidate
            break

    return OrgContext(
        key_id=f"oidc:{claims.sub}",
        role=role,
        org_id=claims.org_id,
        org_name=org.name if org else None,
        is_legacy=False,
        plan=org.plan if org else Plan.FREE,
        authentication_method="oidc",
    )


async def _resolve_saml_context(token: str) -> OrgContext | None:
    """Validate a WhitePact-minted post-SAML-login session token (see
    auth/saml.py's module docstring for why this is a distinct token type
    from the OIDC-forwarded JWT above) and map it to an OrgContext.

    Cheap prefix check first (``wp_saml.``), same reasoning as the
    ``rai_`` guard above: avoid attempting the wrong validation path on
    every request when SAML isn't even configured.
    """
    if _saml_config is None or not token.startswith("wp_saml."):
        return None
    claims = validate_session_token(_saml_config, token)
    if claims is None:
        return None

    org = await _org_repo.get_org(claims.org_id) if (_org_repo and claims.org_id) else None
    role = Role.VIEWER
    for raw_role in claims.roles:
        candidate = role_from_str(raw_role)
        if candidate.value == raw_role.upper():
            role = candidate
            break

    return OrgContext(
        key_id=f"saml:{claims.sub}",
        role=role,
        org_id=claims.org_id,
        org_name=org.name if org else None,
        is_legacy=False,
        plan=org.plan if org else Plan.FREE,
        authentication_method="saml",
    )


async def _resolve_transport_identity(token: str) -> OrgContext | None:
    """Normalize a verified transport credential into canonical identity.

    This establishes identity and tenant only. Runtime authority remains the
    responsibility of ``AuthorityResolver`` in the governance hall.
    """
    if settings.api_keys and token in settings.api_keys:
        import warnings

        from responsibleai.enterprise.preflight import HostedEnterpriseSecurityError

        if settings.is_production:
            raise HostedEnterpriseSecurityError(
                "Static RAI_API_KEYS cannot authenticate production traffic."
            )
        warnings.warn(
            "RAI_API_KEYS is deprecated and restricted to non-production compatibility.",
            DeprecationWarning,
            stacklevel=2,
        )
        logger.warning("legacy_static_api_key_used")
        legacy_key_id = f"legacy:{hashlib.sha256(token.encode()).hexdigest()[:32]}"
        return OrgContext(
            key_id=legacy_key_id,
            role=Role.VIEWER,
            is_legacy=True,
            org_id=None,
            plan=Plan.FREE,
            scopes=frozenset({"legacy:compat"}),
            authentication_method="legacy_static",
        )

    oidc_ctx = await _resolve_oidc_context(token)
    if oidc_ctx is not None:
        return oidc_ctx

    saml_ctx = await _resolve_saml_context(token)
    if saml_ctx is not None:
        return saml_ctx

    if _org_repo:
        try:
            return await _ready(_org_repo).authenticate(token)
        except SSORequiredError as exc:
            sso_paths = [
                path
                for path, enabled in (("oidc", _oidc_provider), ("saml", _saml_config))
                if enabled
            ]
            raise HTTPException(
                403,
                detail=(
                    f"Organization {exc.org_id} requires SSO login. Static API keys are "
                    f"disabled — authenticate via {' or '.join(f'/api/auth/login/{path}' for path in sso_paths) or '/api/auth/login/<provider>'}."
                ),
            ) from None
    return None


async def get_org_context(request: Request) -> OrgContext:
    """Resolve the presented Bearer credential to an OrgContext.

    Resolution order:
    1. Auth disabled → anonymous OWNER (dev mode)
    2. Flat RAI_API_KEYS (legacy, non-production only) → VIEWER + legacy:compat
    3. OIDC-issued JWT (when SSO configured) → role/org from token claims
    4. DB-backed org key → role from DB, rejected if the org enforces SSO
    5. No match → 401
    """
    if not settings.auth_enabled:
        ctx = OrgContext(key_id="anon", role=Role.OWNER, is_legacy=True)
        request.state.audit_org_id = None
        request.state.audit_key_id = "anon"
        return ctx

    client_key = get_remote_address(request)
    if await _auth_failure_limiter.is_blocked(client_key):
        raise HTTPException(429, detail="Too many failed authentication attempts. Try again later.")

    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        await _auth_failure_limiter.record_failure(client_key)
        raise HTTPException(401, detail="Missing or invalid Authorization header")

    token = auth_header[7:].strip()

    context = await _resolve_transport_identity(token)
    if context is None:
        await _auth_failure_limiter.record_failure(client_key)
        raise HTTPException(401, detail="Invalid API key")
    if context.authentication_method == "legacy_static":
        _enforce_legacy_static_compat(request)
    if not context.is_legacy and _plan_rate_limiter:
        await _plan_rate_limiter.check(context.org_id, context.plan)
    _enforce_machine_scope(request, context)
    request.state.audit_org_id = context.org_id
    request.state.audit_key_id = context.key_id
    return context


def _enforce_legacy_static_compat(request: Request) -> None:
    """Non-production RAI_API_KEYS: never OWNER, never enterprise authority."""
    path = request.url.path
    method = request.method.upper()
    blocked = (
        path.startswith("/api/enterprise")
        or path.startswith("/api/v1/enterprise")
        or path.startswith("/api/web/")
        or "service-account" in path
        or path.startswith("/api/governance")
        or "execute" in path
        or "dispatch" in path
        or (method == "POST" and (path.endswith("/keys") or "/api-keys" in path))
    )
    if blocked:
        raise HTTPException(
            403,
            detail={
                "error": "LEGACY_CREDENTIAL_FORBIDDEN",
                "message": (
                    "Static RAI_API_KEYS cannot access enterprise, tenant-admin, "
                    "credential-issuance, or Phase 7A routes. Migrate to verified-principal keys."
                ),
            },
        )


def _enforce_machine_scope(request: Request, context: OrgContext) -> None:
    """Enforce scopes for dashboard-managed keys.

    Empty scopes on non-legacy org keys preserve pre-metadata fixture keys.
    Legacy static keys never have empty scopes; ``legacy:compat`` is not
    governance, evidence, or execution authority.
    """
    if context.authentication_method == "legacy_static":
        return
    if not context.scopes:
        return
    path = request.url.path
    method = request.method.upper()
    required: str | None = None
    if path.startswith("/api/governance/evidence") and method in {"GET", "HEAD"}:
        required = "evidence:read"
    elif path.startswith("/api/governance"):
        required = "governance:read" if method in {"GET", "HEAD"} else "governance:write"
    elif path.startswith("/api/agents"):
        required = "agents:read" if method in {"GET", "HEAD"} else "agents:write"
    if required and required not in context.scopes:
        raise HTTPException(403, detail=f"API key is missing required scope: {required}")


def _require_caller_owns_org(_auth: OrgContext, org_id: str) -> None:
    """Fail closed on path org_id that is not the caller's tenant.

    Returns the same 404 used elsewhere so a cross-tenant probe does not
    disclose whether the other organization exists. Legacy credentials with
    no org_id cannot satisfy this check.
    """
    if _auth.org_id != org_id:
        raise HTTPException(404, "Organization not found")


def require_role(min_role: Role):
    """FastAPI dependency factory — enforces minimum role level."""

    async def _dep(ctx: OrgContext = Depends(get_org_context)) -> OrgContext:
        if not has_permission(ctx.role, min_role):
            raise HTTPException(
                403,
                detail=f"Requires {min_role.value} role or higher. Your role: {ctx.role.value}",
            )
        return ctx

    return _dep


def require_plan(min_plan: Plan):
    """FastAPI dependency factory — enforces minimum billing plan.

    Used to gate paid content (the leaderboard diagnostic deep-dive) rather
    than an endpoint's RBAC role — a VIEWER on an ENTERPRISE org can read the
    diagnostic, an OWNER on a FREE org cannot.
    """

    async def _dep(ctx: OrgContext = Depends(get_org_context)) -> OrgContext:
        if not has_plan(ctx.plan, min_plan):
            raise HTTPException(
                402,
                detail=(
                    f"Requires {min_plan.value} plan or higher. Your plan: {ctx.plan.value}. "
                    "Upgrade at /api/v1/billing/checkout."
                ),
            )
        return ctx

    return _dep


# ── Request / Response models ──────────────────────────────────────────────────


class EvaluateRequest(BaseModel):
    model_name: str = Field(..., min_length=1, max_length=100)
    provider: str = Field(..., min_length=1, max_length=100)
    fairness: float = Field(0.75, ge=0.0, le=1.0)
    privacy: float = Field(0.80, ge=0.0, le=1.0)
    security: float = Field(0.70, ge=0.0, le=1.0)
    robustness: float = Field(0.75, ge=0.0, le=1.0)
    compliance: float = Field(0.80, ge=0.0, le=1.0)
    authenticity: float = Field(0.85, ge=0.0, le=1.0)
    use_case: str = Field("general", max_length=50)
    record_drift: bool = Field(True)


class ScanTextRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=50_000)


class AnalyzePromptRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=100_000)
    response: str = Field("", max_length=100_000)
    provider: str = Field("openai", max_length=50)
    model: str = Field("gpt-4o", max_length=100)
    monthly_requests: int = Field(10_000, ge=1, le=100_000_000)


class RouteTaskRequest(BaseModel):
    task_description: str = Field(..., min_length=1, max_length=2000)
    quality_requirement: str = Field("balanced", pattern="^(balanced|maximum|cheapest)$")


class RecordUsageRequest(BaseModel):
    provider: str = Field(..., min_length=1, max_length=50)
    model: str = Field(..., min_length=1, max_length=100)
    input_tokens: int = Field(..., ge=0, le=10_000_000)
    output_tokens: int = Field(..., ge=0, le=10_000_000)
    team: str = Field("default", max_length=100)
    application: str = Field("default", max_length=100)


class IncidentCreateRequest(BaseModel):
    incident_type: str = Field(
        "other",
        pattern="^(pii_leak|jailbreak_attempt|bias_trigger|hallucination|policy_violation|cost_overrun|drift_alert|other)$",
    )
    severity: str = Field("medium", pattern="^(critical|high|medium|low)$")
    model_name: str = Field("unknown", max_length=100)
    provider: str = Field("unknown", max_length=100)
    description: str = Field(..., min_length=1, max_length=5000)
    evidence: dict[str, Any] = Field(default_factory=dict)
    mitigated: bool = False


class LeaderboardModelRegisterRequest(BaseModel):
    model: str = Field(..., min_length=1, max_length=100)
    provider: str = Field(..., pattern="^(openai|anthropic|google|mock)$")
    display_name: str | None = Field(None, max_length=150)
    active: bool = True


class TrustIndexAssessRequest(BaseModel):
    model_name: str = Field(..., min_length=1, max_length=100)
    provider: str = Field(..., min_length=1, max_length=100)
    fairness: float = Field(0.5, ge=0.0, le=1.0)
    privacy: float = Field(0.5, ge=0.0, le=1.0)
    security: float = Field(0.5, ge=0.0, le=1.0)
    robustness: float = Field(0.5, ge=0.0, le=1.0)
    compliance: float = Field(0.5, ge=0.0, le=1.0)
    authenticity: float = Field(0.5, ge=0.0, le=1.0)


class TrustIndexCertifyRequest(BaseModel):
    certified_by: str = Field("ResponsibleAI Certification Team", max_length=200)


class IncidentReportRequest(BaseModel):
    title: str = Field(..., min_length=5, max_length=300)
    description: str = Field(..., min_length=20, max_length=10_000)
    incident_type: str = Field(
        "other",
        pattern="^(jailbreak|data_leak|harmful_output|misinformation|bias|"
        "prompt_injection|privacy_violation|safety_failure|other)$",
    )
    severity: str = Field("medium", pattern="^(critical|high|medium|low)$")
    affected_model: str = Field(..., min_length=1, max_length=100)
    affected_provider: str = Field(..., min_length=1, max_length=100)
    affected_version: str | None = Field(None, max_length=100)
    reporter_name: str | None = Field(None, max_length=200)
    reporter_contact: str | None = Field(None, max_length=200)
    evidence_urls: list[str] = Field(default_factory=list, max_length=20)
    reproduction_steps: str | None = Field(None, max_length=5000)
    tags: list[str] = Field(default_factory=list, max_length=20)


class IncidentRejectRequest(BaseModel):
    reason: str = Field(..., min_length=5, max_length=2000)


class IncidentStatusUpdateRequest(BaseModel):
    status: str = Field(..., pattern="^(PUBLISHED|DISPUTED|RESOLVED)$")


class GovernedToolCallRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    arguments: dict[str, Any] = Field(default_factory=dict)
    purpose: str = Field(..., min_length=1, max_length=2000)


class ApprovalResolveRequest(BaseModel):
    outcome: str = Field(..., pattern="^(APPROVED|DENIED)$")
    notes: str | None = Field(default=None, max_length=2000)


_POLICY_EFFECTS = (
    "ALLOW",
    "ALLOW_WITH_REDACTION",
    "DENY",
    "REQUIRE_APPROVAL",
    "QUARANTINE",
)


class PolicyRuleCreateRequest(BaseModel):
    rule_id: str = Field(..., min_length=1, max_length=100)
    reason_code: str = Field(..., min_length=1, max_length=100)
    effect: str = Field(
        ...,
        description=("Canonical policy effect. Accepted values: " + ", ".join(_POLICY_EFFECTS)),
    )

    @field_validator("effect")
    @classmethod
    def _normalize_policy_effect(cls, value: str) -> str:
        normalized = value.strip().upper()
        if normalized not in _POLICY_EFFECTS:
            raise ValueError("effect must be one of: " + ", ".join(_POLICY_EFFECTS))
        return normalized

    risk_tiers: list[str] | None = Field(default=None)
    action_types: list[str] | None = Field(default=None)
    targets: list[str] | None = Field(default=None)


class PolicyReorderRequest(BaseModel):
    rule_ids: list[str] = Field(..., min_length=1)


class WorkflowRuleCreateRequest(BaseModel):
    """See governance/workflow.py's WorkflowSequenceRule -- action_types
    is the forbidden *ordered* sequence, e.g. ["beneficiary.create",
    "payment.limit.raise", "payment.execute"]."""

    rule_id: str = Field(..., min_length=1, max_length=100)
    action_types: list[str] = Field(..., min_length=2, max_length=20)
    window_minutes: int = Field(..., ge=1, le=10_080)  # up to 7 days


class DelegationGrantRequest(BaseModel):
    """See governance/delegation.py's DelegationRecord. `from_identity_id`
    omitted (or null) means a root grant -- checked against nothing
    (there's no parent in the graph); set it to require the grant pass
    validate_attenuation() against that identity's own currently active
    delegation."""

    to_identity_id: str = Field(..., min_length=1, max_length=200)
    granted_action_types: list[str] = Field(..., min_length=1, max_length=200)
    purpose: str = Field(..., min_length=1, max_length=2000)
    from_identity_id: str | None = Field(default=None, max_length=200)
    constraints: dict[str, Any] = Field(default_factory=dict)
    require_approval_for: list[str] = Field(default_factory=list, max_length=200)
    expires_in_minutes: int | None = Field(default=None, ge=1, le=525_600)  # up to 1 year


class IntentContractDeclareRequest(BaseModel):
    """See governance/intent.py's IntentContract. Declared once per
    task; applies to every subsequent action from `agent_id` until it
    expires or a newer contract is declared for the same agent."""

    agent_id: str = Field(..., min_length=1, max_length=200)
    goal: str = Field(..., min_length=1, max_length=2000)
    max_value_usd: float | None = Field(default=None, ge=0)
    allowed_targets: list[str] | None = Field(default=None, max_length=200)
    denied_targets: list[str] | None = Field(default=None, max_length=200)
    allowed_action_types: list[str] | None = Field(default=None, max_length=200)
    expires_in_minutes: int | None = Field(default=None, ge=1, le=525_600)  # up to 1 year


class AuthorityPassportIssueRequest(BaseModel):
    """See governance/authority_passport.py's AuthorityPassport.
    `source` selects what to export: the org's current
    `OrgAuthorityCeiling` ("org_ceiling") or `principal_id`'s currently
    active `DelegationRecord` ("delegation")."""

    principal_id: str = Field(..., min_length=1, max_length=200)
    source: Literal["org_ceiling", "delegation"]
    expires_in_minutes: int | None = Field(default=None, ge=1, le=525_600)  # up to 1 year


class AuthorityPassportRevokeRequest(BaseModel):
    reason: str | None = Field(default=None, max_length=2000)


class DelegationRevokeRequest(BaseModel):
    reason: str = Field(..., min_length=1, max_length=2000)


class SupplyChainToolRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    description: str = Field(default="", max_length=5000)


class SupplyChainScanRequest(BaseModel):
    server_name: str = Field(..., min_length=1, max_length=200)
    publisher: str | None = Field(default=None, max_length=200)
    tools: list[SupplyChainToolRequest] = Field(default_factory=list, max_length=200)
    check_known_incidents: bool = Field(
        default=True,
        description="Cross-reference the public AI Incident Database. "
        "Set false to run only the offline checks (no DB query).",
    )


class UpstreamServerRegisterRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    url: str = Field(..., min_length=1, max_length=2048)
    auth_token: str | None = Field(default=None, max_length=4096)


class UpstreamToolCallRequest(BaseModel):
    tool_name: str = Field(..., min_length=1, max_length=200)
    arguments: dict[str, Any] = Field(default_factory=dict)
    purpose: str = Field(..., min_length=1, max_length=2000)


class ToolTrustOverrideRequest(BaseModel):
    tier: ToolTrustTier
    reason: str = Field(..., min_length=1, max_length=2000)


class OutcomeReportRequest(BaseModel):
    status: OutcomeStatus
    result_summary: str | None = Field(default=None, max_length=2000)


class WebhookCreateRequest(BaseModel):
    url: str = Field(..., min_length=1, max_length=2048)
    events: list[str] = Field(..., min_length=1)
    provider: str = Field("generic", pattern="^(slack|teams|pagerduty|generic)$")
    secret: str = Field("", max_length=256)
    description: str = Field("", max_length=500)
    max_retries: int = Field(3, ge=1, le=5)

    @field_validator("secret")
    @classmethod
    def _secret_meets_entropy_floor(cls, v: str) -> str:
        # Empty is fine (unsigned deliveries, an explicit choice) --
        # only a present-but-weak secret is rejected. See
        # crypto_policy.py's own docstring for the NIST SP 800-107
        # rationale behind the 32-character floor.
        validate_webhook_secret(v)
        return v


class EvalCompareRequest(BaseModel):
    model_a: str = Field(..., min_length=1, max_length=100)
    model_b: str = Field(..., min_length=1, max_length=100)
    provider_a: str = Field("unknown", max_length=50)
    provider_b: str = Field("unknown", max_length=50)
    prompts: list[dict[str, str]] = Field(..., min_length=1, max_length=50)
    responses_a: list[dict[str, str]] = Field(..., min_length=1, max_length=50)
    responses_b: list[dict[str, str]] = Field(..., min_length=1, max_length=50)


class EvalBenchmarkRequest(BaseModel):
    model: str = Field(..., min_length=1, max_length=100)
    provider: str = Field("unknown", max_length=50)
    suite: str = Field(..., pattern="^(truthfulqa|bbq|hellaswag)$")
    responses: dict[str, str] = Field(...)
    set_as_baseline: bool = Field(False)


class EvalDatasetScanRequest(BaseModel):
    texts: list[str] = Field(..., min_length=1, max_length=5000)
    filename: str = Field("upload", max_length=200)


class CreateOrgRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    slug: str = Field(..., min_length=1, max_length=100, pattern=r"^[a-z0-9\-]+$")
    monthly_budget_usd: float = Field(10_000.0, ge=0.0)


class SignupRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    slug: str = Field(..., min_length=1, max_length=100, pattern=r"^[a-z0-9\-]+$")
    email: EmailStr
    # Honeypot: rendered visually hidden on /signup — a real browser
    # never fills it, a scripted bot filling every field does.
    website: str = Field("", max_length=200)
    # Client-reported epoch-ms timestamp of when the signup page
    # rendered, used only for the minimum-dwell-time heuristic below —
    # not a security boundary (trivially spoofable), just a cheap filter
    # against unsophisticated bots that submit instantly.
    page_loaded_at_ms: int = Field(..., ge=0)


class CreateKeyRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    role: str = Field("ANALYST", pattern="^(OWNER|ADMIN|ANALYST|VIEWER)$")


class WebRegisterRequest(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=200)
    email: EmailStr
    password: str = Field(..., min_length=12, max_length=128)
    accepted_terms: bool

    @field_validator("password")
    @classmethod
    def strong_password(cls, value: str) -> str:
        if not (
            re.search(r"[a-z]", value)
            and re.search(r"[A-Z]", value)
            and re.search(r"\d", value)
            and re.search(r"[^A-Za-z0-9]", value)
        ):
            raise ValueError("Password must include upper, lower, number, and symbol")
        return value

    @field_validator("accepted_terms")
    @classmethod
    def terms_required(cls, value: bool) -> bool:
        if not value:
            raise ValueError("Terms acceptance is required")
        return value


class WebLoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=1, max_length=128)


class WebVerifyRequest(BaseModel):
    token: str = Field(..., min_length=32, max_length=256)


class WebPasswordResetRequest(BaseModel):
    email: EmailStr


class WebPasswordResetConfirmRequest(BaseModel):
    token: str = Field(..., min_length=32, max_length=256)
    password: str = Field(..., min_length=12, max_length=128)

    @field_validator("password")
    @classmethod
    def strong_password(cls, value: str) -> str:
        return WebRegisterRequest.strong_password(value)


class WebOnboardingRequest(BaseModel):
    organization_name: str = Field(..., min_length=2, max_length=200)
    website: str = Field("", max_length=2048)
    role: str = Field("", max_length=100)
    intended_use: str = Field("", max_length=1000)
    use_case: str = Field(..., min_length=2, max_length=200)
    plan: str = Field("FREE", pattern="^(FREE|DEVELOPER|PRO|BUSINESS|ENTERPRISE)$")


class WebCreateKeyRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    environment: Literal["test", "live"] = "test"
    scopes: list[str] = Field(default_factory=list, max_length=20)
    expires_at: datetime | None = None

    @field_validator("scopes")
    @classmethod
    def valid_scopes(cls, value: list[str]) -> list[str]:
        allowed = {
            "governance:read",
            "governance:write",
            "evidence:read",
            "agents:read",
            "agents:write",
        }
        unique = sorted(set(value))
        if not unique or not set(unique).issubset(allowed):
            raise ValueError("At least one valid API scope is required")
        return unique

    @field_validator("expires_at")
    @classmethod
    def timezone_required(cls, value: datetime | None) -> datetime | None:
        if value is not None and value.tzinfo is None:
            raise ValueError("API key expiration must include a timezone")
        return value


class SetSSORequest(BaseModel):
    sso_required: bool


class SetMFARequest(BaseModel):
    mfa_required: bool


class SetAuthorityCeilingRequest(BaseModel):
    """Mirrors `OrgAuthorityCeiling`'s fields directly (governance/ceiling.py)
    -- see that dataclass's docstring for what each one means. All
    fields optional/omittable; an omitted field means "no restriction
    on this dimension," not "clear whatever was set before" (`PUT`
    replaces the whole ceiling in one call, per
    `OrgAuthorityCeilingRepository.set()`'s own "replace-in-full, not
    incremental" semantics -- so submit the full desired ceiling each
    time, not a partial patch)."""

    max_value_usd: float | None = Field(None, ge=0.0)
    allowed_targets: list[str] | None = None
    denied_targets: list[str] | None = None
    max_delegation_depth: int | None = Field(None, ge=0)
    allowed_action_types: list[str] | None = None
    require_approval_for: list[str] = Field(default_factory=list)


class SetAutonomyBudgetRequest(BaseModel):
    """Mirrors `AutonomyBudgetPolicy` (governance/autonomy_budget.py).
    Unlike the authority ceiling, both fields are required -- there's
    no "all-null means unrestricted" shape here; `DELETE` is how an org
    removes the cap entirely, not `PUT` with empty fields."""

    max_autonomous_actions: int = Field(..., ge=1)
    window_minutes: int = Field(..., ge=1, le=10_080)  # up to 7 days


class MFAVerifyRequest(BaseModel):
    code: str = Field(..., min_length=6, max_length=10)


class LoginKeyRequest(BaseModel):
    api_key: str = Field(..., min_length=1, max_length=512)
    mfa_code: str | None = Field(None, max_length=10)


class CheckoutRequest(BaseModel):
    plan: str = Field(..., pattern="^(PRO|ENTERPRISE)$")
    org_email: str | None = Field(None, max_length=254)


class BillingPortalRequest(BaseModel):
    return_url: str | None = Field(None, max_length=2048)


class UpdateWebOrganizationRequest(BaseModel):
    name: str = Field(..., min_length=2, max_length=200)


class WebSwitchOrganizationRequest(BaseModel):
    organization_id: str = Field(..., min_length=36, max_length=36)


class WebInvitationCreateRequest(BaseModel):
    email: EmailStr
    role: Literal["ADMIN", "ANALYST", "VIEWER"] = "VIEWER"


class WebInvitationAcceptRequest(BaseModel):
    token: str = Field(..., min_length=32, max_length=256)


class WebMembershipRoleRequest(BaseModel):
    role: Literal["ADMIN", "ANALYST", "VIEWER"]


class WebAccountDeleteRequest(BaseModel):
    password: str = Field(..., min_length=12, max_length=128)
    confirmation: Literal["DELETE MY ACCOUNT"]


class WebOwnershipTransferRequest(BaseModel):
    new_owner_user_id: str = Field(..., min_length=36, max_length=36)
    confirmation: Literal["TRANSFER OWNERSHIP"]


def _extract_step_up_proof(
    request: Request, body_dict: dict[str, Any] | None = None
) -> StepUpProof | None:
    nonce = request.headers.get("X-Step-Up-Nonce") or request.headers.get("x-step-up-nonce")
    method_str = request.headers.get("X-Step-Up-Method") or request.headers.get("x-step-up-method")
    token_or_code = request.headers.get("X-Step-Up-Token") or request.headers.get("x-step-up-token")
    auth_time = request.headers.get("X-Step-Up-Auth-Time") or request.headers.get(
        "x-step-up-auth-time"
    )
    claims: dict[str, Any] = {}

    if body_dict and isinstance(body_dict.get("step_up_proof"), dict):
        sp = body_dict["step_up_proof"]
        nonce = nonce or sp.get("nonce")
        method_str = method_str or sp.get("method")
        token_or_code = token_or_code or sp.get("token_or_code") or sp.get("code")
        auth_time = auth_time or sp.get("auth_time")
        claims = sp.get("claims", {})

    if not nonce or not method_str:
        return None

    try:
        method = StepUpMethod(method_str)
    except ValueError:
        method = StepUpMethod.MFA_TOTP

    if not auth_time:
        auth_time = datetime.now(UTC).isoformat()

    return StepUpProof(
        nonce=nonce,
        method=method,
        auth_time=auth_time,
        token_or_code=token_or_code or "",
        claims=claims,
    )


async def _verify_web_step_up(
    request: Request,
    *,
    org_id: str,
    user_id: str,
    action: str,
    risk_tier: PrivilegeRiskTier,
    body_dict: dict[str, Any] | None = None,
) -> None:
    session_token = request.cookies.get("wp_session")
    session_id = (
        hashlib.sha256(session_token.encode("utf-8")).hexdigest() if session_token else None
    )
    proof = _extract_step_up_proof(request, body_dict)
    verifier = StepUpVerifier(_ready(_db_engine))
    try:
        await verifier.verify_and_consume_step_up(
            org_id=org_id,
            principal_id=user_id,
            action=action,
            risk_tier=risk_tier,
            proof=proof,
            session_id=session_id,
        )
    except StepUpRequiredError as exc:
        raise HTTPException(
            status_code=403,
            detail={
                "error": "step_up_required",
                "message": str(exc),
                "required_nonce": exc.required_nonce,
                "max_age_seconds": exc.max_age_seconds,
            },
        ) from exc
    except StepUpVerificationFailedError as exc:
        raise HTTPException(
            status_code=403,
            detail={
                "error": "step_up_failed",
                "message": str(exc),
            },
        ) from exc


# ── Human web identity / console API ─────────────────────────────────────────


def _web_token_hash(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def _set_web_cookies(response: Response, session_token: str, csrf_token: str) -> None:
    max_age = settings.web_session_ttl_hours * 3600
    response.set_cookie(
        "wp_session",
        session_token,
        max_age=max_age,
        httponly=True,
        secure=settings.web_session_secure,
        samesite="lax",
        path="/",
    )
    response.set_cookie(
        "wp_csrf",
        csrf_token,
        max_age=max_age,
        httponly=False,
        secure=settings.web_session_secure,
        samesite="strict",
        path="/",
    )


async def get_web_principal(request: Request) -> WebPrincipal:
    token = request.cookies.get("wp_session", "")
    principal = await _ready(_web_identity_repo).get_principal(token) if token else None
    if principal is None:
        raise HTTPException(401, "Sign in is required.")
    request.state.audit_org_id = principal.org_id
    request.state.audit_key_id = f"web:{principal.user_id}"
    return principal


async def require_web_csrf(
    request: Request, principal: WebPrincipal = Depends(get_web_principal)
) -> WebPrincipal:
    cookie_token = request.cookies.get("wp_csrf", "")
    header_token = request.headers.get("X-WP-CSRF", "")
    if not cookie_token or not header_token or not hmac.compare_digest(cookie_token, header_token):
        raise HTTPException(403, "CSRF validation failed.")
    if not hmac.compare_digest(_web_token_hash(cookie_token), principal.csrf_hash):
        raise HTTPException(403, "CSRF validation failed.")
    return principal


def _web_org_admin(principal: WebPrincipal) -> str:
    if not principal.org_id:
        raise HTTPException(409, "Complete organization onboarding first.")
    if principal.role not in {Role.OWNER, Role.ADMIN}:
        raise HTTPException(403, "Organization administrator access is required.")
    return principal.org_id


def _web_org_member(principal: WebPrincipal) -> str:
    if not principal.org_id:
        raise HTTPException(409, "Complete organization onboarding first.")
    return principal.org_id


def _web_resolver_id(principal: WebPrincipal) -> str:
    return f"web:{principal.user_id}"


async def _web_execution_identifiers(
    org_id: str, approval_id: str
) -> tuple[str | None, str | None]:
    evidence = await _ready(_evidence_repo).get_latest_for_approval(org_id, approval_id)
    if evidence is None:
        return None, None
    outcome = await _ready(_outcome_repo).get_for_org(evidence.evidence_id, org_id)
    return evidence.evidence_id, outcome.outcome_id if outcome else None


def _dashboard_governance_services() -> GovernanceServices:
    engine = _ready(_db_engine)
    return GovernanceServices(
        gateway=_upstream_gateway,
        evidence_repo=_ready(_evidence_repo),
        approval_repo=_ready(_approval_repo),
        policy_repo=_ready(_policy_repo),
        trust_client=TrustClient(),
        webhook_manager=_webhook_manager,
        ceiling_repo=_ready(_ceiling_repo),
        workflow_rule_repo=_ready(_workflow_rule_repo),
        delegation_repo=_ready(_delegation_repo),
        autonomy_budget_repo=_ready(_autonomy_budget_repo),
        outcome_repo=_ready(_outcome_repo),
        intent_repo=_ready(_intent_repo),
        nonce_repo=ExecutionNonceRepository(engine),
        epoch_repo=RevocationEpochRepository(engine),
        authority_resolver=AuthorityResolver(
            RootAuthorityRepository(engine),
            ConsentProofRepository(engine),
            _ready(_delegation_repo),
        ),
        org_repo=_ready(_org_repo),
    )


def _safe_billing_return_url(value: str | None) -> str:
    fallback = f"{settings.web_public_url.rstrip('/')}/dashboard/billing"
    if not value:
        return fallback
    from urllib.parse import urlparse

    requested = urlparse(value)
    public = urlparse(settings.web_public_url)
    if requested.scheme not in {"http", "https"} or (requested.scheme, requested.netloc) != (
        public.scheme,
        public.netloc,
    ):
        raise HTTPException(422, "Billing return URL must use the configured WhitePact origin.")
    return value


async def _deliver_verification(email: str, full_name: str, verification_url: str) -> None:
    if not settings.web_verification_delivery_url:
        return
    provider = AuthenticatedWebhookEmailProvider(
        settings.web_verification_delivery_url,
        settings.web_verification_delivery_token,
    )
    try:
        await provider.deliver(verification_email(email, full_name, verification_url))
    except EmailDeliveryError as exc:
        raise HTTPException(502, "Verification email delivery failed. Please retry later.") from exc


async def _deliver_password_reset(email: str, full_name: str, reset_url: str) -> None:
    if not settings.web_verification_delivery_url:
        return
    provider = AuthenticatedWebhookEmailProvider(
        settings.web_verification_delivery_url,
        settings.web_verification_delivery_token,
    )
    try:
        await provider.deliver(password_reset_email(email, full_name, reset_url))
    except EmailDeliveryError as exc:
        raise HTTPException(502, "Password reset delivery failed. Please retry later.") from exc


async def _deliver_invitation(email: str, organization: str, invitation_url: str) -> None:
    if not settings.web_verification_delivery_url:
        return
    provider = AuthenticatedWebhookEmailProvider(
        settings.web_verification_delivery_url,
        settings.web_verification_delivery_token,
    )
    try:
        await provider.deliver(invitation_email(email, organization, invitation_url))
    except EmailDeliveryError as exc:
        raise HTTPException(502, "Invitation delivery failed. Please retry later.") from exc


@app.post("/api/web/auth/register", tags=["web-auth"], status_code=202)
@limiter.limit("5/minute")
async def web_register(request: Request, req: WebRegisterRequest) -> dict[str, Any]:
    if not settings.web_verification_delivery_url and not settings.web_auth_dev_tokens:
        raise HTTPException(503, "Email verification delivery is not configured.")
    if is_disposable_email_domain(str(req.email)):
        raise HTTPException(422, "Use a permanent work email address.")
    if not _signup_window.allow():
        raise HTTPException(429, "Signup capacity is temporarily exhausted. Try again later.")
    try:
        _, token = await _ready(_web_identity_repo).register(
            req.full_name, str(req.email), req.password
        )
    except DuplicateWebUserError:
        # Deliberately return the same accepted shape as a new registration.
        return {"status": "verification_required"}
    verification_url = (
        f"{settings.web_public_url.rstrip('/')}/verify-email?token={quote(token, safe='')}"
    )
    await _deliver_verification(str(req.email), req.full_name, verification_url)
    result: dict[str, Any] = {"status": "verification_required"}
    if settings.web_auth_dev_tokens:
        result["verification_url"] = verification_url
    return result


@app.post("/api/web/auth/verify", tags=["web-auth"])
@limiter.limit("10/minute")
async def web_verify(request: Request, req: WebVerifyRequest) -> dict[str, str]:
    if not await _ready(_web_identity_repo).verify_email(req.token):
        raise HTTPException(400, "This verification link is invalid or expired.")
    return {"status": "verified", "next": "/login?verified=1"}


@app.post("/api/web/auth/password-reset", tags=["web-auth"], status_code=202)
@limiter.limit("5/minute")
async def web_password_reset_request(
    request: Request, req: WebPasswordResetRequest
) -> dict[str, str]:
    if not settings.web_verification_delivery_url and not settings.web_auth_dev_tokens:
        raise HTTPException(503, "Password reset delivery is not configured.")
    reset = await _ready(_web_identity_repo).create_password_reset(str(req.email))
    result = {"status": "accepted"}
    if reset is None:
        return result
    email, full_name, token = reset
    reset_url = (
        f"{settings.web_public_url.rstrip('/')}/reset-password?token={quote(token, safe='')}"
    )
    await _deliver_password_reset(email, full_name, reset_url)
    if settings.web_auth_dev_tokens:
        result["reset_url"] = reset_url
    return result


@app.post("/api/web/auth/password-reset/confirm", tags=["web-auth"])
@limiter.limit("10/minute")
async def web_password_reset_confirm(
    request: Request, req: WebPasswordResetConfirmRequest
) -> dict[str, str]:
    if not await _ready(_web_identity_repo).reset_password(req.token, req.password):
        raise HTTPException(400, "This password reset link is invalid or expired.")
    return {"status": "password_updated", "next": "/login?reset=1"}


@app.post("/api/web/auth/login", tags=["web-auth"])
@limiter.limit("10/minute")
async def web_login(request: Request, req: WebLoginRequest) -> JSONResponse:
    from responsibleai.enterprise.errors import EnterpriseError as EntErr
    from responsibleai.enterprise.security.service import IdentitySecurityService

    existing_session = request.cookies.get("wp_session", "")
    if existing_session:
        await _ready(_web_identity_repo).revoke_session(existing_session)
    try:
        result = await IdentitySecurityService(_ready(_db_engine)).authenticate_password(
            str(req.email), req.password
        )
    except EntErr as exc:
        if exc.http_status == 403:
            raise HTTPException(exc.http_status, exc.code) from exc
        raise HTTPException(401, "Invalid credentials or unverified email.") from exc
    if result is None:
        raise HTTPException(401, "Invalid credentials or unverified email.")
    token, csrf, assurance = result
    response = JSONResponse(
        {
            "next": "/dashboard" if assurance.org_id else "/onboarding",
            "assurance": assurance.level,
        }
    )
    _set_web_cookies(response, token, csrf)
    return response


@app.post("/api/web/auth/logout", tags=["web-auth"])
async def web_logout(
    request: Request, _principal: WebPrincipal = Depends(require_web_csrf)
) -> JSONResponse:
    token = request.cookies.get("wp_session", "")
    if token:
        await _ready(_web_identity_repo).revoke_session(token)
    response = JSONResponse({"status": "signed_out"})
    response.delete_cookie("wp_session", path="/")
    response.delete_cookie("wp_csrf", path="/")
    return response


@app.post("/api/web/auth/logout-all", tags=["web-auth"])
@limiter.limit("5/minute")
async def web_logout_all(
    request: Request, principal: WebPrincipal = Depends(require_web_csrf)
) -> JSONResponse:
    await _ready(_web_identity_repo).revoke_all_sessions(principal.user_id)
    response = JSONResponse({"status": "all_sessions_revoked"})
    response.delete_cookie("wp_session", path="/")
    response.delete_cookie("wp_csrf", path="/")
    return response


@app.get("/api/web/session", tags=["web-auth"])
async def web_session(principal: WebPrincipal = Depends(get_web_principal)) -> dict[str, Any]:
    organization = None
    if principal.org_id:
        organization = {
            "id": principal.org_id,
            "name": principal.org_name,
            "plan": principal.org_plan.value if principal.org_plan else "FREE",
            "role": principal.role.value if principal.role else None,
        }
    return {
        "user": {
            "id": principal.user_id,
            "email": principal.email,
            "full_name": principal.full_name,
        },
        "organization": organization,
        "organizations": await _ready(_web_identity_repo).list_organizations(principal.user_id),
    }


@app.post("/api/web/session/switch-organization", tags=["web-auth"])
@limiter.limit("10/minute")
async def web_switch_organization(
    request: Request,
    req: WebSwitchOrganizationRequest,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> JSONResponse:
    current = request.cookies.get("wp_session", "")
    rotated = await _ready(_web_identity_repo).switch_organization(
        current,
        principal.user_id,
        req.organization_id,
        ttl_hours=settings.web_session_ttl_hours,
    )
    if rotated is None:
        raise HTTPException(404, "Organization membership not found.")
    token, csrf = rotated
    response = JSONResponse({"status": "organization_switched", "next": "/dashboard"})
    _set_web_cookies(response, token, csrf)
    return response


@app.post("/api/web/onboarding", tags=["web-console"])
@limiter.limit("5/minute")
async def web_onboarding(
    request: Request,
    req: WebOnboardingRequest,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> dict[str, str]:
    if principal.org_id:
        raise HTTPException(409, "This account already belongs to an organization.")
    slug_base = re.sub(r"[^a-z0-9]+", "-", req.organization_name.casefold()).strip("-")
    slug = f"{slug_base[:70]}-{secrets.token_hex(3)}"
    await _ready(_web_identity_repo).attach_organization(
        principal.user_id, name=req.organization_name.strip(), slug=slug
    )
    # Paid entitlements are activated only by a signed Stripe webhook. The
    # onboarding request itself never trusts a browser-selected plan.
    return {"next": "/dashboard/billing" if req.plan != "FREE" else "/dashboard"}


@app.get("/api/web/api-keys", tags=["web-console"])
async def web_list_api_keys(
    principal: WebPrincipal = Depends(get_web_principal),
) -> dict[str, Any]:
    org_id = _web_org_admin(principal)
    keys = await _ready(_org_repo).list_keys(org_id)
    return {"keys": [{**key.to_dict(), "status": "active"} for key in keys]}


async def _canonical_hosted_api_key(
    *,
    user_id: str,
    org_id: str,
    role: Role,
    name: str,
    environment_type: str,
    scopes: tuple[str, ...],
    expires_at: str | None,
) -> tuple[dict[str, Any], str]:
    """Single hosted issuance path. Never calls the low-level repository insert."""
    from responsibleai.enterprise.errors import EnterpriseError
    from responsibleai.enterprise.runtime import get_enterprise_engine
    from responsibleai.enterprise.service import Actor, EnterpriseIAM

    try:
        engine = get_enterprise_engine()
    except RuntimeError as exc:
        raise HTTPException(
            403, detail={"error": "FORBIDDEN", "message": "Authorization backend unavailable."}
        ) from exc
    iam = EnterpriseIAM(engine)
    await iam.ensure_default_environments(org_id)
    actor = Actor(
        actor_type="human",
        actor_id=user_id,
        user_id=user_id,
        org_id=org_id,
        role=role,
        membership_status="ACTIVE",
    )
    envs = {row["type"]: row for row in await iam.list_environments(actor, org_id)}
    env = envs.get(environment_type)
    if env is None:
        raise HTTPException(
            403,
            detail={
                "error": "WRONG_ENVIRONMENT",
                "message": f"{environment_type} environment is not available.",
            },
        )
    try:
        record, raw = await iam.create_api_key(
            actor,
            org_id,
            name=name,
            environment_id=env["id"],
            scopes=scopes,
            expires_at=expires_at,
        )
    except EnterpriseError as exc:
        raise HTTPException(exc.http_status, detail=exc.as_detail()) from exc
    return record, raw


@app.post("/api/web/api-keys", tags=["web-console"], status_code=201)
@limiter.limit("10/minute")
async def web_create_api_key(
    request: Request,
    req: WebCreateKeyRequest,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> dict[str, Any]:
    org_id = _web_org_admin(principal)
    org = await _ready(_org_repo).get_org(org_id)
    if org is None:
        raise HTTPException(404, "Organization not found.")
    active_keys = await _ready(_org_repo).list_keys(org_id)
    if org.plan == Plan.FREE and (req.environment == "live" or len(active_keys) >= 1):
        raise HTTPException(
            403,
            "The Community plan supports one test key. A signed billing webhook must activate a paid entitlement before live or additional keys are issued.",
        )
    expires_at = req.expires_at.isoformat() if req.expires_at else None
    if req.expires_at and req.expires_at <= datetime.now(UTC):
        raise HTTPException(422, "API key expiration must be in the future.")
    env_type = {"test": "DEVELOPMENT", "live": "PRODUCTION", "staging": "STAGING"}[req.environment]
    record, raw = await _canonical_hosted_api_key(
        user_id=principal.user_id,
        org_id=org_id,
        role=principal.role or Role.VIEWER,
        name=req.name,
        environment_type=env_type,
        scopes=tuple(req.scopes),
        expires_at=expires_at,
    )
    return {**record, "api_key": raw, "status": "active"}


@app.post("/api/web/api-keys/{key_id}/rotate", tags=["web-console"])
@limiter.limit("10/minute")
async def web_rotate_api_key(
    request: Request,
    key_id: str,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> dict[str, Any]:
    org_id = _web_org_admin(principal)
    from responsibleai.enterprise.errors import EnterpriseError
    from responsibleai.enterprise.runtime import get_enterprise_engine
    from responsibleai.enterprise.service import Actor, EnterpriseIAM

    iam = EnterpriseIAM(get_enterprise_engine())
    actor = Actor(
        actor_type="human",
        actor_id=principal.user_id,
        user_id=principal.user_id,
        org_id=org_id,
        role=principal.role or Role.VIEWER,
        membership_status="ACTIVE",
    )
    try:
        record, raw = await iam.rotate_api_key(actor, org_id, key_id)
    except EnterpriseError as exc:
        raise HTTPException(exc.http_status, detail=exc.as_detail()) from exc
    return {**record, "api_key": raw, "status": "active"}
    return {**record.to_dict(), "api_key": raw, "status": "active"}


@app.delete("/api/web/api-keys/{key_id}", tags=["web-console"])
@limiter.limit("10/minute")
async def web_revoke_api_key(
    request: Request,
    key_id: str,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> dict[str, str]:
    org_id = _web_org_admin(principal)
    if not await _ready(_org_repo).revoke_key(key_id, org_id=org_id):
        raise HTTPException(404, "API key not found.")
    return {"revoked": key_id}


@app.post("/api/web/invitations", tags=["web-console"], status_code=202)
@limiter.limit("10/minute")
async def web_create_invitation(
    request: Request,
    req: WebInvitationCreateRequest,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> dict[str, str]:
    org_id = _web_org_admin(principal)
    try:
        invitation_id, token = await _ready(_web_identity_repo).create_invitation(
            org_id=org_id,
            email=str(req.email),
            role=Role(req.role),
            invited_by_user_id=principal.user_id,
        )
    except InvitationError as exc:
        raise HTTPException(409, str(exc)) from exc
    from urllib.parse import quote

    invitation_url = (
        f"{settings.web_public_url.rstrip('/')}/accept-invitation?token={quote(token, safe='')}"
    )
    await _deliver_invitation(
        str(req.email), principal.org_name or "your organization", invitation_url
    )
    result = {"status": "invitation_sent", "id": invitation_id}
    if settings.web_auth_dev_tokens:
        result["invitation_url"] = invitation_url
    return result


@app.get("/api/web/invitations", tags=["web-console"])
async def web_list_invitations(
    principal: WebPrincipal = Depends(require_web_csrf),
) -> dict[str, Any]:
    org_id = _web_org_admin(principal)
    invitations = await _ready(_web_identity_repo).list_invitations(org_id)
    return {"invitations": invitations}


@app.post("/api/web/invitations/accept", tags=["web-console"])
@limiter.limit("10/minute")
async def web_accept_invitation(
    request: Request,
    req: WebInvitationAcceptRequest,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> JSONResponse:
    try:
        org_id = await _ready(_web_identity_repo).accept_invitation(req.token, principal.user_id)
    except InvitationError as exc:
        raise HTTPException(400, str(exc)) from exc
    current = request.cookies.get("wp_session", "")
    rotated = await _ready(_web_identity_repo).switch_organization(
        current,
        principal.user_id,
        org_id,
        ttl_hours=settings.web_session_ttl_hours,
    )
    if rotated is None:
        raise HTTPException(409, "Invitation accepted but session rotation failed; sign in again.")
    session_token, csrf = rotated
    response = JSONResponse({"status": "accepted", "next": "/dashboard"})
    _set_web_cookies(response, session_token, csrf)
    return response


@app.delete("/api/web/invitations/{invitation_id}", tags=["web-console"])
@limiter.limit("10/minute")
async def web_revoke_invitation(
    request: Request,
    invitation_id: str,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> dict[str, str]:
    org_id = _web_org_admin(principal)
    if not await _ready(_web_identity_repo).revoke_invitation(invitation_id, org_id):
        raise HTTPException(404, "Pending invitation not found.")
    return {"status": "revoked", "id": invitation_id}


@app.get("/api/web/members", tags=["web-console"])
async def web_list_members(
    principal: WebPrincipal = Depends(require_web_csrf),
) -> dict[str, Any]:
    org_id = _web_org_admin(principal)
    members = await _ready(_web_identity_repo).list_members(org_id)
    return {"members": members}


@app.patch("/api/web/members/{user_id}", tags=["web-console"])
@limiter.limit("10/minute")
async def web_update_member_role(
    request: Request,
    user_id: str,
    req: WebMembershipRoleRequest,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> dict[str, str]:
    org_id = _web_org_admin(principal)
    if req.role == "ADMIN":
        await _verify_web_step_up(
            request,
            org_id=org_id,
            user_id=principal.user_id,
            action="MODIFY_WORKFLOW_RULE",
            risk_tier=PrivilegeRiskTier.PRIVILEGED_HIGH,
        )
    try:
        changed = await _ready(_web_identity_repo).update_membership_role(
            org_id, user_id, Role(req.role)
        )
    except InvitationError as exc:
        raise HTTPException(409, str(exc)) from exc
    if not changed:
        raise HTTPException(404, "Mutable organization membership not found.")
    return {"status": "updated", "user_id": user_id, "role": req.role}


@app.delete("/api/web/members/{user_id}", tags=["web-console"])
@limiter.limit("10/minute")
async def web_remove_member(
    request: Request,
    user_id: str,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> dict[str, str]:
    org_id = _web_org_admin(principal)
    if not await _ready(_web_identity_repo).remove_membership(org_id, user_id):
        raise HTTPException(404, "Removable organization membership not found.")
    return {"status": "removed", "user_id": user_id}


@app.post("/api/web/organizations/transfer-ownership", tags=["web-console"])
@limiter.limit("5/minute")
async def web_transfer_ownership(
    request: Request,
    req: WebOwnershipTransferRequest,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> dict[str, str]:
    if not principal.org_id:
        raise HTTPException(409, "Complete organization onboarding first.")
    if principal.role != Role.OWNER:
        raise HTTPException(403, "Only the organization OWNER may transfer ownership.")
    if principal.user_id == req.new_owner_user_id:
        raise HTTPException(400, "Cannot transfer ownership to yourself.")

    await _verify_web_step_up(
        request,
        org_id=principal.org_id,
        user_id=principal.user_id,
        action="TRANSFER_ROOT_AUTHORITY",
        risk_tier=PrivilegeRiskTier.PRIVILEGED_CRITICAL,
    )

    transferred = await _ready(_web_identity_repo).transfer_organization_ownership(
        org_id=principal.org_id,
        current_owner_id=principal.user_id,
        new_owner_id=req.new_owner_user_id,
    )
    if not transferred:
        raise HTTPException(404, "Target user is not a member of this organization.")
    return {"status": "ownership_transferred", "new_owner_id": req.new_owner_user_id}


@app.delete("/api/web/account", tags=["web-auth"])
@limiter.limit("3/hour")
async def web_delete_account(
    request: Request,
    req: WebAccountDeleteRequest,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> JSONResponse:
    identity = await _ready(_web_identity_repo).authenticate(principal.email, req.password)
    if identity is None or identity[0] != principal.user_id:
        raise HTTPException(403, "Account deletion confirmation failed.")

    await _verify_web_step_up(
        request,
        org_id=principal.org_id or "personal",
        user_id=principal.user_id,
        action="DESTROY_TENANT",
        risk_tier=PrivilegeRiskTier.PRIVILEGED_CRITICAL,
    )

    try:
        disabled = await _ready(_web_identity_repo).disable_account(principal.user_id)
    except (SoleOwnerError, LegalHoldActiveError) as exc:
        raise HTTPException(
            409,
            str(exc),
        ) from exc
    if not disabled:
        raise HTTPException(409, "Account is already disabled.")
    response = JSONResponse({"status": "account_disabled"})
    response.delete_cookie("wp_session", path="/")
    response.delete_cookie("wp_csrf", path="/")
    return response


@app.get("/api/web/dashboard/summary", tags=["web-console"])
async def web_dashboard_summary(
    principal: WebPrincipal = Depends(get_web_principal),
) -> dict[str, Any]:
    if not principal.org_id:
        raise HTTPException(409, "Complete organization onboarding first.")
    pending = await _ready(_approval_repo).list_pending(principal.org_id, limit=50)
    evidence = await _ready(_evidence_repo).list_for_org(principal.org_id, limit=50)
    agents = {record.agent_id for record in evidence if record.agent_id}
    blocked = sum(1 for record in evidence if record.decision in {"DENY", "BLOCKED", "QUARANTINE"})
    return {
        "decisions": len(evidence),
        "agents": len(agents),
        "pending_approvals": len(pending),
        "blocked_actions": blocked,
        "recent_governance": [
            {
                "id": record.evidence_id,
                "agent": record.agent_id,
                "action": record.action_type,
                "policy": record.policy_version or "default",
                "risk": record.risk_tier,
                "decision": record.decision,
                "timestamp": record.recorded_at or record.evaluated_at.isoformat(),
            }
            for record in evidence[:10]
        ],
        "services": {
            "Policy engine": "configured",
            "MCP gateway": "configured" if settings.mcp_governance_enabled else "not enabled",
            "Billing": "configured"
            if _paddle_billing_service or _stripe_service
            else "not configured",
        },
    }


@app.post("/api/web/billing/checkout", tags=["web-console"])
@limiter.limit("10/minute")
async def web_billing_checkout(
    request: Request,
    req: CheckoutRequest,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> dict[str, str]:
    org_id = _web_org_admin(principal)
    org = await _ready(_org_repo).get_org(org_id)
    if org is None:
        raise HTTPException(404, "Organization not found.")
    if _paddle_billing_service is not None:
        try:
            url = await _paddle_billing_service.create_checkout_session(
                PaddleCheckoutRequest(
                    org_id=org_id,
                    plan=Plan(req.plan),
                    success_url=_safe_billing_return_url(settings.billing_success_url),
                    customer_email=principal.email,
                    existing_customer_id=org.paddle_customer_id,
                )
            )
        except PaddleBillingError as exc:
            raise HTTPException(400, str(exc)) from exc
        return {"checkout_url": url}
    if settings.is_production:
        raise HTTPException(503, "Paddle billing is required in production.")
    if _stripe_service is None:
        raise HTTPException(503, "Billing is not configured on this deployment.")
    try:
        url = await _stripe_service.create_checkout_session(
            org_id=org_id,
            org_email=principal.email,
            plan=Plan(req.plan),
            success_url=settings.billing_success_url,
            cancel_url=settings.billing_cancel_url,
            existing_customer_id=org.stripe_customer_id,
        )
    except StripeBillingError as exc:
        raise HTTPException(400, str(exc)) from exc
    return {"checkout_url": url}


@app.post("/api/web/billing/portal", tags=["web-console"])
@limiter.limit("10/minute")
async def web_billing_portal(
    request: Request,
    req: BillingPortalRequest,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> dict[str, str]:
    org_id = _web_org_admin(principal)
    org = await _ready(_org_repo).get_org(org_id)
    if _paddle_billing_service is not None:
        if org is None or not org.paddle_customer_id:
            raise HTTPException(404, "No active Paddle customer exists for this organization.")
        try:
            url = await _paddle_billing_service.create_portal_session(
                customer_id=org.paddle_customer_id,
                subscription_id=org.paddle_subscription_id,
            )
        except PaddleBillingError as exc:
            raise HTTPException(400, str(exc)) from exc
        return {"portal_url": url}
    if settings.is_production:
        raise HTTPException(503, "Paddle billing is required in production.")
    if _stripe_service is None:
        raise HTTPException(503, "Billing is not configured on this deployment.")
    if org is None or not org.stripe_customer_id:
        raise HTTPException(404, "No active billing customer exists for this organization.")
    try:
        url = await _stripe_service.create_billing_portal_session(
            customer_id=org.stripe_customer_id,
            return_url=_safe_billing_return_url(req.return_url),
        )
    except StripeBillingError as exc:
        raise HTTPException(400, str(exc)) from exc
    return {"portal_url": url}


@app.get("/api/web/dashboard/{domain}", tags=["web-console"])
async def web_dashboard_domain(
    request: Request,
    domain: str,
    principal: WebPrincipal = Depends(get_web_principal),
) -> dict[str, Any]:
    if not principal.org_id:
        raise HTTPException(409, "Complete organization onboarding first.")
    if domain not in {
        "agents",
        "approvals",
        "evidence",
        "usage",
        "policies",
        "mcp",
        "organization",
        "members",
        "billing",
        "settings",
        "security",
    }:
        raise HTTPException(404, "Dashboard section not found.")
    if domain == "security":
        return await _web_security_state(request, principal)
    if domain == "organization":
        org = await _ready(_org_repo).get_org(principal.org_id)
        return {
            "items": [org.to_dict()] if org else [],
            "source": "organization_repository",
            "domain": domain,
        }
    if domain == "members":
        return {
            "items": await _ready(_web_identity_repo).list_members(principal.org_id),
            "source": "membership_repository",
            "domain": domain,
        }
    if domain == "approvals":
        return {
            "items": [
                item.to_dict()
                for item in await _ready(_approval_repo).list_pending(principal.org_id, limit=100)
            ],
            "source": "approval_repository",
            "domain": domain,
        }
    if domain == "evidence":
        return {
            "items": [
                item.to_dict()
                for item in await _ready(_evidence_repo).list_for_org(principal.org_id, limit=100)
            ],
            "source": "evidence_repository",
            "domain": domain,
        }
    if domain == "billing":
        org = await _ready(_org_repo).get_org(principal.org_id)
        return {
            "items": [org.to_dict()] if org else [],
            "source": "organization_repository",
            "domain": domain,
            "billing_configured": (_paddle_billing_service or _stripe_service) is not None,
            "usage_meter": "not_available",
        }
    if domain == "usage":
        return {
            "items": [],
            "source": "not_available",
            "domain": domain,
            "detail": "V1 has no customer dashboard usage meter. Billing MCP usage is a separate API-key endpoint.",
        }
    return {"items": [], "source": "not_available", "domain": domain}


def _security_item(title: str, status: str, detail: str, source: str) -> dict[str, Any]:
    return {"title": title, "status": status, "detail": detail, "source": source}


async def _web_security_state(request: Request, principal: WebPrincipal) -> dict[str, Any]:
    from sqlalchemy import func, select

    from responsibleai.db.engine import (
        human_totp_factors,
        identity_verifications,
        organizations,
        passkey_credentials,
        recovery_code_hashes,
        web_sessions,
    )

    items: list[dict[str, Any]] = []
    engine = _ready(_db_engine)
    token = request.cookies.get("wp_session", "")
    try:
        async with engine.raw.connect() as conn:
            session_row = None
            if token:
                session_row = (
                    await conn.execute(
                        select(web_sessions).where(
                            web_sessions.c.token_hash == _web_token_hash(token)
                        )
                    )
                ).fetchone()
            if session_row is None:
                items.append(
                    _security_item(
                        "Assurance level",
                        "UNAVAILABLE",
                        "Current session assurance could not be loaded.",
                        "web_sessions",
                    )
                )
            else:
                items.append(
                    _security_item(
                        "Assurance level",
                        str(session_row.assurance_level or "PASSWORD"),
                        "Session assurance recorded at authentication.",
                        "web_sessions.assurance_level",
                    )
                )
            totp = (
                await conn.execute(
                    select(human_totp_factors.c.status).where(
                        human_totp_factors.c.user_id == principal.user_id
                    )
                )
            ).fetchone()
            if totp is None:
                items.append(
                    _security_item(
                        "MFA (TOTP)",
                        "NOT CONFIGURED",
                        "No TOTP factor is enrolled for this user.",
                        "human_totp_factors",
                    )
                )
            else:
                items.append(
                    _security_item(
                        "MFA (TOTP)",
                        str(totp.status),
                        "TOTP factor row from identity security store.",
                        "human_totp_factors.status",
                    )
                )
            passkey_count = (
                await conn.execute(
                    select(func.count())
                    .select_from(passkey_credentials)
                    .where(
                        passkey_credentials.c.user_id == principal.user_id,
                        passkey_credentials.c.status == "ACTIVE",
                    )
                )
            ).scalar()
            items.append(
                _security_item(
                    "Passkeys",
                    "CONFIGURED" if int(passkey_count or 0) else "NOT CONFIGURED",
                    f"{int(passkey_count or 0)} active passkey credential(s).",
                    "passkey_credentials",
                )
            )
            recovery_count = (
                await conn.execute(
                    select(func.count())
                    .select_from(recovery_code_hashes)
                    .where(
                        recovery_code_hashes.c.user_id == principal.user_id,
                        recovery_code_hashes.c.consumed_at.is_(None),
                    )
                )
            ).scalar()
            items.append(
                _security_item(
                    "Recovery codes",
                    "CONFIGURED" if int(recovery_count or 0) else "NOT CONFIGURED",
                    f"{int(recovery_count or 0)} unused recovery code hash(es).",
                    "recovery_code_hashes",
                )
            )
            org_row = (
                await conn.execute(
                    select(organizations.c.sso_required).where(
                        organizations.c.id == principal.org_id
                    )
                )
            ).fetchone()
            sso_required = bool(org_row.sso_required) if org_row is not None else False
            sso_provider = "CONFIGURED" if (_oidc_provider or _saml_config) else "NOT CONFIGURED"
            items.append(
                _security_item(
                    "SSO",
                    "REQUIRED" if sso_required else sso_provider,
                    (
                        "Organization requires SSO."
                        if sso_required
                        else "SSO provider configuration on this deployment."
                    ),
                    "organizations.sso_required+runtime_oidc_saml",
                )
            )
            identity = (
                await conn.execute(
                    select(identity_verifications.c.status)
                    .where(identity_verifications.c.user_id == principal.user_id)
                    .order_by(identity_verifications.c.updated_at.desc())
                )
            ).fetchone()
            if identity is None:
                items.append(
                    _security_item(
                        "Identity verification",
                        "NOT CONFIGURED",
                        "No identity verification record exists for this user.",
                        "identity_verifications",
                    )
                )
            else:
                items.append(
                    _security_item(
                        "Identity verification",
                        str(identity.status),
                        "Latest identity verification status.",
                        "identity_verifications.status",
                    )
                )
    except Exception:
        logger.exception("web_security_state_unavailable")
        items = [
            _security_item(
                "Security state",
                "UNAVAILABLE",
                "Backend security state could not be read.",
                "unavailable",
            )
        ]
    return {"items": items, "source": "identity_security_stores", "domain": "security"}


@app.get("/api/web/approvals/{approval_id}", tags=["web-console"])
@limiter.limit("30/minute")
async def web_get_approval(
    request: Request,
    approval_id: str,
    principal: WebPrincipal = Depends(get_web_principal),
) -> dict[str, Any]:
    org_id = _web_org_member(principal)
    approval = await _ready(_approval_repo).get(approval_id)
    if approval is None or approval.organization_id != org_id:
        raise HTTPException(404, "No approval request found with this ID.")
    votes = await _ready(_approval_repo).list_votes(approval_id)
    return approval_detail_payload(approval, votes)


@app.get("/api/web/evidence/verify", tags=["web-console"])
@limiter.limit("30/minute")
async def web_verify_evidence_chain(
    request: Request,
    principal: WebPrincipal = Depends(get_web_principal),
) -> dict[str, Any]:
    org_id = _web_org_member(principal)
    status = await _ready(_evidence_repo).verify_chain_status(org_id)
    return {
        "org_id": org_id,
        "status": status.value,
        "chain_intact": status.value in {"VALID", "INCOMPLETE"},
        "cryptographically_signed": False,
        "integrity_note": CHAIN_INTEGRITY_NOTE,
    }


@app.get("/api/web/evidence", tags=["web-console"])
@limiter.limit("30/minute")
async def web_list_evidence(
    request: Request,
    limit: int = Query(default=50, ge=1, le=100),
    decision: str | None = Query(default=None),
    principal: WebPrincipal = Depends(get_web_principal),
) -> dict[str, Any]:
    org_id = _web_org_member(principal)
    records = await _ready(_evidence_repo).list_for_org(org_id, limit=limit, decision=decision)
    return {"evidence": [record.to_dict() for record in records], "limit": limit}


@app.get("/api/web/evidence/{evidence_id}/attestation", tags=["web-console"])
@limiter.limit("30/minute")
async def web_get_evidence_attestation(
    request: Request,
    evidence_id: str,
    principal: WebPrincipal = Depends(get_web_principal),
) -> dict[str, Any]:
    org_id = _web_org_member(principal)
    evidence = await _ready(_evidence_repo).get_for_org(evidence_id, org_id)
    if evidence is None:
        raise HTTPException(404, "Evidence record not found.")
    outcome = await _ready(_outcome_repo).get_for_org(evidence_id, org_id)
    payload = build_attestation_record(evidence, outcome).to_dict()
    payload["cryptographically_signed"] = False
    return payload


@app.get("/api/web/evidence/{evidence_id}", tags=["web-console"])
@limiter.limit("30/minute")
async def web_get_evidence(
    request: Request,
    evidence_id: str,
    principal: WebPrincipal = Depends(get_web_principal),
) -> dict[str, Any]:
    org_id = _web_org_member(principal)
    evidence = await _ready(_evidence_repo).get_for_org(evidence_id, org_id)
    if evidence is None:
        raise HTTPException(404, "Evidence record not found.")
    return evidence.to_dict()


@app.post("/api/web/approvals/{approval_id}/resolve", tags=["web-console"])
@limiter.limit("30/minute")
async def web_resolve_approval(
    request: Request,
    approval_id: str,
    req: ApprovalResolveRequest,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> dict[str, Any]:
    org_id = _web_org_admin(principal)
    existing = await _ready(_approval_repo).get(approval_id)
    if existing is None or existing.organization_id != org_id:
        raise HTTPException(404, "No approval request found with this ID.")
    try:
        resolved = await _ready(_approval_repo).resolve(
            approval_id,
            resolved_by=_web_resolver_id(principal),
            outcome=ApprovalStatus(req.outcome),
            notes=req.notes,
        )
    except ApprovalNotFoundError as exc:
        raise HTTPException(404, str(exc)) from None
    except ApprovalAlreadyResolvedError as exc:
        raise HTTPException(409, str(exc)) from None
    except ApprovalExpiredError as exc:
        raise HTTPException(409, str(exc)) from None
    except SelfApprovalError as exc:
        raise HTTPException(403, str(exc)) from None
    except AlreadyVotedError as exc:
        raise HTTPException(409, str(exc)) from None
    observe_governance_approval(req.outcome, org_id=org_id)
    return resolved.to_dict()


@app.post("/api/web/approvals/{approval_id}/execute", tags=["web-console"])
@limiter.limit("30/minute")
async def web_execute_approval(
    request: Request,
    approval_id: str,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> dict[str, Any]:
    org_id = _web_org_admin(principal)
    existing = await _ready(_approval_repo).get(approval_id)
    if existing is None or existing.organization_id != org_id:
        raise HTTPException(404, "No approval request found with this ID.")
    if existing.status != ApprovalStatus.APPROVED:
        raise HTTPException(409, "Approval is not approved for execution.")
    from responsibleai.governance.synthetic_counter import SyntheticAcknowledgementLostError

    try:
        result = await resume_approval(
            approval_id,
            nonce_repo=ExecutionNonceRepository(_ready(_db_engine)),
            epoch_repo=RevocationEpochRepository(_ready(_db_engine)),
            authority_resolver=AuthorityResolver(
                RootAuthorityRepository(_ready(_db_engine)),
                ConsentProofRepository(_ready(_db_engine)),
                _ready(_delegation_repo),
            ),
            policy_repo=_ready(_policy_repo),
            gateway=_upstream_gateway,
            upstream_registry=_ready(_upstream_registry),
            approval_repo=_ready(_approval_repo),
            evidence_repo=_ready(_evidence_repo),
            org_id=org_id,
            outcome_repo=_ready(_outcome_repo),
        )
    except ApprovalNotFoundError as exc:
        raise HTTPException(404, str(exc)) from None
    except ApprovalExpiredError as exc:
        raise HTTPException(409, str(exc)) from None
    except (ApprovalNotApprovedError, ApprovalActionMismatchError) as exc:
        raise HTTPException(409, str(exc)) from None
    except ApprovalAuthorizationDeniedError as exc:
        raise HTTPException(409, str(exc)) from None
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None
    except SyntheticAcknowledgementLostError:
        evidence_id, outcome_id = await _web_execution_identifiers(org_id, approval_id)
        return web_execution_payload(
            approval_id=approval_id,
            execution_status=OutcomeStatus.UNKNOWN,
            evidence_id=evidence_id,
            outcome_id=outcome_id,
            message=UNKNOWN_EXECUTION_MESSAGE,
        )
    from responsibleai.mcp.governance_integration import _classify_execution_outcome

    status = _classify_execution_outcome(result)
    evidence_id, outcome_id = await _web_execution_identifiers(org_id, approval_id)
    return web_execution_payload(
        approval_id=approval_id,
        execution_status=status,
        evidence_id=evidence_id,
        outcome_id=outcome_id,
        message=KNOWN_SUCCESS_MESSAGE
        if status is OutcomeStatus.SUCCEEDED
        else UNKNOWN_EXECUTION_MESSAGE
        if status is OutcomeStatus.UNKNOWN
        else f"Execution completed with outcome {status.value}.",
    )


@app.patch("/api/web/organization", tags=["web-console"])
@limiter.limit("10/minute")
async def web_update_organization(
    request: Request,
    req: UpdateWebOrganizationRequest,
    principal: WebPrincipal = Depends(require_web_csrf),
) -> dict[str, str]:
    org_id = _web_org_admin(principal)
    if not await _ready(_org_repo).update_org_name(org_id, req.name.strip()):
        raise HTTPException(404, "Organization not found.")
    return {"id": org_id, "name": req.name.strip()}


# ── Root / HTML ────────────────────────────────────────────────────────────────


@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def root() -> HTMLResponse:
    index = _static_dir / "whitepact" / "pages" / "home.html"
    return HTMLResponse(content=index.read_text())


@app.get("/signup", response_class=HTMLResponse, include_in_schema=False)
async def signup_page() -> HTMLResponse:
    """WhitePact account signup. No machine key is issued until verification."""
    page = _static_dir / "whitepact" / "index.html"
    return HTMLResponse(content=page.read_text())


async def _whitepact_spa() -> HTMLResponse:
    return HTMLResponse(content=(_static_dir / "whitepact" / "index.html").read_text())


_WHITEPACT_COMMERCE_PATHS = {
    "/pricing": "pricing.html",
    "/sovereign": "sovereign.html",
    "/terms": "terms.html",
    "/privacy": "privacy.html",
    "/refund-policy": "refund-policy.html",
}


async def _whitepact_commerce_page(request: Request) -> HTMLResponse:
    """Serve built public metadata/content without depending on client JavaScript."""
    filename = _WHITEPACT_COMMERCE_PATHS[request.url.path]
    return HTMLResponse(content=(_static_dir / "whitepact" / "pages" / filename).read_text())


for _commerce_path in _WHITEPACT_COMMERCE_PATHS:
    app.get(_commerce_path, response_class=HTMLResponse, include_in_schema=False)(
        _whitepact_commerce_page
    )


@app.get("/refunds", include_in_schema=False)
@app.head("/refunds", include_in_schema=False)
async def legacy_refunds_redirect() -> RedirectResponse:
    return RedirectResponse("/refund-policy", status_code=308)


_WHITEPACT_SPA_PATHS = [
    "/about",
    "/contact",
    "/docs",
    "/trust",
    "/billing/success",
    "/billing/cancelled",
    "/login",
    "/verify-email",
    "/forgot-password",
    "/reset-password",
    "/accept-invitation",
    "/onboarding",
    "/dashboard",
    "/sovereign/workbench",
]

for _spa_path in _WHITEPACT_SPA_PATHS:
    app.get(_spa_path, response_class=HTMLResponse, include_in_schema=False)(_whitepact_spa)


async def _whitepact_spa_head() -> Response:
    return Response(media_type="text/html")


for _spa_head_path in ["/", "/signup", *_WHITEPACT_SPA_PATHS, *_WHITEPACT_COMMERCE_PATHS]:
    app.head(_spa_head_path, include_in_schema=False)(_whitepact_spa_head)


@app.get("/robots.txt", response_class=PlainTextResponse, include_in_schema=False)
async def robots_txt() -> PlainTextResponse:
    return PlainTextResponse((_static_dir / "whitepact" / "robots.txt").read_text())


@app.head("/robots.txt", include_in_schema=False)
async def robots_txt_head() -> Response:
    return Response(media_type="text/plain")


@app.get("/sitemap.xml", response_class=Response, include_in_schema=False)
async def sitemap_xml() -> Response:
    return Response(
        (_static_dir / "whitepact" / "sitemap.xml").read_text(), media_type="application/xml"
    )


@app.head("/sitemap.xml", include_in_schema=False)
async def sitemap_xml_head() -> Response:
    return Response(media_type="application/xml")


@app.get("/dashboard/{spa_path:path}", response_class=HTMLResponse, include_in_schema=False)
async def whitepact_dashboard_spa(spa_path: str) -> HTMLResponse:
    return await _whitepact_spa()


@app.head("/dashboard/{spa_path:path}", include_in_schema=False)
async def whitepact_dashboard_spa_head(spa_path: str) -> Response:
    return await _whitepact_spa_head()


_LLMS_TXT = """\
# ResponsibleAI

> An independent AI trust and governance platform: a public Trust Index \
(free self-assessed or human-reviewed certified scoring for any AI model \
or tool), a cross-model leaderboard measured against a published \
methodology, and a crowd-reported AI Incident Database. Built to be a \
citable source for questions about AI model/tool trustworthiness, not \
just a compliance vendor.

## Canonical public data

- [Trust Registry](/registry): every assessed model/tool, certified and \
self-reported, searchable.
- [Leaderboard](/leaderboard): cross-model trust ranking from live \
measurement against a published prompt corpus, not self-reported.
- [Incident Database](/incident-db): crowd-reported, moderator-reviewed, \
hash-chained public registry of AI safety incidents.
- [Free self-assessment](/assess): score any model/tool for free, no \
signup, get a citable and embeddable Trust Index badge.

## Machine-readable APIs (no auth required)

- `GET /api/trust-index/registry` — full registry listing (JSON)
- `GET /api/trust-index/check?model=X&provider=Y` — trust score + \
incident count for a named model/tool
- `GET /api/leaderboard` — current leaderboard rankings (JSON)
- `GET /api/incident-db` — published incidents, filterable (JSON)

## Specifications

- [Trust Index Spec](https://github.com/Guruprasath-Annadurai/ResponsibleAi/blob/main/compliance/TRUST_INDEX_SPEC.md): \
the open, versioned scoring standard.
- [Leaderboard Methodology](https://github.com/Guruprasath-Annadurai/ResponsibleAi/blob/main/compliance/LEADERBOARD_METHODOLOGY.md): \
how live scores are measured.

## Agent integration

An MCP server (`responsibleai-mcp`, 27 tools) exposes this platform to \
any MCP-compatible agent, including a free `rai_check_trust` tool for \
checking a third-party model or tool's trust score before invoking it. \
LangChain, LangGraph, and Google ADK adapters are published at \
https://github.com/Guruprasath-Annadurai/ResponsibleAi/tree/main/src/responsibleai/integrations.
"""


@app.get("/llms.txt", response_class=PlainTextResponse, include_in_schema=False)
async def llms_txt() -> PlainTextResponse:
    """Machine-readable entry point for AI crawlers/answer engines — the
    citability play from GAME_CHANGER_STRATEGY.md Section 3: point
    structured, canonical sources at the free public data (registry,
    leaderboard, incident DB) so an AI answer engine asked "is this model
    trustworthy" has something concrete to cite instead of nothing."""
    return PlainTextResponse(content=_LLMS_TXT)


@app.get("/status", response_class=HTMLResponse, include_in_schema=False)
async def status_page() -> HTMLResponse:
    """Self-hosted status page stopgap — polls /api/support/status client-side.
    Not a substitute for a public multi-region status page (statuspage.io etc)."""
    page = _static_dir / "status.html"
    return HTMLResponse(content=page.read_text())


@app.get("/trust/legacy", response_class=HTMLResponse, include_in_schema=False)
async def legacy_trust_center() -> HTMLResponse:
    """Public security/compliance posture page — links to CAIQ, NIST CSF,
    and enterprise security docs. States gaps plainly, not just controls."""
    page = _static_dir / "trust.html"
    return HTMLResponse(content=page.read_text())


@app.get("/leaderboard", response_class=HTMLResponse, include_in_schema=False)
async def leaderboard_page() -> HTMLResponse:
    """Public cross-model trust leaderboard — reads live from GET /api/leaderboard
    client-side. See compliance/LEADERBOARD_METHODOLOGY.md for the methodology."""
    page = _static_dir / "leaderboard.html"
    return HTMLResponse(content=page.read_text())


@app.get("/registry", response_class=HTMLResponse, include_in_schema=False)
async def trust_index_registry_page() -> HTMLResponse:
    """Public Trust Registry — searchable directory over GET
    /api/trust-index/registry. The acquisition-loop page
    GAME_CHANGER_STRATEGY.md Section 3 calls for: anyone landing here from
    a badge link can see every other assessed model, not just the one they
    followed a link to."""
    page = _static_dir / "registry.html"
    return HTMLResponse(content=page.read_text())


@app.get("/assess", response_class=HTMLResponse, include_in_schema=False)
async def trust_index_assess_page() -> HTMLResponse:
    """Public, zero-signup Trust Index self-assessment form — the human
    entry point to POST /api/trust-index/assess. Previously that endpoint
    was only reachable via a raw API call; this is what makes "free
    self-assessment" actually free-to-use rather than free-to-those-who-
    can-write-curl."""
    page = _static_dir / "assess.html"
    return HTMLResponse(content=page.read_text())


@app.get("/verify/{passport_id}", response_class=HTMLResponse, include_in_schema=False)
async def trust_index_verify_page(passport_id: str) -> HTMLResponse:
    """Public Trust Passport verification page — the human-readable version of
    GET /api/trust-index/verify/{id}. Same static shell for every ID; the JS
    reads the ID from the URL path client-side. See
    compliance/TRUST_INDEX_SPEC.md for what this is and why it's citable."""
    page = _static_dir / "verify.html"
    return HTMLResponse(content=page.read_text())


@app.get("/incident-db", response_class=HTMLResponse, include_in_schema=False)
async def incident_db_page() -> HTMLResponse:
    """Public AI Incident Database — searchable list, reads live from
    GET /api/incident-db client-side. Registered before /incident-db/report
    and /incident-db/{public_id} only matters for the API routes above;
    these three page routes are distinct paths so order is not load-bearing
    here, but kept in the same order for readability."""
    page = _static_dir / "incident_db.html"
    return HTMLResponse(content=page.read_text())


@app.get("/incident-db/report", response_class=HTMLResponse, include_in_schema=False)
async def incident_db_report_page() -> HTMLResponse:
    """Public report-submission form — posts to POST /api/incident-db/report."""
    page = _static_dir / "incident_db_report.html"
    return HTMLResponse(content=page.read_text())


@app.get("/incident-db/{public_id}", response_class=HTMLResponse, include_in_schema=False)
async def incident_db_detail_page(public_id: str) -> HTMLResponse:
    """Public single-incident detail page — reads the ID from the URL path
    client-side and fetches GET /api/incident-db/{public_id}. Registered
    after /incident-db/report so a literal request for the report form
    isn't swallowed by this catch-all path parameter."""
    page = _static_dir / "incident_db_detail.html"
    return HTMLResponse(content=page.read_text())


def _page_route(path: str, filename: str) -> None:
    """Register a GET route that serves a static HTML file verbatim.
    Centralized so every simple page follows the exact same pattern — one
    typo'd filename here breaks one page instead of a copy-pasted mistake
    breaking many."""

    async def _handler() -> HTMLResponse:
        return HTMLResponse(content=(_static_dir / filename).read_text())

    app.get(path, response_class=HTMLResponse, include_in_schema=False)(_handler)


for _path, _filename in [
    ("/auth/complete", "auth_complete.html"),
    ("/evaluate", "evaluate.html"),
    ("/guardrails", "guardrails.html"),
    ("/hallucination", "hallucination.html"),
    ("/cost", "cost.html"),
    ("/router", "router.html"),
    ("/trust-scores", "trust_scores.html"),
    ("/eval", "eval.html"),
    ("/redteam", "redteam.html"),
    ("/audit", "audit.html"),
    ("/incidents", "incidents.html"),
    ("/webhooks-manage", "webhooks_manage.html"),
    ("/organizations", "organizations.html"),
    ("/billing", "billing.html"),
    ("/settings", "settings.html"),
]:
    _page_route(_path, _filename)


# ── Branding (white-label) ───────────────────────────────────────────────────────


@app.get("/api/branding", tags=["ops"])
async def branding() -> dict[str, Any]:
    """Public, unauthenticated — the frontend shell fetches this on every
    page load to render the sidebar brand name/logo. See
    compliance/OEM_LICENSING.md for the white-label deployment model this
    supports; this endpoint is the display-layer mechanism, not the
    licensing agreement itself."""
    return {"brand_name": settings.brand_name, "logo_url": settings.brand_logo_url}


# ── Health & Ops ───────────────────────────────────────────────────────────────


@app.get("/api/health", tags=["ops"])
async def health() -> JSONResponse:
    db_ok = True
    try:
        if _cost_repo:
            await _ready(_cost_repo).request_count()
    except Exception:
        db_ok = False

    db_backend = (
        "postgresql" if (settings.database_url or "").startswith("postgresql") else "sqlite"
    )
    rl_backend = "redis" if settings.redis_url else "memory"
    orgs_count = len(await _ready(_org_repo).list_orgs()) if _org_repo else 0

    body = {
        "status": "healthy" if db_ok else "degraded",
        "version": __version__,
        "uptime_seconds": round(time.monotonic() - _START_TIME, 1),
        "timestamp": datetime.now(UTC).isoformat(),
        "checks": {
            "database": "ok" if db_ok else "error",
            "db_backend": db_backend,
            "rate_limit_backend": rl_backend,
            "otel": "enabled" if settings.otel_endpoint else "disabled",
            "auth": "enabled" if (settings.auth_enabled and settings.api_keys) else "disabled",
            "websocket_connections": _ws_manager.connection_count,
            "webhooks_registered": len(_webhook_manager.list_webhooks()),
            "orgs": orgs_count,
        },
        "modules": [
            "trust_score",
            "ai_passport",
            "guardrails",
            "hallucination",
            "compliance",
            "redteam",
            "cost_tracker",
            "cost_analyzer",
            "model_router",
            "drift_monitor",
            "websockets",
            "webhooks",
            "prometheus",
            "rbac",
            "orgs",
            "audit_log",
            "eval_compare",
            "eval_benchmarks",
            "eval_regression",
            "dataset_scan",
            "sso_oidc",
            "api_versioning",
            "support",
            "mcp_server",
            "billing",
        ],
        "api_versions": ["1.0", "1.1"],
        "stable_since": "1.0.0",
    }
    return JSONResponse(content=body, status_code=200 if db_ok else 503)


@app.get("/health", tags=["ops"], include_in_schema=False)
@app.get("/healthz", tags=["ops"], include_in_schema=False)
@app.get("/livez", tags=["ops"], include_in_schema=False)
async def k8s_liveness() -> JSONResponse:
    return JSONResponse(content={"status": "ok"}, status_code=200)


@app.get("/ready", tags=["ops"], include_in_schema=False)
@app.get("/readyz", tags=["ops"], include_in_schema=False)
async def k8s_readiness() -> JSONResponse:
    db_ok = True
    try:
        if _db_engine is not None:
            db_ok = await _db_engine.ping(timeout_seconds=2.0)
        elif _cost_repo:
            await _ready(_cost_repo).request_count()
        else:
            db_ok = False
    except Exception:
        db_ok = False
    if db_ok:
        return JSONResponse(content={"status": "ready", "database": "connected"}, status_code=200)
    return JSONResponse(
        content={"status": "unavailable", "database": "disconnected"},
        status_code=503,
    )


@app.get("/api/restore/status", tags=["ops"], include_in_schema=False)
@app.get("/api/v1/restore/status", tags=["ops"])
async def restore_status() -> JSONResponse:
    """Read-only restore admission status probe."""
    from responsibleai.data_governance.backup_defense import get_restore_readiness_gate

    gate = get_restore_readiness_gate()
    return JSONResponse(
        content={
            "status": gate.state.value,
            "is_admitted": gate.is_admitted(),
        },
        status_code=200,
    )


@app.post("/api/restore/reconcile", tags=["ops"], include_in_schema=False)
@app.post("/api/v1/restore/reconcile", tags=["ops"])
async def restore_reconcile(request: Request) -> JSONResponse:
    """Narrow operator recovery endpoint to trigger post-restore lifecycle reconciliation."""
    from responsibleai.data_governance.backup_defense import (
        RestoreReconciliationEngine,
        RestoreReconciliationError,
        get_restore_readiness_gate,
    )

    if _db_engine is None:
        return JSONResponse(
            status_code=503,
            content={"error": "db_unavailable", "message": "Database is not initialized."},
        )

    gate = get_restore_readiness_gate()
    engine = RestoreReconciliationEngine(engine=_db_engine, gate=gate)
    try:
        report = await engine.reconcile_post_restore(reconciled_by="operator-recovery-endpoint")
        return JSONResponse(
            content={
                "status": "success",
                "report_id": report.id,
                "reconciliation_status": report.status,
                "tombstones_detected": report.tombstones_detected,
                "tenants_quarantined": report.tenants_quarantined,
            },
            status_code=200,
        )
    except RestoreReconciliationError as exc:
        return JSONResponse(
            status_code=500,
            content={
                "error": "reconciliation_failed",
                "message": str(exc),
                "gate_state": gate.state.value,
            },
        )


@app.get("/api/metrics", tags=["ops"])
@limiter.limit("60/minute")
async def metrics(
    request: Request, _auth: OrgContext = Depends(require_role(Role.ANALYST))
) -> dict[str, Any]:
    total_requests = _REQUEST_COUNTER["total"]
    errors = _REQUEST_COUNTER["errors"]
    total_cost = await _ready(_cost_repo).total_cost(30) if _cost_repo else 0.0
    audit_count = await _ready(_audit_repo).count(30) if _audit_repo else 0
    return {
        "uptime_seconds": round(time.monotonic() - _START_TIME, 1),
        "total_requests": total_requests,
        "error_count": errors,
        "error_rate_pct": round(errors / max(total_requests, 1) * 100, 2),
        "db_backend": "postgresql"
        if (settings.database_url or "").startswith("postgresql")
        else "sqlite",
        "rate_limit_backend": "redis" if settings.redis_url else "memory",
        "otel_enabled": bool(settings.otel_endpoint),
        "auth_enabled": settings.auth_enabled and bool(settings.api_keys),
        "alert_threshold": settings.alert_threshold,
        "monthly_budget_usd": settings.monthly_budget_usd,
        "monthly_spend_usd": round(total_cost, 4),
        "websocket_connections": _ws_manager.connection_count,
        "webhooks_registered": len(_webhook_manager.list_webhooks()),
        "webhook_deliveries": _webhook_manager.total_deliveries,
        "webhook_failures": _webhook_manager.failed_deliveries,
        "audit_entries_30d": audit_count,
    }


@app.get("/metrics", tags=["ops"], include_in_schema=False)
async def prometheus_metrics() -> Response:
    observe_websocket_connections(_ws_manager.connection_count)
    body, content_type = get_metrics_output()
    return Response(content=body, media_type=content_type)


# ── Organizations & RBAC ───────────────────────────────────────────────────────


@app.post("/api/signup", tags=["rbac"], status_code=201)
@limiter.limit("5/hour")
async def signup(request: Request, req: SignupRequest) -> dict[str, Any]:
    """Public, unauthenticated self-serve signup — creates a new
    organization and issues its first OWNER-role API key in one call.

    No CAPTCHA and no email-ownership verification: this deployment has
    neither a CAPTCHA provider nor an outbound-email provider
    configured. Hardened instead with what's deterministically checkable
    without either: a honeypot field, a minimum client-side dwell time,
    a disposable-email-domain blocklist, and a site-wide (not just
    per-IP) rate window — see `signup_guard.py`'s own docstring for
    exactly what each of those does and does not defend against.
    """
    if req.website:
        raise HTTPException(400, "Signup failed. Please try again or contact support.")

    if is_disposable_email_domain(req.email):
        raise HTTPException(400, "Please sign up with a non-disposable email address.")

    if not dwell_time_ok(req.page_loaded_at_ms):
        raise HTTPException(400, "Signup failed. Please try again.")

    if not _signup_window.allow():
        raise HTTPException(429, "Too many signups right now. Please try again shortly.")

    existing = await _ready(_org_repo).get_org_by_slug(req.slug)
    if existing:
        raise HTTPException(409, f"Workspace URL '{req.slug}' is already taken.")

    org = await _ready(_org_repo).create_org(req.name, req.slug)
    logger.info("self_serve_signup", org_id=org.id, slug=req.slug)
    return {
        "org": org.to_dict(),
        "api_key": None,
        "key_id": None,
        "reason_code": "API_KEY_ISSUANCE_NOT_ALLOWED",
        "message": (
            "Organization created. Production API credentials require a verified "
            "accountable human (and organization verification where applicable). "
            "Use the enterprise identity APIs after verification."
        ),
    }


@app.post("/api/orgs", tags=["rbac"], status_code=201)
@limiter.limit("10/minute")
async def create_org(
    request: Request,
    req: CreateOrgRequest,
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    existing = await _ready(_org_repo).get_org_by_slug(req.slug)
    if existing:
        raise HTTPException(409, f"Slug '{req.slug}' is already taken")
    org = await _ready(_org_repo).create_org(
        req.name,
        req.slug,
        req.monthly_budget_usd,
        provisioner_key_id=_auth.key_id,
    )
    return org.to_dict()


@app.get("/api/orgs", tags=["rbac"])
@limiter.limit("60/minute")
async def list_orgs(
    request: Request,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    orgs = await _ready(_org_repo).list_orgs()
    return {"orgs": [o.to_dict() for o in orgs], "count": len(orgs)}


@app.get("/api/orgs/{org_id}", tags=["rbac"])
@limiter.limit("120/minute")
async def get_org(
    request: Request,
    org_id: str,
    _auth: OrgContext = Depends(require_role(Role.VIEWER)),
) -> dict[str, Any]:
    _require_caller_owns_org(_auth, org_id)
    org = await _ready(_org_repo).get_org(org_id)
    if not org:
        raise HTTPException(404, "Organization not found")
    return org.to_dict()


@app.delete("/api/orgs/{org_id}", tags=["rbac"])
@limiter.limit("10/minute")
async def delete_org(
    request: Request,
    org_id: str,
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    _require_caller_owns_org(_auth, org_id)
    org = await _ready(_org_repo).get_org(org_id)
    if not org:
        raise HTTPException(404, "Organization not found")
    deleted = await _ready(_org_repo).delete_org(org_id)
    if not deleted:
        raise HTTPException(404, "Organization not found")
    return {"deleted": org_id}


@app.put("/api/orgs/{org_id}/sso", tags=["rbac"])
@limiter.limit("10/minute")
async def set_org_sso(
    request: Request,
    org_id: str,
    req: SetSSORequest,
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    """Enable/disable SSO-only enforcement for an org.

    When enabled, static API keys scoped to this org stop working — every
    request must present an OIDC-issued Bearer token instead. Requires
    RAI_OIDC_ISSUER to be configured on the server, otherwise enabling this
    would lock the org out entirely.
    """
    _require_caller_owns_org(_auth, org_id)
    if req.sso_required and _oidc_provider is None:
        raise HTTPException(
            400,
            "Cannot enforce SSO — no OIDC provider is configured on this server "
            "(set RAI_OIDC_ISSUER). Enabling this now would lock the organization out.",
        )
    org = await _ready(_org_repo).get_org(org_id)
    if not org:
        raise HTTPException(404, "Organization not found")
    await _ready(_org_repo).set_sso_required(org_id, req.sso_required)
    return {"org_id": org_id, "sso_required": req.sso_required}


@app.put("/api/orgs/{org_id}/mfa", tags=["rbac"])
@limiter.limit("10/minute")
async def set_org_mfa(
    request: Request,
    org_id: str,
    req: SetMFARequest,
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    """Require every API key under this org to complete TOTP MFA at
    /login. Keys that haven't enrolled yet are blocked from logging in
    (not from making API calls directly — see auth/mfa.py for why) until
    they enroll via POST /api/orgs/{org_id}/keys/{key_id}/mfa/enroll."""
    _require_caller_owns_org(_auth, org_id)
    org = await _ready(_org_repo).get_org(org_id)
    if not org:
        raise HTTPException(404, "Organization not found")
    await _ready(_org_repo).set_org_mfa_required(org_id, req.mfa_required)
    return {"org_id": org_id, "mfa_required": req.mfa_required}


@app.get("/api/orgs/{org_id}/authority-ceiling", tags=["rbac"])
@limiter.limit("30/minute")
async def get_authority_ceiling(
    request: Request,
    org_id: str,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    """The structural authority ceiling (v3 authority-layer work) no
    per-call `AuthorityContext` built for this org can ever exceed —
    enforced live on every hosted MCP tool call via
    `validate_attenuation()`. `null` fields mean unrestricted; no row at
    all (every org before this feature existed) returns all-`null`."""
    _require_caller_owns_org(_auth, org_id)
    org = await _ready(_org_repo).get_org(org_id)
    if not org:
        raise HTTPException(404, "Organization not found")
    ceiling = await _ready(_ceiling_repo).get(org_id)
    if ceiling is None:
        ceiling = OrgAuthorityCeiling(org_id=org_id)
    return {
        "org_id": org_id,
        "max_value_usd": ceiling.max_value_usd,
        "allowed_targets": ceiling.allowed_targets,
        "denied_targets": ceiling.denied_targets,
        "max_delegation_depth": ceiling.max_delegation_depth,
        "allowed_action_types": ceiling.allowed_action_types,
        "require_approval_for": sorted(ceiling.require_approval_for),
    }


@app.put("/api/orgs/{org_id}/authority-ceiling", tags=["rbac"])
@limiter.limit("10/minute")
async def set_authority_ceiling(
    request: Request,
    org_id: str,
    req: SetAuthorityCeilingRequest,
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    """Sets the org's authority ceiling wholesale — every hosted MCP
    tool call under this org is checked against it from the next call
    onward (no restart needed, `mcp/governance_integration.py` fetches
    it fresh per call)."""
    _require_caller_owns_org(_auth, org_id)
    org = await _ready(_org_repo).get_org(org_id)
    if not org:
        raise HTTPException(404, "Organization not found")
    ceiling = OrgAuthorityCeiling(
        org_id=org_id,
        max_value_usd=req.max_value_usd,
        allowed_targets=req.allowed_targets,
        denied_targets=req.denied_targets,
        max_delegation_depth=req.max_delegation_depth,
        allowed_action_types=req.allowed_action_types,
        require_approval_for=frozenset(req.require_approval_for),
    )
    await _ready(_ceiling_repo).set(ceiling)
    return {
        "org_id": org_id,
        "max_value_usd": ceiling.max_value_usd,
        "allowed_targets": ceiling.allowed_targets,
        "denied_targets": ceiling.denied_targets,
        "max_delegation_depth": ceiling.max_delegation_depth,
        "allowed_action_types": ceiling.allowed_action_types,
        "require_approval_for": sorted(ceiling.require_approval_for),
    }


@app.get("/api/orgs/{org_id}/autonomy-budget", tags=["rbac"])
@limiter.limit("30/minute")
async def get_autonomy_budget(
    request: Request,
    org_id: str,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    """The org's Autonomy Budget (v3 authority-layer work) -- a rolling-
    window cap on how many ALLOW/ALLOW_WITH_REDACTION decisions a
    single identity may accrue before the gateway forces the next one
    to REQUIRE_APPROVAL. `configured: false` (both other fields `null`)
    means no budget is set for this org -- identical to behavior before
    this feature existed."""
    _require_caller_owns_org(_auth, org_id)
    org = await _ready(_org_repo).get_org(org_id)
    if not org:
        raise HTTPException(404, "Organization not found")
    policy = await _ready(_autonomy_budget_repo).get(org_id)
    if policy is None:
        return {
            "org_id": org_id,
            "configured": False,
            "max_autonomous_actions": None,
            "window_minutes": None,
        }
    return {
        "org_id": org_id,
        "configured": True,
        "max_autonomous_actions": policy.max_autonomous_actions,
        "window_minutes": policy.window_minutes,
    }


@app.put("/api/orgs/{org_id}/autonomy-budget", tags=["rbac"])
@limiter.limit("10/minute")
async def set_autonomy_budget(
    request: Request,
    org_id: str,
    req: SetAutonomyBudgetRequest,
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    """Sets the org's autonomy budget -- every hosted MCP tool call
    under this org is checked against it from the next call onward (no
    restart needed, `mcp/governance_integration.py` fetches it fresh
    per call)."""
    _require_caller_owns_org(_auth, org_id)
    org = await _ready(_org_repo).get_org(org_id)
    if not org:
        raise HTTPException(404, "Organization not found")
    policy = AutonomyBudgetPolicy(
        max_autonomous_actions=req.max_autonomous_actions, window_minutes=req.window_minutes
    )
    await _ready(_autonomy_budget_repo).set(org_id, policy)
    return {
        "org_id": org_id,
        "configured": True,
        "max_autonomous_actions": policy.max_autonomous_actions,
        "window_minutes": policy.window_minutes,
    }


@app.delete("/api/orgs/{org_id}/autonomy-budget", tags=["rbac"])
@limiter.limit("10/minute")
async def delete_autonomy_budget(
    request: Request,
    org_id: str,
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    """Removes the org's autonomy budget entirely -- distinct from
    `PUT` (which always requires both fields), the only way back to
    "no cap configured."""
    _require_caller_owns_org(_auth, org_id)
    org = await _ready(_org_repo).get_org(org_id)
    if not org:
        raise HTTPException(404, "Organization not found")
    await _ready(_autonomy_budget_repo).delete(org_id)
    return {"org_id": org_id, "configured": False}


@app.post("/api/orgs/{org_id}/keys", tags=["rbac"], status_code=201)
@limiter.limit("20/minute")
async def create_api_key(
    request: Request,
    org_id: str,
    req: CreateKeyRequest,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    if _auth.authentication_method == "legacy_static" or _auth.is_legacy:
        raise HTTPException(
            403,
            detail={
                "error": "LEGACY_CREDENTIAL_FORBIDDEN",
                "message": "Static or anonymous credentials cannot issue API keys.",
            },
        )
    org = await _ready(_org_repo).get_org(org_id)
    if not org:
        raise HTTPException(404, "Organization not found")
    if _auth.org_id != org_id and _auth.key_id != org.provisioner_key_id:
        raise HTTPException(404, "Organization not found")
    from sqlalchemy import select

    from responsibleai.db.engine import org_api_keys, web_memberships, web_users
    from responsibleai.enterprise.runtime import get_enterprise_engine

    engine = get_enterprise_engine()
    async with engine.raw.connect() as conn:
        key_row = (
            await conn.execute(select(org_api_keys).where(org_api_keys.c.id == _auth.key_id))
        ).fetchone()
        accountable = (
            getattr(key_row, "accountable_human_user_id", None) if key_row is not None else None
        )
        if not accountable:
            raise HTTPException(
                403,
                detail={
                    "error": "API_KEY_ISSUANCE_NOT_ALLOWED",
                    "message": "Only an IDENTITY_VERIFIED accountable human may issue reusable credentials.",
                },
            )
        user = (
            await conn.execute(select(web_users).where(web_users.c.id == accountable))
        ).fetchone()
        membership = (
            await conn.execute(
                select(web_memberships).where(
                    web_memberships.c.user_id == accountable,
                    web_memberships.c.org_id == org_id,
                )
            )
        ).fetchone()
    if user is None or membership is None:
        raise HTTPException(
            403,
            detail={
                "error": "API_KEY_ISSUANCE_NOT_ALLOWED",
                "message": "Accountable human membership is required to issue credentials.",
            },
        )
    record, raw_key = await _canonical_hosted_api_key(
        user_id=accountable,
        org_id=org_id,
        role=role_from_str(membership.role),
        name=req.name,
        environment_type="DEVELOPMENT",
        scopes=("usage:read",),
        expires_at=None,
    )
    return {**record, "key": raw_key, "id": record["id"]}


@app.get("/api/orgs/{org_id}/keys", tags=["rbac"])
@limiter.limit("60/minute")
async def list_api_keys(
    request: Request,
    org_id: str,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    org = await _ready(_org_repo).get_org(org_id)
    if not org or (_auth.org_id != org_id and _auth.key_id != org.provisioner_key_id):
        raise HTTPException(404, "Organization not found")
    keys = await _ready(_org_repo).list_keys(org_id)
    return {"keys": [k.to_dict() for k in keys]}


@app.delete("/api/orgs/{org_id}/keys/{key_id}", tags=["rbac"])
@limiter.limit("20/minute")
async def revoke_api_key(
    request: Request,
    org_id: str,
    key_id: str,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    org = await _ready(_org_repo).get_org(org_id)
    if not org or (_auth.org_id != org_id and _auth.key_id != org.provisioner_key_id):
        raise HTTPException(404, "Organization not found")
    key = await _ready(_org_repo).get_key(key_id)
    if key is None or key.org_id != org_id:
        raise HTTPException(404, "Key not found")
    revoked = await _ready(_org_repo).revoke_key(key_id, org_id=org_id)
    if not revoked:
        raise HTTPException(404, "Key not found")
    return {"revoked": key_id}


@app.post("/api/orgs/{org_id}/keys/{key_id}/mfa/enroll", tags=["rbac"])
@limiter.limit("10/minute")
async def enroll_mfa(
    request: Request,
    org_id: str,
    key_id: str,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    """Step 1 of 2: generate a TOTP secret and return it for the user to
    add to their authenticator app. Not yet active — call .../mfa/verify
    with a real code from that app to confirm enrollment. Calling this
    again before verifying replaces the pending (unconfirmed) secret."""
    _require_caller_owns_org(_auth, org_id)
    org = await _ready(_org_repo).get_org(org_id)
    if not org:
        raise HTTPException(404, "Organization not found")
    key = await _ready(_org_repo).get_key(key_id)
    if key is None or key.org_id != org_id:
        raise HTTPException(404, "Key not found")
    secret = mfa.generate_secret()
    await _ready(_org_repo).set_mfa_secret(key_id, secret)
    return {
        "secret": secret,
        "provisioning_uri": mfa.provisioning_uri(secret, account_name=key.name),
        "message": "Scan or enter this into your authenticator app, then POST the "
        "6-digit code to .../mfa/verify to activate MFA on this key.",
    }


@app.post("/api/orgs/{org_id}/keys/{key_id}/mfa/verify", tags=["rbac"])
@limiter.limit("10/minute")
async def verify_mfa(
    request: Request,
    org_id: str,
    key_id: str,
    req: MFAVerifyRequest,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    """Step 2 of 2: confirm enrollment with a real code from the
    authenticator app. Returns 10 one-time backup codes — shown exactly
    once, store them now. Each is consumed on use if the authenticator
    device is ever lost."""
    _require_caller_owns_org(_auth, org_id)
    org = await _ready(_org_repo).get_org(org_id)
    if not org:
        raise HTTPException(404, "Organization not found")
    key = await _ready(_org_repo).get_key(key_id)
    if key is None or key.org_id != org_id:
        raise HTTPException(404, "Key not found")
    if not key.mfa_secret:
        raise HTTPException(400, "No pending MFA enrollment — call .../mfa/enroll first")
    if not mfa.verify_code(key.mfa_secret, req.code):
        raise HTTPException(400, "Invalid code")
    backup_codes = mfa.generate_backup_codes()
    hashed = [mfa.hash_backup_code(c) for c in backup_codes]
    await _ready(_org_repo).confirm_mfa(key_id, hashed)
    return {
        "enrolled": True,
        "backup_codes": backup_codes,
        "message": "Store these backup codes now — they will not be shown again.",
    }


@app.delete("/api/orgs/{org_id}/keys/{key_id}/mfa", tags=["rbac"])
@limiter.limit("10/minute")
async def disable_mfa(
    request: Request,
    org_id: str,
    key_id: str,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    _require_caller_owns_org(_auth, org_id)
    org = await _ready(_org_repo).get_org(org_id)
    if not org:
        raise HTTPException(404, "Organization not found")
    key = await _ready(_org_repo).get_key(key_id)
    if key is None or key.org_id != org_id:
        raise HTTPException(404, "Key not found")
    await _ready(_org_repo).disable_mfa(key_id)
    return {"org_id": org_id, "key_id": key_id, "mfa_enrolled": False}


# ── Billing (Stripe) ───────────────────────────────────────────────────────────


@app.get("/api/billing/plans", tags=["billing"])
@limiter.limit("60/minute")
async def get_billing_plans(request: Request) -> dict[str, Any]:
    """Public — plan tiers, pricing, and which MCP tools each tier unlocks."""
    return plan_catalog()


@app.post("/api/billing/checkout", tags=["billing"])
@limiter.limit("10/minute")
async def create_checkout_session(
    request: Request,
    req: CheckoutRequest,
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    if _stripe_service is None:
        raise HTTPException(503, "Billing is not configured on this server.")
    if not _auth.org_id:
        raise HTTPException(400, "Checkout requires an org-scoped API key, not a legacy flat key.")

    org = await _ready(_org_repo).get_org(_auth.org_id)
    if not org:
        raise HTTPException(404, "Organization not found")

    try:
        url = await _stripe_service.create_checkout_session(
            org_id=_auth.org_id,
            org_email=req.org_email,
            plan=Plan(req.plan),
            success_url=settings.billing_success_url,
            cancel_url=settings.billing_cancel_url,
            existing_customer_id=org.stripe_customer_id,
        )
    except StripeBillingError as exc:
        raise HTTPException(400, str(exc)) from exc

    return {"checkout_url": url}


@app.post("/api/billing/portal", tags=["billing"])
@limiter.limit("10/minute")
async def create_portal_session(
    request: Request,
    req: BillingPortalRequest,
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    if _stripe_service is None:
        raise HTTPException(503, "Billing is not configured on this server.")
    if not _auth.org_id:
        raise HTTPException(400, "Billing portal requires an org-scoped API key.")

    org = await _ready(_org_repo).get_org(_auth.org_id)
    if not org or not org.stripe_customer_id:
        raise HTTPException(404, "No active Stripe customer for this organization.")

    try:
        url = await _stripe_service.create_billing_portal_session(
            customer_id=org.stripe_customer_id,
            return_url=_safe_billing_return_url(req.return_url),
        )
    except StripeBillingError as exc:
        raise HTTPException(400, str(exc)) from exc

    return {"portal_url": url}


@app.get("/api/billing/usage/mcp", tags=["billing"])
@limiter.limit("30/minute")
async def get_mcp_usage(
    request: Request,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """This org's hosted MCP tool call volume for the current billing month."""
    if _mcp_usage_repo is None:
        raise HTTPException(503, "MCP usage metering not initialised.")
    if not _auth.org_id:
        raise HTTPException(400, "MCP usage requires an org-scoped API key, not a legacy flat key.")
    usage = await _ready(_mcp_usage_repo).usage_this_month(_auth.org_id)
    quota = monthly_quota(_auth.plan)
    return {
        **usage,
        "plan": _auth.plan.value,
        "monthly_quota": quota,
        "quota_remaining": (quota - usage["allowed_calls"]) if quota is not None else None,
    }


@app.get("/api/billing/usage/mcp/top", tags=["billing"], include_in_schema=False)
@limiter.limit("10/minute")
async def get_mcp_usage_leaderboard(
    request: Request,
    days: int = Query(30, ge=1, le=365),
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    """Platform-wide MCP usage by org — founder/ops visibility, not customer-facing."""
    if not (_auth.is_legacy and _auth.role == Role.OWNER):
        raise HTTPException(403, "Usage leaderboard requires super-admin access")
    if _mcp_usage_repo is None:
        raise HTTPException(503, "MCP usage metering not initialised.")
    rows = await _ready(_mcp_usage_repo).top_orgs_by_volume(days=days)
    return {"days": days, "orgs": rows}


@app.post("/api/billing/webhook", tags=["billing"], include_in_schema=False)
async def stripe_webhook(request: Request) -> dict[str, Any]:
    """Stripe calls this directly — verified by signature, not by API key."""
    if _stripe_service is None:
        raise HTTPException(503, "Billing is not configured on this server.")

    payload = await request.body()
    sig_header = request.headers.get("stripe-signature", "")

    try:
        event = _stripe_service.verify_and_parse_webhook(payload, sig_header)
    except StripeBillingError as exc:
        raise HTTPException(400, str(exc)) from exc

    event_id = str(getattr(event, "id", "") or "")
    event_type = str(getattr(event, "type", "unknown"))
    if not event_id:
        raise HTTPException(400, "Stripe event ID is required.")
    update = _stripe_service.extract_plan_update(event)
    org_id = update.org_id if update else None
    if not await _ready(_billing_event_repo).begin(event_id, event_type, org_id):
        return {"received": True, "processed": False, "duplicate": True}
    if update is None:
        await _ready(_billing_event_repo).complete(event_id)
        return {"received": True, "processed": False, "duplicate": False}
    try:
        await _ready(_org_repo).set_plan(
            org_id=update.org_id,
            plan=update.plan,
            stripe_customer_id=update.stripe_customer_id,
            stripe_subscription_id=update.stripe_subscription_id,
            plan_renews_at=update.plan_renews_at,
            subscription_status=update.subscription_status,
        )
        await _ready(_billing_event_repo).complete(event_id)
    except Exception as exc:
        await _ready(_billing_event_repo).fail(event_id, str(exc))
        raise
    logger.info(
        "billing_plan_updated",
        org_id=update.org_id,
        plan=update.plan.value,
    )
    return {"received": True, "processed": True}


@app.post("/api/billing/paddle/webhook", tags=["billing"], include_in_schema=False)
async def paddle_webhook(request: Request) -> dict[str, Any]:
    """Paddle Billing calls this directly — verified by HMAC-SHA256 signature."""
    secret_key = settings.paddle_webhook_secret or os.environ.get("PADDLE_WEBHOOK_SECRET", "")
    if not secret_key:
        raise HTTPException(503, "Paddle billing is not configured on this server.")

    raw_body = await request.body()
    sig_header = request.headers.get("paddle-signature", "")
    if not sig_header:
        raise HTTPException(400, "Missing Paddle-Signature header.")

    sig_parts = dict(re.findall(r"([a-z0-9_]+)=([^;]+)", sig_header))
    ts_str = sig_parts.get("ts")
    h1 = sig_parts.get("h1")
    if not ts_str or not h1:
        raise HTTPException(400, "Malformed Paddle-Signature header.")

    try:
        ts = int(ts_str)
    except ValueError:
        raise HTTPException(400, "Invalid timestamp in Paddle-Signature header.") from None

    tolerance = getattr(settings, "paddle_signature_tolerance_seconds", 300)
    now_ts = int(datetime.now(UTC).timestamp())
    if (now_ts - ts) > tolerance:
        raise HTTPException(400, f"Paddle webhook signature has expired (> {tolerance}s).")
    if (ts - now_ts) > tolerance:
        raise HTTPException(
            400, f"Paddle webhook signature timestamp is in the future (> {tolerance}s)."
        )

    signed_payload = f"{ts_str}:".encode() + raw_body
    computed_sig = hmac.new(secret_key.encode("utf-8"), signed_payload, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(computed_sig, h1):
        raise HTTPException(400, "Invalid Paddle webhook signature.")

    try:
        payload = json.loads(raw_body.decode("utf-8"))
    except Exception as exc:
        raise HTTPException(400, "Invalid JSON in Paddle webhook payload.") from exc

    event_id = str(payload.get("event_id") or "")
    event_type = str(payload.get("event_type") or "unknown")
    if not event_id:
        raise HTTPException(400, "Paddle event_id is required.")

    occurred_at = payload.get("occurred_at")
    if not occurred_at or not isinstance(occurred_at, str):
        raise HTTPException(400, "Missing occurred_at in Paddle webhook payload.")

    data = payload.get("data", {})
    if not isinstance(data, dict):
        data = {}

    subscription_id = data.get("id")
    customer_id = data.get("customer_id")
    entity_id = subscription_id or customer_id or event_id

    payload_hash = hashlib.sha256(raw_body).hexdigest()

    try:
        is_new = await _ready(_paddle_event_repo).begin(
            event_id, event_type, payload_hash, occurred_at=occurred_at, entity_id=entity_id
        )
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from exc

    if not is_new:
        return {"received": True, "processed": False, "duplicate": True}

    if event_type not in PADDLE_SUBSCRIPTION_ENTITLEMENT_EVENTS:
        await _ready(_paddle_event_repo).complete(event_id, org_id=None)
        return {"received": True, "processed": False, "ignored_event_type": True}

    try:
        custom_org_id = (
            data.get("custom_data", {}).get("org_id")
            if isinstance(data.get("custom_data"), dict)
            else None
        )

        # Cross-tenant reassignment protection: verify existing customer/subscription mappings
        cust_org = (
            await _ready(_org_repo).get_org_by_paddle_customer(customer_id) if customer_id else None
        )
        sub_org = (
            await _ready(_org_repo).get_org_by_paddle_subscription(subscription_id)
            if subscription_id
            else None
        )

        if cust_org and custom_org_id and custom_org_id != cust_org.id:
            raise HTTPException(
                409,
                f"Paddle customer is already bound to org {cust_org.id}; cannot reassign to {custom_org_id}.",
            )
        if sub_org and custom_org_id and custom_org_id != sub_org.id:
            raise HTTPException(
                409,
                f"Paddle subscription is already bound to org {sub_org.id}; cannot reassign to {custom_org_id}.",
            )
        if cust_org and sub_org and cust_org.id != sub_org.id:
            raise HTTPException(
                409, "Paddle customer and subscription are bound to conflicting organizations."
            )

        org_id = custom_org_id or (cust_org.id if cust_org else (sub_org.id if sub_org else None))

        if not org_id:
            await _ready(_paddle_event_repo).complete(event_id, org_id=None)
            return {"received": True, "processed": False, "unmapped_org": True}

        # Verify target org exists and is not tombstoned
        org = await _ready(_org_repo).get_org(org_id)
        if org is None:
            raise HTTPException(404, f"Organization '{org_id}' not found.")

        async with _ready(_db_engine).raw.begin() as conn:
            from sqlalchemy import select

            from responsibleai.db.engine import tenant_tombstones

            ts_row = (
                await conn.execute(
                    select(tenant_tombstones.c.id).where(tenant_tombstones.c.org_id == org_id)
                )
            ).first()
            if ts_row is not None:
                raise HTTPException(
                    409, f"Cannot apply entitlement: organization '{org_id}' is tombstoned."
                )

        await _ready(_paddle_event_repo).set_org(event_id, org_id)

        status = str(data.get("status", "inactive")).casefold()
        custom_plan = (
            data.get("custom_data", {}).get("plan")
            if isinstance(data.get("custom_data"), dict)
            else None
        )
        if custom_plan:
            try:
                plan = Plan(str(custom_plan).upper())
            except ValueError:
                plan = Plan.PRO
        else:
            plan = Plan.PRO if status in {"active", "trialing"} else Plan.FREE

        if not customer_id:
            customer_id = org.paddle_customer_id or f"ctm_inferred_{org_id}"

        applied = await _ready(_org_repo).apply_paddle_entitlement(
            org_id=org_id,
            customer_id=customer_id,
            subscription_id=subscription_id,
            plan=plan,
            subscription_status=status,
            occurred_at=occurred_at,
            updated_at=occurred_at,
        )
        if not applied:
            await _ready(_paddle_event_repo).complete(event_id, org_id=org_id)
            return {"received": True, "processed": False, "stale_event_ignored": True}

        await _ready(_paddle_event_repo).complete(event_id, org_id=org_id)
    except HTTPException:
        await _ready(_paddle_event_repo).fail(event_id, "HTTP error during processing")
        raise
    except ValueError as exc:
        await _ready(_paddle_event_repo).fail(event_id, str(exc))
        if "tombstoned" in str(exc).lower() or "already bound" in str(exc).lower():
            raise HTTPException(409, str(exc)) from exc
        if "not found" in str(exc).lower():
            raise HTTPException(404, str(exc)) from exc
        raise HTTPException(400, str(exc)) from exc
    except Exception as exc:
        await _ready(_paddle_event_repo).fail(event_id, str(exc))
        raise

    logger.info("paddle_webhook_processed", event_id=event_id, event_type=event_type, org_id=org_id)
    return {"received": True, "processed": True}


# ── Model Evaluation Framework ────────────────────────────────────────────────


@app.post("/api/eval/compare", tags=["eval"], status_code=201)
@limiter.limit("20/minute")
async def eval_compare(
    request: Request,
    req: EvalCompareRequest,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    prompts = [
        EvalPrompt(
            id=p.get("id", ""),
            prompt=p.get("prompt", ""),
            expected=p.get("expected", ""),
            category=p.get("category", ""),
        )
        for p in req.prompts
    ]
    ra = [
        ModelResponse(
            prompt_id=r.get("prompt_id", ""),
            model=req.model_a,
            provider=req.provider_a,
            response=r.get("response", ""),
        )
        for r in req.responses_a
    ]
    rb = [
        ModelResponse(
            prompt_id=r.get("prompt_id", ""),
            model=req.model_b,
            provider=req.provider_b,
            response=r.get("response", ""),
        )
        for r in req.responses_b
    ]
    result = _ready(_comparator).compare(
        prompts=prompts,
        responses_a=ra,
        responses_b=rb,
        model_a=req.model_a,
        model_b=req.model_b,
        provider_a=req.provider_a,
        provider_b=req.provider_b,
    )
    payload = result.to_dict()
    if _eval_repo:
        await _eval_repo.save_run(
            run_type="comparison",
            model=f"{req.model_a}|{req.model_b}",
            payload=payload,
            provider=f"{req.provider_a}|{req.provider_b}",
            org_id=_auth.org_id,
        )
    return payload


@app.post("/api/eval/benchmark", tags=["eval"], status_code=201)
@limiter.limit("10/minute")
async def eval_benchmark(
    request: Request,
    req: EvalBenchmarkRequest,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    suite = BenchmarkSuite(req.suite)
    result = _ready(_benchmark_runner).run(
        model=req.model,
        provider=req.provider,
        suite=suite,
        responses=req.responses,
    )
    payload = result.to_dict()
    if _eval_repo:
        await _eval_repo.save_run(
            run_type="benchmark",
            model=req.model,
            payload=payload,
            provider=req.provider,
            suite=req.suite,
            org_id=_auth.org_id,
        )
    if req.set_as_baseline:
        _regression_detector.set_baseline(req.model, result)
        if _eval_repo:
            for metric in ("accuracy", "bias_rate", "overall_score"):
                score = getattr(result, metric)
                await _eval_repo.set_baseline(
                    model=req.model,
                    suite=req.suite,
                    metric=metric,
                    score=score,
                    org_id=_auth.org_id,
                )
    regressions = _regression_detector.check(req.model, result)
    payload["regressions"] = [r.to_dict() for r in regressions]
    return payload


@app.get("/api/eval/benchmark/prompts/{suite}", tags=["eval"])
@limiter.limit("60/minute")
async def eval_benchmark_prompts(
    request: Request,
    suite: str,
    _auth: OrgContext = Depends(require_role(Role.VIEWER)),
) -> dict[str, Any]:
    try:
        s = BenchmarkSuite(suite)
    except ValueError:
        raise HTTPException(
            400, f"Unknown suite: {suite}. Valid: truthfulqa, bbq, hellaswag"
        ) from None
    prompts = _ready(_benchmark_runner).get_prompts(s)
    return {"suite": suite, "prompts": prompts, "count": len(prompts)}


@app.get("/api/eval/regression/{model}", tags=["eval"])
@limiter.limit("60/minute")
async def eval_regression(
    request: Request,
    model: str,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    baselines = _regression_detector.get_baselines(model)
    db_baselines: dict[str, float] = {}
    if _eval_repo:
        db_baselines = await _eval_repo.get_baselines(model)
    return {
        "model": model,
        "in_memory_baselines": baselines,
        "db_baselines": db_baselines,
        "has_baseline": bool(baselines or db_baselines),
    }


@app.post("/api/eval/dataset-scan", tags=["eval"], status_code=201)
@limiter.limit("10/minute")
async def eval_dataset_scan(
    request: Request,
    req: EvalDatasetScanRequest,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    result = _ready(_dataset_scanner).scan_texts(req.texts, filename=req.filename)
    payload = result.to_dict()
    if _eval_repo:
        await _eval_repo.save_run(
            run_type="dataset_scan",
            model="dataset",
            payload=payload,
            org_id=_auth.org_id,
        )
    return payload


@app.get("/api/eval/results", tags=["eval"])
@limiter.limit("30/minute")
async def eval_results(
    request: Request,
    run_type: str | None = Query(default=None),
    model: str | None = Query(default=None),
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    if not _eval_repo:
        return {"runs": [], "count": 0}
    runs = await _eval_repo.list_runs(
        run_type=run_type,
        model=model,
        org_id=_auth.org_id,
        limit=limit,
        offset=offset,
    )
    return {"runs": runs, "count": len(runs)}


# ── Audit log ─────────────────────────────────────────────────────────────────


@app.get("/api/audit-log", tags=["rbac"])
@limiter.limit("30/minute")
async def query_audit_log(
    request: Request,
    days: int = Query(default=7, ge=1, le=90),
    org_id: str | None = Query(default=None, description="Cross-org filter (super-admin only)"),
    endpoint: str | None = Query(default=None),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    scoped_org_id: str | None
    if _auth.org_id is not None:
        scoped_org_id = _auth.org_id
    elif _auth.is_legacy and _auth.role == Role.OWNER:
        scoped_org_id = org_id
    else:
        scoped_org_id = None
    entries = await _ready(_audit_repo).query(
        org_id=scoped_org_id, endpoint=endpoint, days=days, limit=limit, offset=offset
    )
    total = await _ready(_audit_repo).count(days=days, org_id=scoped_org_id)
    summary = await _ready(_audit_repo).endpoint_summary(days=days)
    return {
        "entries": entries,
        "total": total,
        "limit": limit,
        "offset": offset,
        "endpoint_summary": summary,
    }


# ── Incidents ──────────────────────────────────────────────────────────────────
# Real, wired persistence for governance incident records — closes the gap the
# 2026-07-21 tabletop drill found: rai_incident_log's MCP output used to be
# ephemeral with no server-side endpoint to send it to. See
# compliance/TABLETOP_EXERCISE_2026-07-21.md and INCIDENT_RESPONSE_RUNBOOK.md.

# Alertmanager sends "critical" | "warning" | "info" (or whatever a deployer's
# alert rules set) — mapped onto this platform's four-tier incident severity
# scale (see compliance/INCIDENT_RESPONSE_RUNBOOK.md's severity table).
_ALERTMANAGER_SEVERITY_MAP = {
    "critical": "critical",
    "warning": "medium",
    "info": "low",
    "page": "critical",
}


def _incident_type_from_alertname(alertname: str) -> str:
    """Best-effort classification from Prometheus alert rule names (see
    grafana/prometheus/alert-rules.yml) onto rai_incident_log's incident_type
    enum. Falls back to "other" rather than guessing wrong."""
    name = alertname.lower()
    if "drift" in name:
        return "drift_alert"
    if "guardrail" in name or "pii" in name:
        return "policy_violation"
    if "cost" in name or "budget" in name or "spend" in name:
        return "cost_overrun"
    return "other"


@app.post("/api/incidents", tags=["incidents"], status_code=201)
@limiter.limit("60/minute")
async def create_incident(
    request: Request,
    req: IncidentCreateRequest,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    record = build_incident_record(
        incident_type=req.incident_type,
        severity=req.severity,
        model_name=req.model_name,
        provider=req.provider,
        description=req.description,
        evidence=req.evidence,
        mitigated=req.mitigated,
        source="manual",
    )
    stored = await _ready(_incident_repo).create(record, org_id=_auth.org_id)
    logger.info(
        "incident_created",
        incident_id=stored["incident_id"],
        severity=stored["severity"],
        incident_type=stored["incident_type"],
        org_id=_auth.org_id,
    )
    return stored


@app.get("/api/incidents", tags=["incidents"])
@limiter.limit("60/minute")
async def list_incidents(
    request: Request,
    severity: str | None = Query(default=None),
    status: str | None = Query(default=None),
    days: int = Query(default=90, ge=1, le=365),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    org_id: str | None = Query(default=None, description="Cross-org filter (super-admin only)"),
    _auth: OrgContext = Depends(require_role(Role.VIEWER)),
) -> dict[str, Any]:
    scoped_org_id: str | None
    if _auth.org_id is not None:
        scoped_org_id = _auth.org_id
    elif _auth.is_legacy and _auth.role == Role.OWNER:
        scoped_org_id = org_id
    else:
        scoped_org_id = None
    incidents_list = await _ready(_incident_repo).list(
        org_id=scoped_org_id,
        severity=severity,
        status=status,
        days=days,
        limit=limit,
        offset=offset,
    )
    return {"incidents": incidents_list, "limit": limit, "offset": offset}


@app.get("/api/incidents/{incident_id}", tags=["incidents"])
@limiter.limit("120/minute")
async def get_incident(
    request: Request,
    incident_id: str,
    _auth: OrgContext = Depends(require_role(Role.VIEWER)),
) -> dict[str, Any]:
    record = await _ready(_incident_repo).get(incident_id)
    if record is None:
        raise HTTPException(404, "Incident not found.")
    is_super_admin = _auth.is_legacy and _auth.role == Role.OWNER
    if not is_super_admin and record["org_id"] is not None and record["org_id"] != _auth.org_id:
        raise HTTPException(404, "Incident not found.")
    return record


@app.post("/api/alerts/webhook", tags=["incidents"], include_in_schema=False)
async def alerts_webhook(request: Request) -> dict[str, Any]:
    """Prometheus Alertmanager calls this directly — configure a
    `webhook_configs` receiver pointing here with
    `http_config.authorization.credentials` set to RAI_ALERTS_WEBHOOK_TOKEN.
    Verified by bearer token, not by org-scoped API key, since Alertmanager
    has no concept of an org."""
    if not settings.alerts_webhook_token:
        raise HTTPException(503, "Alertmanager webhook bridge is not configured on this server.")

    auth_header = request.headers.get("Authorization", "")
    if auth_header != f"Bearer {settings.alerts_webhook_token}":
        raise HTTPException(401, "Missing or invalid bearer token.")

    payload = await request.json()
    alerts = payload.get("alerts", [])
    created: list[str] = []
    skipped = 0

    for alert in alerts:
        if alert.get("status") != "firing":
            skipped += 1
            continue
        labels = alert.get("labels", {})
        annotations = alert.get("annotations", {})
        alertname = str(labels.get("alertname", "UnknownAlert"))
        severity = _ALERTMANAGER_SEVERITY_MAP.get(str(labels.get("severity", "")).lower(), "medium")
        description = str(
            annotations.get("description") or annotations.get("summary") or alertname
        )[:5000]

        record = build_incident_record(
            incident_type=_incident_type_from_alertname(alertname),
            severity=severity,
            model_name=str(labels.get("model", "unknown")),
            provider=str(labels.get("provider", "unknown")),
            description=f"[{alertname}] {description}",
            evidence={"labels": labels, "annotations": annotations},
            mitigated=False,
            source="alertmanager",
        )
        stored = await _ready(_incident_repo).create(record, org_id=None, raw_payload=alert)
        created.append(stored["incident_id"])
        logger.info(
            "incident_created_from_alert",
            incident_id=stored["incident_id"],
            alertname=alertname,
            severity=severity,
        )

    return {"received": True, "incidents_created": created, "alerts_skipped": skipped}


# ── Public cross-model trust leaderboard ────────────────────────────────────────
# Free, public leaderboard (GET /api/leaderboard, /history) — no auth required,
# by design: the leaderboard is a marketing/awareness surface, not customer
# data. The per-prompt diagnostic ("here's exactly which prompts caused the
# score to drop") is gated behind require_plan(Plan.PRO) — that's the paid
# product this feature funds itself with. See compliance/LEADERBOARD_METHODOLOGY.md
# for the published scoring methodology and STRATEGY_ROADMAP.md's Tier-1
# feature #1 for why this exists.


def _leaderboard_super_admin_check(_auth: OrgContext) -> None:
    if not (_auth.is_legacy and _auth.role == Role.OWNER):
        raise HTTPException(403, "Leaderboard administration requires super-admin access")


_DIAGNOSTIC_ONLY_KEYS = {"findings", "findings_count"}


def _strip_diagnostic_fields(row: dict[str, Any]) -> dict[str, Any]:
    """Free-tier view of a stored run — omits the paid per-prompt findings."""
    return {k: v for k, v in row.items() if k not in _DIAGNOSTIC_ONLY_KEYS}


@app.get("/api/leaderboard", tags=["leaderboard"])
@limiter.limit("120/minute")
async def get_leaderboard(request: Request) -> dict[str, Any]:
    """Public, unauthenticated. Current ranked list — one row per tracked
    model, its most recent evaluation run, sorted by overall_score desc."""
    rows = await _ready(_leaderboard_repo).ranked_leaderboard()
    return {
        "leaderboard": [_strip_diagnostic_fields(row) for row in rows],
        "methodology_version": METHODOLOGY_VERSION,
        "methodology_url": "https://github.com/Guruprasath-Annadurai/ResponsibleAi/blob/main/compliance/LEADERBOARD_METHODOLOGY.md",
    }


@app.get("/api/leaderboard/{model}/{provider}/history", tags=["leaderboard"])
@limiter.limit("60/minute")
async def get_leaderboard_history(
    request: Request,
    model: str,
    provider: str,
    limit: int = Query(default=30, ge=1, le=200),
) -> dict[str, Any]:
    """Public, unauthenticated. Trend over time for one model."""
    rows = await _ready(_leaderboard_repo).history(model, provider, limit=limit)
    if not rows:
        raise HTTPException(404, "No leaderboard runs found for this model/provider.")
    return {
        "model": model,
        "provider": provider,
        "history": [_strip_diagnostic_fields(row) for row in rows],
    }


@app.get("/api/leaderboard/{model}/{provider}/diagnostic", tags=["leaderboard"])
@limiter.limit("30/minute")
async def get_leaderboard_diagnostic(
    request: Request,
    model: str,
    provider: str,
    _auth: OrgContext = Depends(require_plan(Plan.PRO)),
) -> dict[str, Any]:
    """PRO/ENTERPRISE only — the paid deep-dive: every specific prompt that
    caused the score to drop, categorized, with severity."""
    row = await _ready(_leaderboard_repo).latest_run(model, provider)
    if row is None:
        raise HTTPException(404, "No leaderboard runs found for this model/provider.")
    return row


@app.get("/api/leaderboard/models", tags=["leaderboard"])
@limiter.limit("30/minute")
async def list_leaderboard_models(
    request: Request,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    _leaderboard_super_admin_check(_auth)
    return {"models": await _ready(_leaderboard_repo).list_models()}


@app.post("/api/leaderboard/models", tags=["leaderboard"], status_code=201)
@limiter.limit("10/minute")
async def register_leaderboard_model(
    request: Request,
    req: LeaderboardModelRegisterRequest,
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    _leaderboard_super_admin_check(_auth)
    adapter_name = req.provider if req.provider != "mock" else "mock"
    stored = await _ready(_leaderboard_repo).register_model(
        model=req.model,
        provider=req.provider,
        display_name=req.display_name,
        adapter=adapter_name,
        active=req.active,
    )
    logger.info("leaderboard_model_registered", model=req.model, provider=req.provider)
    return stored


@app.post("/api/leaderboard/run", tags=["leaderboard"])
@limiter.limit("5/minute")
async def run_leaderboard_eval(
    request: Request,
    model: str | None = Query(default=None),
    provider: str | None = Query(default=None),
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    """Super-admin only. Triggers a live evaluation run synchronously — fine
    for one model or a small registry (~55 model calls each); for a large
    registry, prefer scripts/run_leaderboard_eval.py on a schedule (cron)
    instead of this endpoint, since a big run can take minutes per model and
    ties up the request for that whole time."""
    _leaderboard_super_admin_check(_auth)

    if model and provider:
        target = await _ready(_leaderboard_repo).get_model(model, provider)
        if target is None:
            raise HTTPException(404, f"Model {provider}/{model} is not registered.")
        targets = [target]
    else:
        targets = await _ready(_leaderboard_repo).list_models(active_only=True)

    if not targets:
        return {"runs_completed": [], "runs_failed": []}

    completed: list[dict[str, Any]] = []
    failed: list[dict[str, Any]] = []
    for t in targets:
        try:
            adapter = get_adapter(
                t["adapter"],
                t["model"],
                settings.leaderboard_api_keys,
                azure_openai_endpoint=settings.leaderboard_azure_openai_endpoint,
                azure_openai_api_version=settings.leaderboard_azure_openai_api_version,
            )
            result = await _ready(_leaderboard_runner).run_model(t["model"], t["provider"], adapter)
            stored = await _ready(_leaderboard_repo).create_run(result)
            completed.append(
                {
                    "model": t["model"],
                    "provider": t["provider"],
                    "run_id": stored["id"],
                    "overall_score": stored["overall_score"],
                }
            )
            logger.info(
                "leaderboard_run_completed",
                model=t["model"],
                provider=t["provider"],
                overall_score=stored["overall_score"],
            )
        except ProviderNotConfiguredError as exc:
            failed.append({"model": t["model"], "provider": t["provider"], "reason": str(exc)})
            logger.warning(
                "leaderboard_run_skipped", model=t["model"], provider=t["provider"], reason=str(exc)
            )

    return {"runs_completed": completed, "runs_failed": failed}


# ── Trust Index — open, versioned scoring standard ──────────────────────────────
# Free, public self-assessment and verification (POST /assess, GET /verify) — the
# standard itself and the ability to get scored against it cost nothing, on
# purpose: free things become the thing everyone cites (OWASP Top 10, PCI-DSS).
# Certification (POST /certify) is the paid, audited product this funds itself
# with — a self-reported score and a certified one are never conflated; every
# verify response says which one it is. See compliance/TRUST_INDEX_SPEC.md.


def _trust_index_super_admin_check(_auth: OrgContext) -> None:
    if not (_auth.is_legacy and _auth.role == Role.OWNER):
        raise HTTPException(403, "Trust Index certification requires super-admin access")


@app.post("/api/trust-index/assess", tags=["trust-index"], status_code=201, include_in_schema=True)
@limiter.limit("20/minute")
async def trust_index_assess(request: Request, req: TrustIndexAssessRequest) -> dict[str, Any]:
    """Public, unauthenticated, free — score any model against the open Trust
    Index standard and get back a durable, independently-verifiable record.
    No org context required: self-assessment doesn't need an account."""
    score = _ready(_trust_engine).compute(
        fairness=req.fairness,
        privacy=req.privacy,
        security=req.security,
        robustness=req.robustness,
        compliance=req.compliance,
        authenticity=req.authenticity,
    )
    passport = _ready(_passport_gen).generate(
        model_name=req.model_name,
        provider=req.provider,
        trust_score=score,
    )
    stored = await _ready(_passport_repo).create(passport, org_id=None, source="self_assessment")
    logger.info(
        "trust_index_self_assessment",
        model=req.model_name,
        provider=req.provider,
        overall_score=score.overall,
    )
    return {
        **stored,
        "citation": f"Scored {score.overall}/100 (Grade {score.grade}) under the "
        f"ResponsibleAI Trust Index v{passport.version} — self-reported, not certified. "
        f"Verify at /api/trust-index/verify/{passport.passport_id}",
        "verify_url": f"/api/trust-index/verify/{passport.passport_id}",
    }


@app.get("/api/trust-index/verify/{passport_id}", tags=["trust-index"])
@limiter.limit("120/minute")
async def trust_index_verify(request: Request, passport_id: str) -> dict[str, Any]:
    """Public, unauthenticated. The whole point of a citable standard: anyone
    who sees a cited score can check it's real here, not just trust the claim."""
    record = await _ready(_passport_repo).get(passport_id)
    if record is None:
        raise HTTPException(
            404, "No Trust Passport found with this ID — the cited score cannot be verified."
        )
    return record


@app.get("/api/trust-index/badge/{passport_id}.svg", tags=["trust-index"], include_in_schema=True)
@limiter.limit("300/minute")
async def trust_index_badge(request: Request, passport_id: str) -> Response:
    """Public, unauthenticated — the embeddable badge image behind the
    free/paid split: a self-assessed passport renders 'Self-Assessed', a
    human-reviewed one (see POST /certify above) renders 'Certified'. Same
    endpoint, same mechanism, the underlying `certified` flag is the only
    difference — see trust/badge.py and STRATEGY_ROADMAP.md Part 0 Item 3."""
    record = await _ready(_passport_repo).get(passport_id)
    if record is None:
        raise HTTPException(404, "No Trust Passport found with this ID.")
    svg = render_badge_svg(
        grade=record["trust_score"]["grade"],
        overall_score=record["trust_score"]["overall"],
        certified=record["certified"],
    )
    return Response(
        content=svg,
        media_type="image/svg+xml",
        headers={"Cache-Control": "public, max-age=3600"},
    )


@app.get("/api/trust-index/check", tags=["trust-index"])
@limiter.limit("120/minute")
async def trust_index_check(
    request: Request,
    model: str = Query(..., min_length=1, max_length=100),
    provider: str = Query(..., min_length=1, max_length=100),
) -> dict[str, Any]:
    """Public, unauthenticated, free — the one endpoint the LangChain/
    LangGraph/ADK integrations under `src/responsibleai/integrations/`
    call before letting an agent invoke a third-party model or tool.
    Exact model+provider match, same contract as
    `GET /api/incident-db/check`'s CI/CD deploy-gate guarantee — but
    unlike that PRO/ENTERPRISE endpoint, this is free and only surfaces a
    best-effort incident count (up to 5 recent published entries) rather
    than the full, guaranteed-fresh incident feed. That split preserves
    the paid pre-deployment-check product while still letting an
    unauthenticated agent framework ask "is this trustworthy" for free."""
    passport = await _ready(_passport_repo).get_latest_by_model(model, provider)
    incidents = await _ready(_public_incident_repo).list_published(
        model=model,
        provider=provider,
        limit=5,
    )
    base = {
        "model": model,
        "provider": provider,
        "has_reported_incidents": len(incidents) > 0,
        "recent_incidents": incidents,
    }
    if passport is None:
        return {
            **base,
            "known": False,
            "trust_score": None,
            "certified": False,
            "passport_id": None,
            "verify_url": None,
            "message": "No Trust Index assessment on file for this model/provider. "
            "Self-assess for free at POST /api/trust-index/assess.",
        }
    return {
        **base,
        "known": True,
        "trust_score": passport["trust_score"],
        "certified": passport["certified"],
        "passport_id": passport["passport_id"],
        "verify_url": f"/api/trust-index/verify/{passport['passport_id']}",
    }


@app.get("/api/trust-index/registry", tags=["trust-index"])
@limiter.limit("60/minute")
async def trust_index_registry(
    request: Request,
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> dict[str, Any]:
    """Public, unauthenticated — every assessed model/tool, certified and
    self-reported alike, newest first. The public Trust Registry
    GAME_CHANGER_STRATEGY.md Section 3 calls the acquisition mechanism:
    unlike `/certified` below (a curated 'who passed review' list), this
    is the full directory a badge embed or a search engine should be able
    to land on. `certified` is included per row so nothing here implies a
    self-report is independently reviewed."""
    rows = await _ready(_passport_repo).list_recent(limit=limit, offset=offset)
    return {"registry": rows, "limit": limit, "offset": offset}


@app.get("/api/trust-index/certified", tags=["trust-index"])
@limiter.limit("60/minute")
async def trust_index_certified_directory(
    request: Request,
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> dict[str, Any]:
    """Public, unauthenticated. The 'who's actually certified' directory —
    reinforces the standard's value by making certification checkable in bulk,
    not just one ID at a time."""
    rows = await _ready(_passport_repo).list_certified(limit=limit, offset=offset)
    return {"certified": rows, "limit": limit, "offset": offset}


@app.post("/api/trust-index/certify/{passport_id}", tags=["trust-index"])
@limiter.limit("10/minute")
async def trust_index_certify(
    request: Request,
    passport_id: str,
    req: TrustIndexCertifyRequest,
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    """Super-admin only. Certification is a human-reviewed attestation, same
    as any real certification body — there is no automated path to a
    'certified' badge, by design; that's what makes the badge worth anything."""
    _trust_index_super_admin_check(_auth)
    updated = await _ready(_passport_repo).certify(passport_id, certified_by=req.certified_by)
    if updated is None:
        raise HTTPException(404, "No Trust Passport found with this ID.")
    logger.info("trust_index_certified", passport_id=passport_id, certified_by=req.certified_by)
    return updated


# ── Public AI Incident Database — "the CVE database for AI failures" ────────────
# Anyone can report (POST /report, strictly rate-limited — this is the spam
# surface). Nothing is publicly visible until a super-admin reviews it
# (moderation queue, same posture as Trust Index certification: no automated
# publish path). Once published, entries are hash-chained the same way the
# internal audit log is, and GET /verify is public — unlike the internal
# audit chain, anyone should be able to check this database's integrity, not
# just the operator. GET /check is the paid product: "has anything been
# reported against the model I'm about to deploy," gated at PRO plan for
# real programmatic/CI use, same free-browse/paid-integration split as the
# leaderboard's diagnostic tier.


def _incident_db_super_admin_check(_auth: OrgContext) -> None:
    if not (_auth.is_legacy and _auth.role == Role.OWNER):
        raise HTTPException(403, "AI Incident Database moderation requires super-admin access")


@app.post("/api/incident-db/report", tags=["incident-db"], status_code=201)
@limiter.limit("5/hour")
async def incident_db_report(request: Request, req: IncidentReportRequest) -> dict[str, Any]:
    """Public, unauthenticated — anyone can report a publicly observed AI
    incident. Held as PENDING_REVIEW until a super-admin approves it; never
    visible in the public listing before that. Strictly rate-limited (5/hour
    per IP) since this is the one endpoint on this feature with no auth gate
    at all."""
    stored = await _ready(_public_incident_repo).submit(
        title=req.title,
        description=req.description,
        incident_type=req.incident_type,
        severity=req.severity,
        affected_model=req.affected_model,
        affected_provider=req.affected_provider,
        affected_version=req.affected_version,
        reporter_name=req.reporter_name,
        reporter_contact=req.reporter_contact,
        evidence={"urls": req.evidence_urls, "reproduction_steps": req.reproduction_steps},
        tags=req.tags,
    )
    logger.info(
        "incident_db_report_submitted",
        internal_id=stored["id"],
        model=req.affected_model,
        provider=req.affected_provider,
        severity=req.severity,
    )
    return {
        **stored,
        "message": "Report received and is pending review. It will not appear in the "
        "public database until a moderator approves it.",
    }


@app.get("/api/incident-db", tags=["incident-db"])
@limiter.limit("60/minute")
async def incident_db_list(
    request: Request,
    severity: str | None = Query(default=None),
    incident_type: str | None = Query(default=None),
    model: str | None = Query(default=None),
    provider: str | None = Query(default=None),
    search: str | None = Query(default=None, max_length=200),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> dict[str, Any]:
    """Public, unauthenticated. Published incidents only — free to browse,
    like the CVE database, no account required."""
    rows = await _ready(_public_incident_repo).list_published(
        severity=severity,
        incident_type=incident_type,
        model=model,
        provider=provider,
        search=search,
        limit=limit,
        offset=offset,
    )
    return {"incidents": rows, "limit": limit, "offset": offset}


@app.get("/api/incident-db/check", tags=["incident-db"])
@limiter.limit("120/minute")
async def incident_db_check(
    request: Request,
    model: str = Query(..., min_length=1, max_length=100),
    provider: str = Query(..., min_length=1, max_length=100),
    _auth: OrgContext = Depends(require_plan(Plan.PRO)),
) -> dict[str, Any]:
    """PRO/ENTERPRISE only — the pre-deployment check product: 'has anything
    been reported against the exact model/provider I'm about to deploy.'
    Exact match, not fuzzy search, so this is safe to wire into a CI/CD
    deploy gate without false positives from partial name matches."""
    rows = await _ready(_public_incident_repo).check(model, provider)
    return {
        "model": model,
        "provider": provider,
        "has_reported_incidents": len(rows) > 0,
        "incidents": rows,
    }


@app.get("/api/incident-db/verify", tags=["incident-db"])
@limiter.limit("30/minute")
async def incident_db_verify(request: Request) -> dict[str, Any]:
    """Public, unauthenticated — recomputes the hash chain over every
    published entry. Deliberately public, unlike GET /api/audit/verify:
    a CVE-style database's trustworthiness depends on anyone being able to
    check it hasn't been quietly tampered with, not just the operator."""
    return await _ready(_public_incident_repo).verify_chain()


@app.get("/api/incident-db/pending", tags=["incident-db"])
@limiter.limit("30/minute")
async def incident_db_pending(
    request: Request,
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    _incident_db_super_admin_check(_auth)
    rows = await _ready(_public_incident_repo).list_pending(limit=limit, offset=offset)
    return {"pending": rows, "limit": limit, "offset": offset}


@app.post("/api/incident-db/{internal_id}/approve", tags=["incident-db"])
@limiter.limit("30/minute")
async def incident_db_approve(
    request: Request,
    internal_id: str,
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    _incident_db_super_admin_check(_auth)
    updated = await _ready(_public_incident_repo).approve(internal_id, reviewed_by=_auth.key_id)
    if updated is None:
        raise HTTPException(
            404, "No pending report found with this ID (already reviewed, or doesn't exist)."
        )
    logger.info("incident_db_published", public_id=updated["public_id"], internal_id=internal_id)
    return updated


@app.post("/api/incident-db/{internal_id}/reject", tags=["incident-db"])
@limiter.limit("30/minute")
async def incident_db_reject(
    request: Request,
    internal_id: str,
    req: IncidentRejectRequest,
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    _incident_db_super_admin_check(_auth)
    updated = await _ready(_public_incident_repo).reject(
        internal_id, reviewed_by=_auth.key_id, reason=req.reason
    )
    if updated is None:
        raise HTTPException(
            404, "No pending report found with this ID (already reviewed, or doesn't exist)."
        )
    logger.info("incident_db_rejected", internal_id=internal_id, reason=req.reason)
    return updated


@app.post("/api/incident-db/{public_id}/status", tags=["incident-db"])
@limiter.limit("30/minute")
async def incident_db_update_status(
    request: Request,
    public_id: str,
    req: IncidentStatusUpdateRequest,
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    """Post-publish lifecycle transition only (e.g. mark RESOLVED once a
    provider patches the issue) — never touches the hash-chained disclosure
    facts."""
    _incident_db_super_admin_check(_auth)
    updated = await _ready(_public_incident_repo).update_status(
        public_id, req.status, reviewed_by=_auth.key_id
    )
    if updated is None:
        raise HTTPException(404, "No published incident found with this ID.")
    return updated


@app.get("/api/incident-db/{public_id}", tags=["incident-db"])
@limiter.limit("120/minute")
async def incident_db_get(request: Request, public_id: str) -> dict[str, Any]:
    """Public, unauthenticated. Must be registered after /check, /verify,
    /pending, and the {id}/approve|reject|status routes so those literal
    and admin-action paths aren't swallowed by this catch-all ID pattern."""
    record = await _ready(_public_incident_repo).get_by_public_id(public_id)
    if record is None:
        raise HTTPException(404, "No published incident found with this ID.")
    return record


# ── Governance: evidence + approvals (WhitePact Phases 11-12) ──────────────────
# See MIGRATION_WHITEPACT_V2.md Section 8. Every route below is scoped to the
# caller's own org (_auth.org_id) -- there is no cross-org listing endpoint,
# matching get_mcp_usage's pattern just above: a legacy flat key with no
# org_id can't use these either, same 400 as that endpoint gives, for the
# same reason (there is no "this org's" evidence/approvals for a key that
# isn't scoped to an org).


@app.get("/api/governance/evidence", tags=["governance"])
@limiter.limit("30/minute")
async def governance_list_evidence(
    request: Request,
    limit: int = Query(default=50, ge=1, le=200),
    decision: str | None = Query(default=None),
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    if not _auth.org_id:
        raise HTTPException(
            400, "Governance evidence requires an org-scoped API key, not a legacy flat key."
        )
    records = await _ready(_evidence_repo).list_for_org(
        _auth.org_id, limit=limit, decision=decision
    )
    return {"evidence": [r.to_dict() for r in records], "limit": limit}


@app.get("/api/governance/evidence/verify", tags=["governance"])
@limiter.limit("30/minute")
async def governance_verify_evidence(
    request: Request,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """Recomputes this org's evidence hash chain from scratch and reports
    whether it's intact -- the same tamper-evidence check
    /api/incident-db/verify offers for the public registry, scoped here
    to the caller's own org rather than public."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Governance evidence requires an org-scoped API key, not a legacy flat key."
        )
    status = await _ready(_evidence_repo).verify_chain_status(_auth.org_id)
    return {
        "org_id": _auth.org_id,
        "chain_intact": status.value in {"VALID", "INCOMPLETE"},
        "status": status.value,
    }


@app.get("/api/governance/evidence/bundle", tags=["governance"])
@limiter.limit("10/minute")
async def governance_export_evidence_bundle(
    request: Request,
    since: str | None = Query(
        default=None, description="ISO-8601 recorded_at lower bound, inclusive."
    ),
    until: str | None = Query(
        default=None, description="ISO-8601 recorded_at upper bound, inclusive."
    ),
    limit: int = Query(default=1000, ge=1, le=10_000),
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """Exports a self-contained, OFFLINE-verifiable Evidence Bundle
    (v3 authority-layer work) -- download this JSON and hand it to an
    auditor/regulator/insurer; POST it back to
    /api/governance/evidence/bundle/verify (or call
    governance.evidence_bundle.verify_evidence_bundle() directly, no
    WhitePact credential needed) to confirm it wasn't tampered with,
    with no further access to this API required. Omitting since/until
    exports the org's entire chain (up to `limit`); a scoped export's
    first record's prev_hash is an external anchor, not something the
    bundle alone proves -- see that module's docstring."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Governance evidence requires an org-scoped API key, not a legacy flat key."
        )
    records = await _ready(_evidence_repo).list_for_bundle(
        _auth.org_id, since=since, until=until, limit=limit
    )
    bundle = build_evidence_bundle(records, org_id=_auth.org_id)
    return bundle.to_dict()


@app.post("/api/governance/evidence/bundle/verify", tags=["governance"])
@limiter.limit("10/minute")
async def governance_verify_evidence_bundle(
    request: Request,
    bundle: dict[str, Any],
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """Verifies an uploaded Evidence Bundle purely from its own
    contents -- this endpoint is a convenience (so a caller doesn't
    have to run the same Python locally), not a requirement: the whole
    point of an Evidence Bundle is that
    governance.evidence_bundle.verify_evidence_bundle() can run this
    exact check completely offline, with no WhitePact API access at
    all. Does not check the bundle's org_id against the caller's --
    verifying a bundle you didn't originally export is a legitimate
    use (an auditor checking a bundle handed to them by someone else)."""
    result = verify_evidence_bundle(bundle)
    return {
        "valid": result.valid,
        "chain_intact": result.chain_intact,
        "digest_matches": result.digest_matches,
        "failure_reason": result.failure_reason,
    }


@app.post("/api/governance/evidence/{evidence_id}/outcome", tags=["governance"])
@limiter.limit("60/minute")
async def governance_report_outcome(
    request: Request,
    evidence_id: str,
    req: OutcomeReportRequest,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """Outcome Observation (Authority Everywhere Phase 12) -- for a
    governed action whose execution happens outside the synchronous
    request that made the decision (a caller doing its own async
    execution against a result WhitePact already authorized). The
    internal MCP dispatch path and the upstream proxy path both record
    an outcome automatically already; this endpoint exists for every
    other caller."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Governance evidence requires an org-scoped API key, not a legacy flat key."
        )
    evidence = await _ready(_evidence_repo).get_for_org(evidence_id, _auth.org_id)
    if evidence is None:
        raise HTTPException(404, f"Evidence record {evidence_id!r} not found.")
    outcome = await _ready(_outcome_repo).record(
        build_outcome_record(
            evidence_id,
            evidence.action_id,
            req.status,
            organization_id=_auth.org_id,
            result_summary=req.result_summary,
        )
    )
    return outcome.to_dict()


@app.get("/api/governance/evidence/{evidence_id}/attestation", tags=["governance"])
@limiter.limit("30/minute")
async def governance_get_attestation(
    request: Request,
    evidence_id: str,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """Attestation (Authority Everywhere Phase 14) -- the packaged
    Decision -> Outcome -> Reconciliation statement for one evidence
    entry. Not cryptographically signed; see
    governance/attestation.py's module docstring for why, and verify
    `evidence_hash` against /api/governance/evidence/verify's chain
    check instead."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Governance evidence requires an org-scoped API key, not a legacy flat key."
        )
    evidence = await _ready(_evidence_repo).get_for_org(evidence_id, _auth.org_id)
    if evidence is None:
        raise HTTPException(404, f"Evidence record {evidence_id!r} not found.")
    outcome = await _ready(_outcome_repo).get_for_org(evidence_id, _auth.org_id)
    attestation = build_attestation_record(evidence, outcome)
    return attestation.to_dict()


@app.get("/api/governance/approvals", tags=["governance"])
@limiter.limit("30/minute")
async def governance_list_pending_approvals(
    request: Request,
    limit: int = Query(default=50, ge=1, le=200),
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    if not _auth.org_id:
        raise HTTPException(
            400, "Governance approvals require an org-scoped API key, not a legacy flat key."
        )
    pending = await _ready(_approval_repo).list_pending(_auth.org_id, limit=limit)
    return {"pending": [p.to_dict() for p in pending], "limit": limit}


@app.post("/api/governance/approvals/{approval_id}/resolve", tags=["governance"])
@limiter.limit("30/minute")
async def governance_resolve_approval(
    request: Request,
    approval_id: str,
    req: ApprovalResolveRequest,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    """Resolving an approval is a privileged action (ADMIN+), unlike the
    read endpoints above (ANALYST+) -- deciding whether a governed action
    proceeds is a materially different responsibility than viewing the
    record of past decisions."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Governance approvals require an org-scoped API key, not a legacy flat key."
        )
    existing = await _ready(_approval_repo).get(approval_id)
    if existing is None:
        raise HTTPException(404, "No approval request found with this ID.")
    if existing.organization_id != _auth.org_id:
        # Same 404 as "doesn't exist" -- not 403 -- so this endpoint never
        # confirms *anything* about another org's approval IDs existing.
        raise HTTPException(404, "No approval request found with this ID.")
    try:
        resolved = await _ready(_approval_repo).resolve(
            approval_id,
            resolved_by=_auth.key_id,
            outcome=ApprovalStatus(req.outcome),
            notes=req.notes,
        )
    except ApprovalNotFoundError as exc:
        raise HTTPException(404, str(exc)) from None
    except ApprovalAlreadyResolvedError as exc:
        raise HTTPException(409, str(exc)) from None
    except ApprovalExpiredError as exc:
        raise HTTPException(409, str(exc)) from None
    except SelfApprovalError as exc:
        raise HTTPException(403, str(exc)) from None
    except AlreadyVotedError as exc:
        raise HTTPException(409, str(exc)) from None
    observe_governance_approval(req.outcome, org_id=_auth.org_id)
    logger.info(
        "governance_approval_resolved",
        approval_id=approval_id,
        outcome=req.outcome,
        resolved_by=_auth.key_id,
        org_id=_auth.org_id,
        status=resolved.status.value,
    )
    return resolved.to_dict()


@app.get("/api/governance/approvals/{approval_id}/votes", tags=["governance"])
@limiter.limit("30/minute")
async def governance_list_approval_votes(
    request: Request,
    approval_id: str,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """The quorum audit trail (v3 authority-layer work): every vote cast
    so far on a multi-approver approval -- the parent approval's own
    resolved_by/resolved_at only ever reflects the single vote that
    closed (or is closing) it, not the full history for a quorum > 1
    approval."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Governance approvals require an org-scoped API key, not a legacy flat key."
        )
    approval = await _ready(_approval_repo).get(approval_id)
    if approval is None or approval.organization_id != _auth.org_id:
        raise HTTPException(404, "No approval request found with this ID.")
    votes = await _ready(_approval_repo).list_votes(approval_id)
    return {
        "approval_id": approval_id,
        "required_approvals": approval.required_approvals,
        "votes": [v.to_dict() for v in votes],
    }


@app.post("/api/governance/approvals/{approval_id}/execute", tags=["governance"])
@limiter.limit("30/minute")
async def governance_execute_approval(
    request: Request,
    approval_id: str,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    """The REQUIRE_APPROVAL -> resume-execution pipeline (v3
    authority-layer work): a human has already resolved this approval
    APPROVED via the resolve endpoint above; this actually runs the
    original action against the exact arguments they reviewed, via the
    same InternalToolExecutor the live governed MCP dispatch path uses.
    ADMIN-role, same as resolve -- executing a previously-gated action
    is at least as privileged as approving it.
    """
    if not _auth.org_id:
        raise HTTPException(
            400, "Governance approvals require an org-scoped API key, not a legacy flat key."
        )
    try:
        result = await resume_approval(
            approval_id,
            nonce_repo=ExecutionNonceRepository(_ready(_db_engine)),
            epoch_repo=RevocationEpochRepository(_ready(_db_engine)),
            authority_resolver=AuthorityResolver(
                RootAuthorityRepository(_ready(_db_engine)),
                ConsentProofRepository(_ready(_db_engine)),
                _ready(_delegation_repo),
            ),
            policy_repo=_ready(_policy_repo),
            gateway=_upstream_gateway,
            upstream_registry=_ready(_upstream_registry),
            approval_repo=_ready(_approval_repo),
            evidence_repo=_ready(_evidence_repo),
            org_id=_auth.org_id,
            outcome_repo=_ready(_outcome_repo),
        )
    except ApprovalNotFoundError as exc:
        raise HTTPException(404, str(exc)) from None
    except ApprovalExpiredError as exc:
        raise HTTPException(409, str(exc)) from None
    except (ApprovalNotApprovedError, ApprovalActionMismatchError) as exc:
        raise HTTPException(409, str(exc)) from None
    except ApprovalAuthorizationDeniedError as exc:
        raise HTTPException(409, str(exc)) from None
    except ValueError as exc:
        # build_resume_action()'s "no persisted arguments" case -- a
        # pre-resume-feature approval that was already APPROVED before
        # this endpoint existed.
        raise HTTPException(422, str(exc)) from None
    logger.info(
        "governance_approval_executed",
        approval_id=approval_id,
        org_id=_auth.org_id,
    )
    return {"approval_id": approval_id, "result": result}


@app.post("/api/governance/tools/call", tags=["governance"])
@limiter.limit("30/minute")
async def governance_call_tool(
    request: Request,
    req: GovernedToolCallRequest,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """Canonical governed tool invocation over HTTP.

    Uses ``apply_governance`` then ``InternalToolExecutor``. Does not mint
    ExecutionGrant state. UI and REST callers are not authority.
    """
    if not _auth.org_id:
        raise HTTPException(
            400, "Governed tool calls require an org-scoped API key, not a legacy flat key."
        )
    from responsibleai.governance.synthetic_counter import SyntheticAcknowledgementLostError
    from responsibleai.mcp.tools import TOOL_DEFS

    allowed = {definition.name for definition in TOOL_DEFS}
    if req.name not in allowed:
        raise HTTPException(404, "Unknown tool.")
    try:
        outcome = await apply_governance(
            req.name,
            dict(req.arguments),
            _auth,
            _dashboard_governance_services(),
            purpose=req.purpose,
        )
    except SyntheticAcknowledgementLostError:
        return {
            "error": "governance_unknown_outcome",
            "message": (
                "The mutation may have applied; acknowledgement was lost. "
                "WhitePact will not retry automatically."
            ),
            "tool": req.name,
        }
    if not outcome.proceed:
        return outcome.blocked_response or {"error": "governance_blocked"}
    status = outcome.outcome_status.value if outcome.outcome_status is not None else None
    return {"tool": req.name, "result": outcome.result, "outcome_status": status}


@app.get("/api/governance/test-counter", tags=["governance"])
@limiter.limit("30/minute")
async def governance_test_counter(
    request: Request,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    if not _auth.org_id:
        raise HTTPException(
            400, "Counter inspection requires an org-scoped API key, not a legacy flat key."
        )
    state = await counter_snapshot(_auth.org_id)
    return {"tool": SYNTHETIC_COUNTER_TOOL, **state}


def _policy_rule_to_dict(rule: PolicyRule) -> dict[str, Any]:
    return {
        "rule_id": rule.rule_id,
        "reason_code": rule.reason_code,
        "effect": rule.effect.value,
        "risk_tiers": sorted(t.value for t in rule.risk_tiers) if rule.risk_tiers else None,
        "action_types": sorted(rule.action_types) if rule.action_types else None,
        "targets": sorted(rule.targets) if rule.targets else None,
    }


@app.get("/api/governance/policy", tags=["governance"])
@limiter.limit("30/minute")
async def governance_get_policy(
    request: Request,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """The org's persisted policy, in evaluation order (first-match-wins
    — see governance/policy.py). Previously policies only existed as
    in-code objects a call site constructed fresh each time; this is
    what an org actually configured, queryable and editable without a
    deploy."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Governance policy requires an org-scoped API key, not a legacy flat key."
        )
    policy = await _ready(_policy_repo).get_policy(_auth.org_id)
    return {"org_id": _auth.org_id, "rules": [_policy_rule_to_dict(r) for r in policy.rules]}


@app.post("/api/governance/policy/rules", tags=["governance"])
@limiter.limit("20/minute")
async def governance_add_policy_rule(
    request: Request,
    req: PolicyRuleCreateRequest,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    """Adding a policy rule is ADMIN+ (like resolving an approval) — it
    changes what future actions this org's own governance pipeline
    allows, not just a view of past decisions. Appended at the end of
    the evaluation order; use POST /api/governance/policy/reorder to
    change that."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Governance policy requires an org-scoped API key, not a legacy flat key."
        )
    try:
        rule = PolicyRule(
            rule_id=req.rule_id,
            reason_code=req.reason_code,
            effect=GovernanceDecision(req.effect),
            risk_tiers=frozenset(RiskTier(t) for t in req.risk_tiers) if req.risk_tiers else None,
            action_types=frozenset(req.action_types) if req.action_types else None,
            targets=frozenset(req.targets) if req.targets else None,
        )
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None
    existing = await _ready(_policy_repo).get_policy(_auth.org_id)
    if any(r.rule_id == rule.rule_id for r in existing.rules):
        raise HTTPException(409, f"Rule {rule.rule_id!r} already exists for this org.")
    await _ready(_policy_repo).add_rule(_auth.org_id, rule)
    logger.info(
        "governance_policy_rule_added",
        rule_id=rule.rule_id,
        org_id=_auth.org_id,
        added_by=_auth.key_id,
    )
    return _policy_rule_to_dict(rule)


@app.delete("/api/governance/policy/rules/{rule_id}", tags=["governance"])
@limiter.limit("20/minute")
async def governance_remove_policy_rule(
    request: Request,
    rule_id: str,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, str]:
    if not _auth.org_id:
        raise HTTPException(
            400, "Governance policy requires an org-scoped API key, not a legacy flat key."
        )
    try:
        await _ready(_policy_repo).remove_rule(_auth.org_id, rule_id)
    except PolicyRuleNotFoundError as exc:
        raise HTTPException(404, str(exc)) from None
    logger.info(
        "governance_policy_rule_removed",
        rule_id=rule_id,
        org_id=_auth.org_id,
        removed_by=_auth.key_id,
    )
    return {"status": "removed", "rule_id": rule_id}


@app.post("/api/governance/policy/reorder", tags=["governance"])
@limiter.limit("20/minute")
async def governance_reorder_policy(
    request: Request,
    req: PolicyReorderRequest,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    if not _auth.org_id:
        raise HTTPException(
            400, "Governance policy requires an org-scoped API key, not a legacy flat key."
        )
    try:
        await _ready(_policy_repo).reorder(_auth.org_id, req.rule_ids)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None
    policy = await _ready(_policy_repo).get_policy(_auth.org_id)
    logger.info("governance_policy_reordered", org_id=_auth.org_id, reordered_by=_auth.key_id)
    return {"org_id": _auth.org_id, "rules": [_policy_rule_to_dict(r) for r in policy.rules]}


def _workflow_rule_to_dict(rule: WorkflowSequenceRule) -> dict[str, Any]:
    return {
        "rule_id": rule.rule_id,
        "action_types": list(rule.action_types),
        "window_minutes": rule.window_minutes,
    }


@app.get("/api/governance/workflow-rules", tags=["governance"])
@limiter.limit("30/minute")
async def governance_get_workflow_rules(
    request: Request,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """The org's persisted forbidden-sequence rules (Workflow Authority
    Engine, v3 authority-layer work) — enforced live on every hosted MCP
    tool call via governance/workflow.py's check_composition_violation().
    """
    if not _auth.org_id:
        raise HTTPException(
            400, "Workflow rules require an org-scoped API key, not a legacy flat key."
        )
    rules = await _ready(_workflow_rule_repo).get_rules(_auth.org_id)
    return {"org_id": _auth.org_id, "rules": [_workflow_rule_to_dict(r) for r in rules]}


@app.post("/api/governance/workflow-rules", tags=["governance"], status_code=201)
@limiter.limit("20/minute")
async def governance_add_workflow_rule(
    request: Request,
    req: WorkflowRuleCreateRequest,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    """Adding a workflow rule is ADMIN+ (same bar as adding a policy
    rule) — it changes what future action sequences this org's own
    agents are allowed to complete."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Workflow rules require an org-scoped API key, not a legacy flat key."
        )
    rule = WorkflowSequenceRule(
        rule_id=req.rule_id,
        action_types=tuple(req.action_types),
        window_minutes=req.window_minutes,
    )
    try:
        await _ready(_workflow_rule_repo).add_rule(_auth.org_id, rule)
    except WorkflowRuleAlreadyExistsError as exc:
        raise HTTPException(409, str(exc)) from None
    logger.info(
        "governance_workflow_rule_added",
        rule_id=rule.rule_id,
        org_id=_auth.org_id,
        added_by=_auth.key_id,
    )
    return _workflow_rule_to_dict(rule)


@app.delete("/api/governance/workflow-rules/{rule_id}", tags=["governance"])
@limiter.limit("20/minute")
async def governance_remove_workflow_rule(
    request: Request,
    rule_id: str,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, str]:
    if not _auth.org_id:
        raise HTTPException(
            400, "Workflow rules require an org-scoped API key, not a legacy flat key."
        )
    try:
        await _ready(_workflow_rule_repo).remove_rule(_auth.org_id, rule_id)
    except WorkflowRuleNotFoundError as exc:
        raise HTTPException(404, str(exc)) from None
    logger.info(
        "governance_workflow_rule_removed",
        rule_id=rule_id,
        org_id=_auth.org_id,
        removed_by=_auth.key_id,
    )
    return {"status": "removed", "rule_id": rule_id}


@app.post("/api/governance/delegations", tags=["governance"], status_code=201)
@limiter.limit("20/minute")
async def governance_grant_delegation(
    request: Request,
    req: DelegationGrantRequest,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    """Grants authority via the Delegation Graph (v3 authority-layer
    work, Core Invariant #2) -- ADMIN+ since it directly creates
    authority another identity can act on. A `from_identity_id` grant
    is checked against that identity's own currently active delegation
    via validate_attenuation() (db/delegation_repository.py's grant());
    a mismatch is a 422, not a silent narrowing."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Delegations require an org-scoped API key, not a legacy flat key."
        )
    expires_at = None
    if req.expires_in_minutes is not None:
        expires_at = datetime.now(UTC) + timedelta(minutes=req.expires_in_minutes)
    try:
        record = await _ready(_delegation_repo).grant(
            _auth.org_id,
            req.to_identity_id,
            granted_action_types=frozenset(req.granted_action_types),
            constraints=req.constraints,
            require_approval_for=frozenset(req.require_approval_for),
            purpose=req.purpose,
            granted_by=_auth.key_id,
            from_identity_id=req.from_identity_id,
            expires_at=expires_at,
        )
    except DelegationEscalationError as exc:
        raise HTTPException(422, str(exc)) from None
    logger.info(
        "governance_delegation_granted",
        delegation_id=record.delegation_id,
        to_identity_id=record.to_identity_id,
        from_identity_id=record.from_identity_id,
        org_id=_auth.org_id,
        granted_by=_auth.key_id,
    )
    return await _ready(_delegation_repo).explain_authority(_auth.org_id, record.to_identity_id)


@app.get("/api/governance/delegations/{identity_id}/chain", tags=["governance"])
@limiter.limit("30/minute")
async def governance_get_delegation_chain(
    request: Request,
    identity_id: str,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """The root-first authority chain behind `identity_id`'s current
    authority -- empty if it has no active delegation."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Delegations require an org-scoped API key, not a legacy flat key."
        )
    return await _ready(_delegation_repo).explain_authority(_auth.org_id, identity_id)


@app.post("/api/governance/delegations/{identity_id}/revoke", tags=["governance"])
@limiter.limit("10/minute")
async def governance_revoke_delegation(
    request: Request,
    identity_id: str,
    req: DelegationRevokeRequest,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    """Cascading revocation (Core Invariant #11): revokes `identity_id`'s
    own active delegation and every descendant's, transitively -- a
    revoked identity can never leave a still-valid grant standing for
    anyone it delegated to."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Delegations require an org-scoped API key, not a legacy flat key."
        )
    revoked_ids = await _ready(_delegation_repo).revoke_branch(
        _auth.org_id, identity_id, revoked_by=_auth.key_id, reason=req.reason
    )
    logger.info(
        "governance_delegation_revoked",
        identity_id=identity_id,
        revoked_count=len(revoked_ids),
        org_id=_auth.org_id,
        revoked_by=_auth.key_id,
    )
    return {"identity_id": identity_id, "revoked_delegation_ids": revoked_ids}


@app.get("/api/governance/delegations/{identity_id}/descendants", tags=["governance"])
@limiter.limit("30/minute")
async def governance_get_delegation_descendants(
    request: Request,
    identity_id: str,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """Authority Everywhere Phase 6: every identity currently,
    transitively delegated-from `identity_id` -- the forward-direction
    counterpart to `.../chain` (which looks backward, to the root).
    Built from each identity's current parentage, not a raw historical
    walk -- an identity re-delegated under a different parent since
    only shows up under its current one."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Delegations require an org-scoped API key, not a legacy flat key."
        )
    descendants = await _ready(_delegation_repo).get_descendants(_auth.org_id, identity_id)
    return {
        "identity_id": identity_id,
        "descendant_count": len(descendants),
        "descendants": [
            {
                "identity_id": d.to_identity_id,
                "delegation_id": d.delegation_id,
                "from_identity_id": d.from_identity_id,
                "granted_action_types": sorted(d.granted_action_types),
                "is_active": d.is_active(),
            }
            for d in descendants
        ],
    }


@app.get("/api/governance/delegations/graph", tags=["governance"])
@limiter.limit("15/minute")
async def governance_get_delegation_graph(
    request: Request,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """Authority Everywhere Phase 6: the org's full delegation forest
    as a first-class, queryable object -- every root grant and
    everything transitively delegated from it, not just one identity's
    own chain. A snapshot at request time, rebuilt fresh, not cached."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Delegations require an org-scoped API key, not a legacy flat key."
        )
    graph = await _ready(_delegation_repo).get_org_graph(_auth.org_id)
    return graph.to_dict()


@app.post("/api/governance/intent-contracts", tags=["governance"], status_code=201)
@limiter.limit("30/minute")
async def governance_declare_intent(
    request: Request,
    req: IntentContractDeclareRequest,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """Declares an Intent Contract (Authority Everywhere Phase 4) for
    `agent_id` -- ANALYST+ since, unlike delegation grants, this
    narrows what an agent can do rather than expanding it (an agent
    declaring an overly broad contract gains nothing beyond its
    existing authority; `intent_violation()` only ever adds a DENY,
    never an ALLOW). A new declaration doesn't revoke the previous one
    -- both are preserved as an audit trail -- but only the most
    recently declared, still-active contract is consulted per call
    (`IntentContractRepository.get_active_for_agent()`)."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Intent contracts require an org-scoped API key, not a legacy flat key."
        )
    expires_at = None
    if req.expires_in_minutes is not None:
        expires_at = datetime.now(UTC) + timedelta(minutes=req.expires_in_minutes)
    contract = build_intent_contract(
        _auth.org_id,
        req.agent_id,
        req.goal,
        max_value_usd=req.max_value_usd,
        allowed_targets=req.allowed_targets,
        denied_targets=req.denied_targets,
        allowed_action_types=req.allowed_action_types,
        expires_at=expires_at,
    )
    await _ready(_intent_repo).declare(contract)
    logger.info(
        "governance_intent_contract_declared",
        contract_id=contract.contract_id,
        agent_id=req.agent_id,
        org_id=_auth.org_id,
        declared_by=_auth.key_id,
    )
    return contract.to_dict()


@app.get("/api/governance/intent-contracts/{agent_id}/active", tags=["governance"])
@limiter.limit("60/minute")
async def governance_get_active_intent(
    request: Request,
    agent_id: str,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """The currently active Intent Contract for `agent_id`, or a
    `has_active_contract: false` marker if none is declared or the
    latest declaration has expired -- 200, not 404, since "no contract"
    is a normal, expected state (identical to behavior before this
    feature existed), not an error."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Intent contracts require an org-scoped API key, not a legacy flat key."
        )
    contract = await _ready(_intent_repo).get_active_for_agent(_auth.org_id, agent_id)
    if contract is None:
        return {"agent_id": agent_id, "has_active_contract": False}
    return {"has_active_contract": True, **contract.to_dict()}


@app.post("/api/governance/authority-passports", tags=["governance"], status_code=201)
@limiter.limit("20/minute")
async def governance_issue_authority_passport(
    request: Request,
    req: AuthorityPassportIssueRequest,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    """Issues an Authority Passport (Authority Everywhere Phase 5) --
    ADMIN+, like a delegation grant, since exporting a portable
    credential is exporting real usable authority (unlike an Intent
    Contract, which only ever narrows). `source` picks what to export
    from; the passport is a snapshot at issuance time -- see
    `governance/authority_passport.py`'s module docstring for why this
    is deliberately not cryptographically signed."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Authority passports require an org-scoped API key, not a legacy flat key."
        )
    expires_at = None
    if req.expires_in_minutes is not None:
        expires_at = datetime.now(UTC) + timedelta(minutes=req.expires_in_minutes)

    if req.source == "org_ceiling":
        ceiling = await _ready(_ceiling_repo).get(_auth.org_id)
        if ceiling is None:
            raise HTTPException(404, "No authority ceiling configured for this organization.")
        passport = build_authority_passport_from_ceiling(
            ceiling, req.principal_id, expires_at=expires_at
        )
    else:
        delegation = await _ready(_delegation_repo).get_active_delegation(
            _auth.org_id, req.principal_id
        )
        if delegation is None:
            raise HTTPException(
                404, f"No active delegation found for principal {req.principal_id!r}."
            )
        passport = build_authority_passport_from_delegation(delegation, expires_at=expires_at)

    await _ready(_authority_passport_repo).issue(passport)
    logger.info(
        "governance_authority_passport_issued",
        passport_id=passport.passport_id,
        principal_id=req.principal_id,
        source=req.source,
        org_id=_auth.org_id,
        issued_by=_auth.key_id,
    )
    return passport.to_dict()


@app.get("/api/governance/authority-passports/{passport_id}", tags=["governance"])
@limiter.limit("60/minute")
async def governance_get_authority_passport(
    request: Request,
    passport_id: str,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """Fetches a passport and re-verifies it against its live source in
    the same response -- never trusts the passport's own stored fields
    alone, per `verify_passport()`'s "integrity by linkage" design."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Authority passports require an org-scoped API key, not a legacy flat key."
        )
    passport = await _ready(_authority_passport_repo).get(passport_id)
    if passport is None or passport.organization_id != _auth.org_id:
        raise HTTPException(404, "Authority passport not found.")

    ceiling = None
    delegation = None
    if passport.source == "org_ceiling":
        ceiling = await _ready(_ceiling_repo).get(_auth.org_id)
    elif passport.source == "delegation":
        delegation = await _ready(_delegation_repo).get_active_delegation(
            _auth.org_id, passport.principal_id
        )
    result = verify_passport(passport, ceiling=ceiling, delegation=delegation)
    return {
        **passport.to_dict(),
        "verification": {"status": result.status.value, "detail": result.detail},
    }


@app.post("/api/governance/authority-passports/{passport_id}/revoke", tags=["governance"])
@limiter.limit("20/minute")
async def governance_revoke_authority_passport(
    request: Request,
    passport_id: str,
    req: AuthorityPassportRevokeRequest,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    if not _auth.org_id:
        raise HTTPException(
            400, "Authority passports require an org-scoped API key, not a legacy flat key."
        )
    existing = await _ready(_authority_passport_repo).get(passport_id)
    if existing is None or existing.organization_id != _auth.org_id:
        raise HTTPException(404, "Authority passport not found.")
    try:
        revoked = await _ready(_authority_passport_repo).revoke(
            passport_id, revoked_by=_auth.key_id, reason=req.reason
        )
    except AuthorityPassportNotFoundError:
        raise HTTPException(404, "Authority passport not found.") from None
    logger.info(
        "governance_authority_passport_revoked",
        passport_id=passport_id,
        org_id=_auth.org_id,
        revoked_by=_auth.key_id,
    )
    return revoked.to_dict()


@app.post("/api/governance/supplychain/scan", tags=["governance"])
@limiter.limit("30/minute")
async def governance_supplychain_scan(
    request: Request,
    req: SupplyChainScanRequest,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """MCP Trust/Supply-Chain Scanner (SPEC.md Section 7, Phase 13) --
    evaluates a caller-supplied MCP server manifest (this endpoint never
    connects to a remote MCP server itself; see supplychain/scanner.py's
    module docstring for why). Not org-scoped: the checks it runs are
    either pure (content/name analysis) or query the public, org-agnostic
    AI Incident Database, so there's no per-org data to isolate here."""
    manifest = McpServerManifest(
        name=req.server_name,
        publisher=req.publisher,
        tools=[McpToolDescriptor(name=t.name, description=t.description) for t in req.tools],
    )
    incident_repo = _public_incident_repo if req.check_known_incidents else None
    report = await _supplychain_scanner.scan(manifest, incident_repo=incident_repo)
    return report.to_dict()


# ── MCP Upstream Gateway ────────────────────────────────────────────────────────
# v3 authority-layer work: an org-scoped registry of approved external MCP
# servers, and a governed proxy call to a specific tool on one of them. See
# governance/upstream.py, governance/upstream_executor.py,
# mcp/upstream_dispatch.py.


@app.post("/api/governance/upstream/servers", tags=["governance"], status_code=201)
@limiter.limit("10/minute")
async def upstream_register_server(
    request: Request,
    req: UpstreamServerRegisterRequest,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    """Registering a server IS the approval step (see
    ReasonCode.UNAPPROVED_MCP_SERVER) -- ADMIN-role, and the URL is
    SSRF-validated (private/loopback/link-local/reserved/multicast/
    unspecified addresses, cloud-metadata endpoint) before anything is
    persisted."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Upstream servers require an org-scoped API key, not a legacy flat key."
        )
    try:
        server = await _ready(_upstream_registry).register(
            _auth.org_id,
            req.name,
            req.url,
            added_by=_auth.key_id,
            auth_token=req.auth_token,
        )
    except UnsafeUpstreamServerURLError as exc:
        raise HTTPException(422, str(exc)) from None
    logger.info(
        "upstream_server_registered",
        server_id=server.server_id,
        org_id=_auth.org_id,
        added_by=_auth.key_id,
    )
    return server.to_dict()


@app.get("/api/governance/upstream/servers", tags=["governance"])
@limiter.limit("30/minute")
async def upstream_list_servers(
    request: Request,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    if not _auth.org_id:
        raise HTTPException(
            400, "Upstream servers require an org-scoped API key, not a legacy flat key."
        )
    servers = await _ready(_upstream_registry).list_for_org(_auth.org_id)
    return {"servers": [s.to_dict() for s in servers]}


@app.get("/api/governance/upstream/tools", tags=["governance"])
@limiter.limit("15/minute")
async def upstream_list_tools(
    request: Request,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """Discovery/aggregation across every enabled upstream server this
    org has registered (v3 authority-layer work, bounded scope --
    see governance/upstream_discovery.py's module docstring for what
    this deliberately does NOT do: inject these into the live MCP
    protocol's own tool listing). A server that can't be reached
    appears in `errors`, not as a 500 for the whole request -- one
    broken registration must not hide every other server's tools."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Upstream servers require an org-scoped API key, not a legacy flat key."
        )
    tools, errors = await discover_upstream_tools(_ready(_upstream_registry), _auth.org_id)
    return {"tools": [t.to_dict() for t in tools], "errors": errors}


@app.delete("/api/governance/upstream/servers/{server_id}", tags=["governance"])
@limiter.limit("10/minute")
async def upstream_remove_server(
    request: Request,
    server_id: str,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, str]:
    if not _auth.org_id:
        raise HTTPException(
            400, "Upstream servers require an org-scoped API key, not a legacy flat key."
        )
    try:
        await _ready(_upstream_registry).remove(_auth.org_id, server_id)
    except UpstreamServerNotFoundError as exc:
        raise HTTPException(404, str(exc)) from None
    logger.info(
        "upstream_server_removed", server_id=server_id, org_id=_auth.org_id, removed_by=_auth.key_id
    )
    return {"status": "removed", "server_id": server_id}


@app.post("/api/governance/upstream/servers/{server_id}/call", tags=["governance"])
@limiter.limit("30/minute")
async def upstream_call_tool(
    request: Request,
    server_id: str,
    req: UpstreamToolCallRequest,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """A governed proxy call to one tool on one registered upstream MCP
    server -- goes through the exact same five-way decision every
    internal tool call goes through (risk classification, authority,
    policy, quarantine, evidence), with the registry membership check
    (registered / same org / enabled) as an additional pre-check. Same
    ANALYST+ tier as internal governed tool calls: real authorization
    happens in the governance pipeline, not the REST role check."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Upstream calls require an org-scoped API key, not a legacy flat key."
        )
    executor = UpstreamMCPExecutor(
        _ready(_upstream_registry),
        credential_issuance_repo=_ready(_credential_issuance_repo),
        nonce_repo=ExecutionNonceRepository(_ready(_db_engine)),
    )
    try:
        outcome = await apply_upstream_governance(
            server_id,
            req.tool_name,
            req.arguments,
            _auth,
            purpose=req.purpose,
            authority_resolver=AuthorityResolver(
                RootAuthorityRepository(_ready(_db_engine)),
                ConsentProofRepository(_ready(_db_engine)),
                _ready(_delegation_repo),
            ),
            epoch_repo=RevocationEpochRepository(_ready(_db_engine)),
            gateway=_upstream_gateway,
            evidence_repo=_ready(_evidence_repo),
            policy_repo=_ready(_policy_repo),
            approval_repo=_ready(_approval_repo),
            upstream_registry=_ready(_upstream_registry),
            executor=executor,
            tool_trust_repo=_ready(_tool_trust_repo),
            outcome_repo=_ready(_outcome_repo),
        )
    except UpstreamServerNotAvailableError as exc:
        raise HTTPException(404, str(exc)) from None
    if not outcome.proceed:
        return outcome.blocked_response or {"error": "governance_blocked"}
    return {
        "server_id": server_id,
        "tool_name": req.tool_name,
        "result": outcome.result,
        "evidence_outcome": outcome.outcome_status.value if outcome.outcome_status else None,
        "reconciliation_required": outcome.outcome_status is OutcomeStatus.UNKNOWN,
    }


# ── Tool Trust Network (Authority Everywhere Phase 8) ──────────────────────────
# A continuously maintained, deterministic trust score per registered upstream
# MCP server -- see governance/tool_trust.py for the scoring logic and
# mcp/upstream_dispatch.py for how a BLOCKED tier gates a proxied call before
# governance even evaluates it. Registration (above) answers "is this server
# approved to exist in the registry"; this answers "should calls to it keep
# being allowed right now."


@app.get("/api/governance/upstream/servers/{server_id}/trust", tags=["governance"])
@limiter.limit("30/minute")
async def upstream_get_trust_score(
    request: Request,
    server_id: str,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    if not _auth.org_id:
        raise HTTPException(
            400, "Upstream servers require an org-scoped API key, not a legacy flat key."
        )
    server = await _ready(_upstream_registry).get(server_id)
    if server is None or server.org_id != _auth.org_id:
        raise HTTPException(404, f"Upstream MCP server {server_id!r} not found.")
    score = await _ready(_tool_trust_repo).get(server_id)
    if score is None:
        score = unscanned_score(server_id, _auth.org_id)
    return score.to_dict()


@app.post("/api/governance/upstream/servers/{server_id}/trust/scan", tags=["governance"])
@limiter.limit("10/minute")
async def upstream_scan_trust(
    request: Request,
    server_id: str,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    """Runs the MCP Trust/Supply-Chain Scanner against this server's
    currently discoverable tool list and persists the resulting score --
    ADMIN-role, since it changes what future calls to this server are
    allowed to do. Reuses `upstream_discovery.discover_upstream_tools()`
    (already built for the tool-listing endpoint) rather than a second
    way of asking a server what it offers; a server that can't be
    reached for discovery is reported as an error, not silently scored
    as if it had zero tools."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Upstream servers require an org-scoped API key, not a legacy flat key."
        )
    server = await _ready(_upstream_registry).get(server_id)
    if server is None or server.org_id != _auth.org_id:
        raise HTTPException(404, f"Upstream MCP server {server_id!r} not found.")

    all_tools, errors = await discover_upstream_tools(_ready(_upstream_registry), _auth.org_id)
    if server_id in errors:
        raise HTTPException(
            502, f"Could not discover this server's tools to scan it: {errors[server_id]}"
        )
    server_tools = [t for t in all_tools if t.server_id == server_id]

    manifest = McpServerManifest(
        name=server.name,
        tools=[
            McpToolDescriptor(name=t.tool_name, description=t.description) for t in server_tools
        ],
    )
    report = await _supplychain_scanner.scan(manifest, incident_repo=_public_incident_repo)
    incident_finding = next((f for f in report.findings if f.check == "known_incidents"), None)
    incident_count = len(incident_finding.detail.get("incidents", [])) if incident_finding else 0
    score = compute_trust_score(server_id, _auth.org_id, report, incident_count=incident_count)
    await _ready(_tool_trust_repo).upsert(score)
    logger.info(
        "upstream_server_trust_scanned",
        server_id=server_id,
        org_id=_auth.org_id,
        score=score.score,
        tier=score.tier.value,
        scanned_by=_auth.key_id,
    )
    return score.to_dict()


@app.post("/api/governance/upstream/servers/{server_id}/trust/override", tags=["governance"])
@limiter.limit("10/minute")
async def upstream_override_trust(
    request: Request,
    server_id: str,
    req: ToolTrustOverrideRequest,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    """An explicit, audited admin decision that overrides whatever the
    scan-derived tier currently is -- the only path that can force
    BLOCKED (immediately stopping all future calls to this server) or
    TRUSTED ahead of what a scan alone would grant. See
    governance/tool_trust.py's apply_admin_override() docstring for why
    every override requires a non-empty reason."""
    if not _auth.org_id:
        raise HTTPException(
            400, "Upstream servers require an org-scoped API key, not a legacy flat key."
        )
    server = await _ready(_upstream_registry).get(server_id)
    if server is None or server.org_id != _auth.org_id:
        raise HTTPException(404, f"Upstream MCP server {server_id!r} not found.")

    current = await _ready(_tool_trust_repo).get(server_id) or unscanned_score(
        server_id, _auth.org_id
    )
    score = apply_admin_override(current, req.tier, admin_id=_auth.key_id, reason=req.reason)
    await _ready(_tool_trust_repo).upsert(score)
    logger.info(
        "upstream_server_trust_overridden",
        server_id=server_id,
        org_id=_auth.org_id,
        tier=score.tier.value,
        overridden_by=_auth.key_id,
    )
    return score.to_dict()


# ── WebSocket live dashboard ───────────────────────────────────────────────────


@app.websocket("/ws/dashboard")
async def websocket_dashboard(
    websocket: WebSocket,
    token: str = Query(default=""),
) -> None:
    if settings.auth_enabled:
        if not token:
            await websocket.close(code=4001, reason="Unauthorized")
            return
        try:
            context = await _resolve_transport_identity(token)
        except HTTPException:
            context = None
        if context is None:
            await websocket.close(code=4001, reason="Unauthorized")
            return
        if not context.org_id:
            await websocket.close(code=4003, reason="Tenant-scoped credential required")
            return
        channel_id = context.org_id
    else:
        channel_id = "anonymous"

    await _ws_manager.connect(websocket, channel_id)
    observe_websocket_connections(_ws_manager.connection_count)

    try:
        snapshot: dict[str, Any] = {"type": "connected", "version": "0.9.0"}
        if _cost_repo:
            snapshot["monthly_spend_usd"] = round(
                await _ready(_cost_repo).total_cost(
                    30, org_id=None if channel_id == "anonymous" else channel_id
                ),
                4,
            )
        if _trust_repo:
            snapshot["models"] = await _ready(_trust_repo).all_models(
                org_id=None if channel_id == "anonymous" else channel_id
            )
        await websocket.send_json(snapshot)

        while True:
            await websocket.receive_text()

    except WebSocketDisconnect:
        pass
    finally:
        _ws_manager.disconnect(websocket, channel_id)
        observe_websocket_connections(_ws_manager.connection_count)


# ── Webhooks CRUD ──────────────────────────────────────────────────────────────


@app.post("/api/webhooks", tags=["webhooks"])
@limiter.limit("30/minute")
async def create_webhook(
    request: Request,
    req: WebhookCreateRequest,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    try:
        events = [WebhookEvent(e) for e in req.events]
    except ValueError as exc:
        raise HTTPException(400, f"Invalid event type: {exc}") from exc
    try:
        validate_webhook_url(req.url)
    except UnsafeWebhookURLError as exc:
        raise HTTPException(400, f"Invalid webhook URL: {exc}") from exc
    config = WebhookConfig(
        url=req.url,
        events=events,
        org_id=_auth.org_id,
        provider=WebhookProvider(req.provider),
        secret=req.secret,
        description=req.description,
        max_retries=req.max_retries,
    )
    await _webhook_manager.register_and_persist(config)
    return config.to_dict()


@app.get("/api/webhooks", tags=["webhooks"])
@limiter.limit("60/minute")
async def list_webhooks(
    request: Request,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    # Org-specific keys: force scope to their org. Legacy super-admin keys
    # (is_legacy=True, role=OWNER): see everything, same as /api/audit.
    scoped_org_id: str | None
    if _auth.org_id is not None:
        scoped_org_id = _auth.org_id
    elif _auth.is_legacy and _auth.role == Role.OWNER:
        scoped_org_id = None
    else:
        scoped_org_id = _auth.org_id
    return {"webhooks": [c.to_dict() for c in _webhook_manager.list_webhooks(org_id=scoped_org_id)]}


@app.delete("/api/webhooks/{webhook_id}", tags=["webhooks"])
@limiter.limit("30/minute")
async def delete_webhook(
    request: Request,
    webhook_id: str,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    scoped_org_id = _auth.org_id if not (_auth.is_legacy and _auth.role == Role.OWNER) else None
    if not await _webhook_manager.remove_and_persist(webhook_id, org_id=scoped_org_id):
        raise HTTPException(404, "Webhook not found")
    return {"deleted": webhook_id}


@app.get("/api/webhooks/deliveries", tags=["webhooks"])
@limiter.limit("60/minute")
async def webhook_deliveries(
    request: Request,
    limit: int = Query(default=50, ge=1, le=500),
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    scoped_org_id = _auth.org_id if not (_auth.is_legacy and _auth.role == Role.OWNER) else None
    return {
        "deliveries": _webhook_manager.delivery_log(limit, org_id=scoped_org_id),
        "total": _webhook_manager.total_deliveries_for(scoped_org_id),
        "failed": _webhook_manager.failed_deliveries_for(scoped_org_id),
    }


@app.post("/api/webhooks/test/{webhook_id}", tags=["webhooks"])
@limiter.limit("10/minute")
async def test_webhook(
    request: Request,
    webhook_id: str,
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> dict[str, Any]:
    cfg = _webhook_manager.get(webhook_id)
    is_super_admin = _auth.is_legacy and _auth.role == Role.OWNER
    if cfg is None or (not is_super_admin and cfg.org_id != _auth.org_id):
        raise HTTPException(404, "Webhook not found")
    deliveries = await _webhook_manager.fire(
        WebhookEvent.TRUST_SCORE_CHANGED,
        {"model": "test-model", "provider": "test", "score": 85.0, "test": True},
        org_id=cfg.org_id,
    )
    result = next((d for d in deliveries if d.webhook_id == webhook_id), None)
    return result.to_dict() if result else {"success": False, "error": "no delivery"}


# ── Trust & Evaluation ─────────────────────────────────────────────────────────


@app.post("/api/evaluate", tags=["trust"])
@limiter.limit(settings.rate_limit_evaluate)
async def evaluate_model(
    request: Request,
    req: EvaluateRequest,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    score = _ready(_trust_engine).compute(
        fairness=req.fairness,
        privacy=req.privacy,
        security=req.security,
        robustness=req.robustness,
        compliance=req.compliance,
        authenticity=req.authenticity,
    )
    compliance_report = _ready(_compliance).evaluate(
        fairness_score=req.fairness,
        privacy_score=req.privacy,
        security_score=req.security,
        robustness_score=req.robustness,
        compliance_maturity=req.compliance,
        use_case=req.use_case,
    )
    passport = _ready(_passport_gen).generate(
        model_name=req.model_name,
        provider=req.provider,
        trust_score=score,
        compliance_summary={"overall": round(compliance_report.compliance_score * 100, 1)},
    )
    await _ready(_passport_repo).create(passport, org_id=_auth.org_id, source="evaluate")
    drift_alert = None
    if req.record_drift:
        drift_alert = await _ready(_trust_repo).record(
            req.model_name, req.provider, score, org_id=_auth.org_id
        )

    observe_trust_score(req.model_name, req.provider, score.overall, org_id=_auth.org_id)
    record_evaluation(req.model_name, req.provider, score.overall, score.grade)

    await _ws_manager.broadcast(
        {
            "type": "trust_score",
            "data": {
                "model": req.model_name,
                "provider": req.provider,
                "score": score.overall,
                "grade": score.grade,
                "timestamp": datetime.now(UTC).isoformat(),
            },
        },
        api_key=_auth.org_id,
    )

    if drift_alert:
        observe_drift_alert(drift_alert.get("severity", "LOW"), org_id=_auth.org_id)
        deliveries = await _webhook_manager.fire(
            WebhookEvent.DRIFT_ALERT,
            {
                "model": req.model_name,
                "provider": req.provider,
                "delta": drift_alert.get("delta"),
                "severity": drift_alert.get("severity"),
                "score": score.overall,
            },
            org_id=_auth.org_id,
        )
        for d in deliveries:
            observe_webhook_delivery(WebhookEvent.DRIFT_ALERT.value, d.success, org_id=_auth.org_id)
        await _ws_manager.broadcast(
            {
                "type": "drift_alert",
                "data": {**drift_alert, "model": req.model_name, "provider": req.provider},
            },
            api_key=_auth.org_id,
        )

    logger.info(
        "evaluation",
        model=req.model_name,
        provider=req.provider,
        score=score.overall,
        grade=score.grade,
    )
    return {
        "trust_score": score.to_dict(),
        "compliance": {
            "overall_score": round(compliance_report.compliance_score * 100, 2),
            "eu_ai_act_tier": compliance_report.eu_ai_act_tier.value
            if compliance_report.eu_ai_act_tier
            else None,
            "violations": len(compliance_report.violations),
            "frameworks_evaluated": len(compliance_report.frameworks),
        },
        "passport_id": passport.passport_id,
        "passport_hash": passport.verification_hash[:16] + "...",
        "verify_url": f"/api/trust-index/verify/{passport.passport_id}",
        "drift_alert": drift_alert,
    }


@app.get("/api/trust-score/{model_name}/{provider}", tags=["trust"])
@limiter.limit("120/minute")
async def get_trust_history(
    request: Request,
    model_name: str,
    provider: str,
    limit: int = 30,
    _auth: OrgContext = Depends(require_role(Role.VIEWER)),
) -> dict[str, Any]:
    if limit < 1 or limit > 365:
        raise HTTPException(400, "limit must be between 1 and 365")
    history = await _ready(_trust_repo).history(
        model_name, provider, limit=limit, org_id=_auth.org_id
    )
    trend = await _ready(_trust_repo).trend(model_name, provider, org_id=_auth.org_id)
    return {"model": model_name, "provider": provider, "history": history, "trend": trend}


@app.get("/api/models", tags=["trust"])
@limiter.limit("120/minute")
async def list_models(
    request: Request,
    _auth: OrgContext = Depends(require_role(Role.VIEWER)),
) -> dict[str, Any]:
    return {"models": await _ready(_trust_repo).all_models(org_id=_auth.org_id)}


# ── Guardrails ─────────────────────────────────────────────────────────────────


@app.post("/api/scan", tags=["guardrails"])
@limiter.limit("200/minute")
async def scan_text(
    request: Request,
    req: ScanTextRequest,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    result = _ready(_guardrails).scan(req.text)
    blocked = result.is_blocked
    observe_guardrail(blocked, org_id=_auth.org_id)
    record_guardrail_scan(blocked, len(result.pii_findings))

    if blocked:
        await _ws_manager.broadcast(
            {
                "type": "guardrail",
                "data": {
                    "blocked": True,
                    "pii_count": len(result.pii_findings),
                    "timestamp": datetime.now(UTC).isoformat(),
                },
            },
            api_key=_auth.org_id,
        )
        deliveries = await _webhook_manager.fire(
            WebhookEvent.GUARDRAIL_TRIGGERED,
            {"pii_count": len(result.pii_findings), "block_reasons": result.block_reasons},
            org_id=_auth.org_id,
        )
        for d in deliveries:
            observe_webhook_delivery(
                WebhookEvent.GUARDRAIL_TRIGGERED.value, d.success, org_id=_auth.org_id
            )

    return {
        "is_blocked": blocked,
        "pii_count": len(result.pii_findings),
        "toxicity_count": len(result.toxicity_findings),
        "block_reasons": result.block_reasons,
        "redacted_text": result.redacted_text,
        "pii_findings": [
            {"category": f.category, "start": f.start, "end": f.end} for f in result.pii_findings
        ],
    }


# ── Hallucination ──────────────────────────────────────────────────────────────


@app.post("/api/hallucination", tags=["hallucination"])
@limiter.limit("100/minute")
async def analyze_hallucination(
    request: Request,
    body: dict[str, Any],
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    text = str(body.get("text", ""))[:50_000]
    if not text:
        raise HTTPException(400, "text field is required")
    candidates_raw = body.get("candidates", None)
    candidates = [str(c)[:10_000] for c in candidates_raw] if candidates_raw else None
    result = _ready(_hallucination).analyze(text, candidates=candidates)
    return {
        "hallucination_risk": round(result.hallucination_risk, 3),
        "risk_level": result.risk_level.upper(),
        "consistency_score": round(result.consistency_score, 3),
        "hedging_score": round(result.hedging_score, 3),
        "unsupported_claims": result.unsupported_claims[:20],
    }


# ── Cost Intelligence ──────────────────────────────────────────────────────────


@app.post("/api/cost/record", tags=["cost"])
@limiter.limit("500/minute")
async def record_usage(
    request: Request,
    req: RecordUsageRequest,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    usage = TokenUsage.create(
        provider=req.provider,
        model=req.model,
        input_tokens=req.input_tokens,
        output_tokens=req.output_tokens,
        team=req.team,
        application=req.application,
        org_id=_auth.org_id,
    )
    cost_record = await _ready(_cost_repo).record(usage)
    observe_cost(
        req.model,
        req.provider,
        cost_record.total_cost,
        req.input_tokens,
        req.output_tokens,
        org_id=_auth.org_id,
    )
    record_cost(
        req.provider, req.model, cost_record.total_cost, req.input_tokens + req.output_tokens
    )

    await _ws_manager.broadcast(
        {
            "type": "cost_update",
            "data": {
                "model": req.model,
                "provider": req.provider,
                "cost_usd": cost_record.total_cost,
                "tokens": req.input_tokens + req.output_tokens,
                "timestamp": datetime.now(UTC).isoformat(),
            },
        },
        api_key=_auth.org_id,
    )

    budget = await _ready(_cost_repo).check_budget(org_id=_auth.org_id)
    if budget.is_exceeded:
        deliveries = await _webhook_manager.fire(
            WebhookEvent.BUDGET_EXCEEDED,
            {
                "monthly_limit_usd": budget.monthly_limit_usd,
                "total_spent_usd": budget.total_spent_usd,
                "overage_usd": round(budget.total_spent_usd - budget.monthly_limit_usd, 4),
            },
            org_id=_auth.org_id,
        )
        for d in deliveries:
            observe_webhook_delivery(
                WebhookEvent.BUDGET_EXCEEDED.value, d.success, org_id=_auth.org_id
            )

    return cost_record.to_dict()


@app.get("/api/cost/summary", tags=["cost"])
@limiter.limit("60/minute")
async def cost_summary(
    request: Request,
    days: int = 30,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    if days < 1 or days > 365:
        raise HTTPException(400, "days must be between 1 and 365")
    oid = _auth.org_id
    return {
        "total_cost_usd": await _ready(_cost_repo).total_cost(days, org_id=oid),
        "total_tokens": await _ready(_cost_repo).total_tokens(days, org_id=oid),
        "model_breakdown": await _ready(_cost_repo).get_model_breakdown(days, org_id=oid),
        "team_breakdown": await _ready(_cost_repo).get_team_breakdown(days, org_id=oid),
        "daily_costs": await _ready(_cost_repo).get_daily_costs(days, org_id=oid),
        "budget_status": (await _ready(_cost_repo).check_budget(org_id=oid)).to_dict(),
        "request_count": await _ready(_cost_repo).request_count(days, org_id=oid),
    }


@app.post("/api/cost/analyze", tags=["cost"])
@limiter.limit("60/minute")
async def analyze_prompt(
    request: Request,
    req: AnalyzePromptRequest,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    result = _ready(_cost_analyzer).analyze_prompt_efficiency(
        prompt=req.prompt,
        response=req.response,
        provider=req.provider,
        model=req.model,
        monthly_requests=req.monthly_requests,
    )
    return result.to_dict()


@app.post("/api/cost/route", tags=["cost"])
@limiter.limit("120/minute")
async def route_task(
    request: Request,
    req: RouteTaskRequest,
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    decision = _ready(_router).route(req.task_description, req.quality_requirement)
    return decision.to_dict()


@app.get("/api/cost/models", tags=["cost"])
@limiter.limit("60/minute")
async def model_pricing(
    request: Request,
    _auth: OrgContext = Depends(require_role(Role.VIEWER)),
) -> dict[str, Any]:
    return {"models": _ready(_router).provider_comparison()}


# ── Drift ──────────────────────────────────────────────────────────────────────


@app.get("/api/drift/{model_name}/{provider}", tags=["drift"])
@limiter.limit("120/minute")
async def get_drift_trend(
    request: Request,
    model_name: str,
    provider: str,
    _auth: OrgContext = Depends(require_role(Role.VIEWER)),
) -> dict[str, Any]:
    trend = await _ready(_trust_repo).trend(model_name, provider)
    history = await _ready(_trust_repo).history(model_name, provider, limit=10)
    return {"trend": trend, "recent_history": history}


# ── API versioning ─────────────────────────────────────────────────────────────


@app.get("/api/version", tags=["ops"])
async def api_version() -> dict[str, Any]:
    """Return full version and stability metadata."""
    major, minor, patch = (int(part) for part in __version__.split(".")[:3])
    return {
        "version": __version__,
        "major": major,
        "minor": minor,
        "patch": patch,
        "stable": True,
        "api_versions": ["1.0", "1.1"],
        "current_api_prefix": "/api/v1",
        "deprecated_prefixes": [],
        "release_date": "2026-07-12",
        "changelog_url": "https://github.com/Guruprasath-Annadurai/ResponsibleAi/blob/main/CHANGELOG.md",
    }


# ── SSO / OAuth2 / OIDC ───────────────────────────────────────────────────────


@app.get("/api/auth/providers", tags=["auth"])
async def list_auth_providers() -> dict[str, Any]:
    """List configured authentication providers."""
    providers = []
    if settings.oidc_issuer:
        providers.append(
            {
                "id": "oidc",
                "type": "oidc",
                "issuer": settings.oidc_issuer,
                "client_id": settings.oidc_client_id,
                "login_url": "/api/auth/login/oidc",
            }
        )
    if _saml_config:
        providers.append(
            {
                "id": "saml",
                "type": "saml",
                "idp_entity_id": _saml_config.idp_entity_id,
                "login_url": "/api/auth/login/saml",
                "sp_metadata_url": "/api/auth/saml/metadata",
            }
        )
    providers.append(
        {
            "id": "api_key",
            "type": "api_key",
            "description": "Static API key via Authorization: Bearer <key>",
        }
    )
    return {"providers": providers, "count": len(providers)}


@app.get("/api/auth/login/{provider_id}", tags=["auth"])
async def auth_login(
    request: Request,
    provider_id: str,
    redirect_uri: str = "",
) -> Response:
    """Initiate SSO login — OAuth2 authorization code flow for ``oidc``,
    or a SAML AuthnRequest redirect for ``saml``."""
    if provider_id == "oidc":
        if not _oidc_provider:
            raise HTTPException(404, f"Unknown or unconfigured provider: {provider_id!r}")
        if redirect_uri and redirect_uri != settings.oidc_redirect_uri:
            raise HTTPException(400, "OIDC redirect URI is not allowlisted.")
        state = secrets.token_urlsafe(32)
        nonce = secrets.token_urlsafe(32)
        code_verifier = secrets.token_urlsafe(64)
        challenge = (
            base64.urlsafe_b64encode(hashlib.sha256(code_verifier.encode()).digest())
            .decode()
            .rstrip("=")
        )
        target_redirect = settings.oidc_redirect_uri

        initiating_session = request.cookies.get("wp_session")
        oauth_tx = request.cookies.get("wp_oauth_tx") or (
            _web_token_hash(initiating_session) if initiating_session else secrets.token_urlsafe(32)
        )
        bound_session_id = _web_token_hash(oauth_tx)

        await _ready(_web_identity_repo).create_oauth_flow_state(
            state=state,
            provider="oidc",
            nonce=nonce,
            redirect_uri=target_redirect,
            pkce_verifier=code_verifier,
            ttl_seconds=300,
            session_id=bound_session_id,
        )
        url = _oidc_provider.authorization_url(
            redirect_uri=target_redirect,
            state=state,
            scopes=settings.oidc_scopes,
            nonce=nonce,
            code_challenge=challenge,
        )
        resp = JSONResponse({"authorization_url": url, "state": state})
        resp.set_cookie(
            "wp_oauth_tx",
            oauth_tx,
            httponly=True,
            samesite="lax",
            secure=settings.web_session_secure,
            path="/",
            max_age=300,
        )
        return resp

    if provider_id == "saml":
        if not _saml_config:
            raise HTTPException(404, f"Unknown or unconfigured provider: {provider_id!r}")
        redirect_url, request_id = build_authn_request(_saml_config)
        try:
            await _ready(_saml_txn_store).remember(
                request_id,
                idp_entity_id=_saml_config.idp_entity_id,
                acs_url=_saml_config.acs_url,
                ttl_seconds=_SAML_REQUEST_TTL,
            )
        except SamlTransactionUnavailableError as exc:
            raise HTTPException(503, str(exc)) from exc
        return JSONResponse({"authorization_url": redirect_url, "request_id": request_id})

    raise HTTPException(404, f"Unknown or unconfigured provider: {provider_id!r}")


@app.get("/api/auth/saml/metadata", tags=["auth"])
async def saml_sp_metadata() -> Response:
    """SP metadata XML most IdPs need to configure the integration on
    their side (or the equivalent fields typed in by hand)."""
    if not _saml_config:
        raise HTTPException(501, "SAML not configured")
    return Response(content=build_sp_metadata(_saml_config), media_type="application/xml")


@app.post("/api/auth/acs", tags=["auth"])
@limiter.limit("20/minute")
async def saml_acs(request: Request) -> Response:
    """SAML Assertion Consumer Service — the IdP POSTs the SAMLResponse
    here (HTTP-POST binding) after the user authenticates. Mirrors
    auth_callback's shape: validate, mint WhitePact's own session token
    (see auth/saml.py's module docstring for why SAML needs one), then
    redirect the browser to /auth/complete with it in the URL fragment
    (never sent to the server, unlike a query param, so it never lands in
    access logs)."""
    if not _saml_config:
        raise HTTPException(501, "SAML not configured")

    form = await request.form()
    saml_response_raw = form.get("SAMLResponse")
    if not saml_response_raw or not isinstance(saml_response_raw, str):
        raise HTTPException(400, "Missing SAMLResponse")

    # SP-initiated flow (we sent the AuthnRequest): the response's
    # InResponseTo must be a known, single-use ID from our own store —
    # that store-membership check IS the replay defense, not the value
    # itself. IdP-initiated flow (user started from their IdP's app
    # dashboard, no prior AuthnRequest exists) carries no InResponseTo at
    # all, which is allowed: the signature and Conditions checks inside
    # parse_and_validate_response still fully authenticate the assertion.
    peeked_id = peek_in_response_to(saml_response_raw)
    expected_request_id: str | None = None
    if peeked_id is not None:
        try:
            consumed = await _ready(_saml_txn_store).consume(
                peeked_id,
                idp_entity_id=_saml_config.idp_entity_id,
                acs_url=_saml_config.acs_url,
            )
        except SamlTransactionUnavailableError as exc:
            raise HTTPException(503, str(exc)) from exc
        if not consumed:
            raise HTTPException(400, "Unknown or already-used SAML request ID")
        expected_request_id = peeked_id

    try:
        claims = parse_and_validate_response(saml_response_raw, _saml_config, expected_request_id)
    except SAMLError as e:
        raise HTTPException(401, f"SAML assertion validation failed: {e}") from None

    session_token = mint_session_token(_saml_config, claims)
    fragment = (
        f"token={quote(session_token)}&name={quote(claims.name or claims.email or claims.sub)}"
    )
    return RedirectResponse(url=f"/auth/complete#{fragment}", status_code=302)


@app.get("/api/auth/callback", tags=["auth"])
async def auth_callback(
    request: Request,
    code: str = Query(...),
    state: str = Query(...),
) -> Response:
    """Handle the OAuth2 callback — exchange code for tokens, then redirect the
    browser to /auth/complete with the access token in a URL fragment (never
    sent to the server, unlike a query param, so it never lands in access
    logs). That page extracts it client-side and finishes the login."""
    if not _oidc_provider:
        raise HTTPException(501, "OIDC not configured")

    initiating_session = request.cookies.get("wp_session")
    oauth_tx = request.cookies.get("wp_oauth_tx") or (
        _web_token_hash(initiating_session) if initiating_session else None
    )
    expected_session_id = _web_token_hash(oauth_tx) if oauth_tx else None

    state_record = await _ready(_web_identity_repo).consume_oauth_flow_state(
        state, expected_provider="oidc", expected_session_id=expected_session_id
    )
    if state_record is None:
        raise HTTPException(400, "Invalid or expired OAuth2 state parameter")

    nonce = state_record["nonce"]
    code_verifier = state_record["pkce_verifier"]
    target_redirect = state_record["redirect_uri"]

    try:
        tokens = await _oidc_provider.exchange_code(
            code=code,
            redirect_uri=target_redirect,
            client_secret=settings.oidc_client_secret,
            code_verifier=code_verifier,
        )
    except TypeError:
        tokens = await _oidc_provider.exchange_code(
            code=code,
            redirect_uri=target_redirect,
            client_secret=settings.oidc_client_secret,
        )
    except ValueError as e:
        logger.warning("oidc_token_exchange_failed", reason=str(e))
        raise HTTPException(400, "OIDC token exchange failed.") from None

    id_token = tokens.get("id_token") or tokens.get("access_token", "")
    try:
        claims = await _oidc_provider.validate_token(id_token, expected_nonce=nonce)
    except TypeError:
        claims = await _oidc_provider.validate_token(id_token)
    except ValueError as e:
        logger.warning("oidc_token_validation_failed", reason=str(e))
        raise HTTPException(401, "OIDC token validation failed.") from None

    access_token = tokens.get("access_token") or ""
    fragment = (
        f"token={quote(access_token)}&name={quote(claims.name or claims.email or claims.sub)}"
    )
    redirect_resp = RedirectResponse(url=f"/auth/complete#{fragment}", status_code=302)
    redirect_resp.delete_cookie("wp_oauth_tx", path="/")
    return redirect_resp


@app.post("/api/auth/logout", tags=["auth"])
async def auth_logout(
    _auth: OrgContext = Depends(get_org_context),
) -> dict[str, Any]:
    """Invalidate the current session (client should discard its token)."""
    return {"logged_out": True, "timestamp": datetime.now(UTC).isoformat()}


@app.post("/api/auth/login-key", tags=["auth"])
@limiter.limit("10/minute")
async def login_with_key(request: Request, req: LoginKeyRequest) -> dict[str, Any]:
    """Human-facing login step for the dashboard's /login page.

    Distinct from every other endpoint's Bearer-header auth: this is the
    one interactive login step, so it's where TOTP MFA gets enforced (see
    auth/mfa.py's module docstring for why it can't be enforced on
    ordinary API calls). Flow:
      1. POST {api_key} — if the key's org requires MFA and the key isn't
         enrolled yet, returns 403 telling the caller to enroll first.
         If enrolled, returns {mfa_required: true} without a code.
      2. POST {api_key, mfa_code} — verifies the code (or a backup code)
         and returns {ok: true}. The frontend then treats the api_key
         itself as the session token, same as before this endpoint existed.
    """
    if not settings.auth_enabled:
        return {"ok": True, "mfa_required": False}
    if settings.api_keys and req.api_key in settings.api_keys:
        return {"ok": True, "mfa_required": False}

    try:
        ctx = await _ready(_org_repo).authenticate(req.api_key)
    except SSORequiredError:
        raise HTTPException(
            403, "This organization requires SSO login — use the SSO button instead."
        ) from None
    if ctx is None:
        raise HTTPException(401, "Invalid or revoked API key")

    org = await _ready(_org_repo).get_org(ctx.org_id) if ctx.org_id else None
    if org is not None and org.mfa_required:
        if not ctx.mfa_enrolled:
            raise HTTPException(
                403,
                "This organization requires MFA and this key hasn't enrolled yet. "
                f"An admin must call POST /api/orgs/{org.id}/keys/{ctx.key_id}/mfa/enroll first.",
            )
        if not req.mfa_code:
            return {"ok": False, "mfa_required": True}

        key = await _ready(_org_repo).get_key(ctx.key_id)
        if key is None or not key.mfa_secret:
            raise HTTPException(401, "MFA state is inconsistent for this key — contact an admin")

        if mfa.verify_code(key.mfa_secret, req.mfa_code):
            return {"ok": True, "mfa_required": True}

        remaining = mfa.verify_and_consume_backup_code(key.mfa_backup_codes or [], req.mfa_code)
        if remaining is not None:
            await _ready(_org_repo).consume_backup_code(ctx.key_id, remaining)
            return {"ok": True, "mfa_required": True, "backup_code_used": True}

        raise HTTPException(401, "Invalid MFA code")

    return {"ok": True, "mfa_required": False}


@app.get("/api/auth/session", tags=["auth"])
async def auth_session(_auth: OrgContext = Depends(get_org_context)) -> dict[str, Any]:
    """Current auth context — used by the Settings page for self-service
    MFA enrollment (needs its own key_id/mfa_enrolled without a separate
    list-keys call, which would require ADMIN and this doesn't)."""
    return {
        "key_id": _auth.key_id,
        "key_name": _auth.key_name,
        "org_id": _auth.org_id,
        "org_name": _auth.org_name,
        "role": _auth.role.value,
        "is_legacy": _auth.is_legacy,
        "mfa_enrolled": _auth.mfa_enrolled,
    }


# ── Support tier ───────────────────────────────────────────────────────────────


@app.get("/api/support", tags=["support"])
async def support_info() -> dict[str, Any]:
    """Return SLA tiers and support contact information."""
    return {
        "tiers": [
            {
                "name": "Standard",
                "uptime_sla": "99.0%",
                "response_time": "Next business day",
                "channels": ["email"],
                "price": "Included",
            },
            {
                "name": "Professional",
                "uptime_sla": "99.5%",
                "response_time": "4 business hours",
                "channels": ["email", "slack"],
                "price": "Contact sales",
            },
            {
                "name": "Enterprise",
                "uptime_sla": "99.9%",
                "response_time": "1 hour (24/7)",
                "channels": ["email", "slack", "phone", "dedicated TAM"],
                "price": "Contact sales",
            },
        ],
        "contact": {
            "email": "annaduraiguruprasath7@gmail.com",
            "docs": "https://github.com/Guruprasath-Annadurai/ResponsibleAi",
            "issues": "https://github.com/Guruprasath-Annadurai/ResponsibleAi/issues",
        },
        "platform_version": "1.1.0",
    }


@app.get("/api/support/status", tags=["support"])
async def platform_status() -> dict[str, Any]:
    """Public platform status — no auth required."""
    db_ok = True
    try:
        if _cost_repo:
            await _ready(_cost_repo).request_count()
    except Exception:
        db_ok = False
    return {
        "platform": "ResponsibleAI Governance Platform",
        "version": __version__,
        "status": "operational" if db_ok else "degraded",
        "uptime_seconds": round(time.monotonic() - _START_TIME, 1),
        "timestamp": datetime.now(UTC).isoformat(),
    }


# ── Audit log ──────────────────────────────────────────────────────────────────


@app.get("/api/audit", tags=["audit"])
@limiter.limit("60/minute")
async def list_audit_entries(
    request: Request,
    org_id: str | None = Query(None, description="Cross-org filter (super-admin only)"),
    endpoint: str | None = Query(None, description="Filter by endpoint path"),
    days: int = Query(30, ge=1, le=365, description="Lookback window in days"),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    _auth: OrgContext = Depends(require_role(Role.ANALYST)),
) -> dict[str, Any]:
    """Query the governance audit log. Always scoped to the authenticated org."""
    if not _audit_repo:
        raise HTTPException(503, "Audit repository not initialised")
    # Org-specific keys: force scope to their org regardless of query param.
    # Legacy super-admin keys (is_legacy=True, role=OWNER): allow cross-org filter.
    scoped_org_id: str | None
    if _auth.org_id is not None:
        scoped_org_id = _auth.org_id
    elif _auth.is_legacy and _auth.role == Role.OWNER:
        scoped_org_id = org_id
    else:
        scoped_org_id = None
    rows = await _ready(_audit_repo).query(
        org_id=scoped_org_id, endpoint=endpoint, days=days, limit=limit, offset=offset
    )
    total = await _ready(_audit_repo).count(days=days, org_id=scoped_org_id)
    return {
        "entries": rows,
        "total": total,
        "limit": limit,
        "offset": offset,
        "days": days,
    }


@app.get("/api/audit/export", tags=["audit"])
@limiter.limit("10/minute")
async def export_audit_log(
    request: Request,
    org_id: str | None = Query(None, description="Cross-org filter (super-admin only)"),
    days: int = Query(30, ge=1, le=365),
    _auth: OrgContext = Depends(require_role(Role.ADMIN)),
) -> Response:
    """Export audit log as CSV. Results scoped to authenticated org."""
    if not _audit_repo:
        raise HTTPException(503, "Audit repository not initialised")
    scoped_org_id: str | None
    if _auth.org_id is not None:
        scoped_org_id = _auth.org_id
    elif _auth.is_legacy and _auth.role == Role.OWNER:
        scoped_org_id = org_id
    else:
        scoped_org_id = None
    rows = await _ready(_audit_repo).query(org_id=scoped_org_id, days=days, limit=5000)
    import csv as _csv
    import io as _io

    buf = _io.StringIO()
    writer = _csv.writer(buf)
    writer.writerow(
        [
            "id",
            "timestamp",
            "org_id",
            "key_id",
            "endpoint",
            "method",
            "status_code",
            "ip_address",
            "request_id",
            "duration_ms",
            "entry_hash",
            "prev_hash",
        ]
    )
    for r in rows:
        writer.writerow(
            [
                r.get("id", ""),
                r.get("timestamp", ""),
                r.get("org_id", ""),
                r.get("key_id", ""),
                r.get("endpoint", ""),
                r.get("method", ""),
                r.get("status_code", ""),
                r.get("ip_address", ""),
                r.get("request_id", ""),
                r.get("duration_ms", ""),
                r.get("entry_hash", ""),
                r.get("prev_hash", ""),
            ]
        )
    return Response(
        content=buf.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=audit-{days}d.csv"},
    )


@app.get("/api/audit/verify", tags=["audit"])
@limiter.limit("10/minute")
async def verify_audit_chain(
    request: Request,
    days: int = Query(90, ge=1, le=365),
    _auth: OrgContext = Depends(require_role(Role.OWNER)),
) -> dict[str, Any]:
    """Verify audit log tamper-evidence by recomputing the hash chain.

    Restricted to legacy super-admin OWNER — the chain spans all orgs on
    this server, so verifying it inherently reveals cross-org existence.
    """
    if not (_auth.is_legacy and _auth.role == Role.OWNER):
        raise HTTPException(403, "Audit chain verification requires super-admin access")
    return await _ready(_audit_repo).verify_chain(days=days)


@app.get("/api/audit/summary", tags=["audit"])
async def audit_endpoint_summary(
    days: int = Query(7, ge=1, le=90),
    _auth: OrgContext = Depends(get_org_context),
) -> dict[str, Any]:
    """Top endpoints by request count and average latency."""
    if not _audit_repo:
        raise HTTPException(503, "Audit repository not initialised")
    summary = await _ready(_audit_repo).endpoint_summary(days=days)
    return {"days": days, "endpoints": summary}


# ── Red team ───────────────────────────────────────────────────────────────────


@app.get("/api/redteam/payloads", tags=["redteam"])
async def get_redteam_payloads(
    categories: list[str] | None = Query(None, description="Filter by attack category"),
    _auth: OrgContext = Depends(get_org_context),
) -> dict[str, Any]:
    """Return all adversarial attack payloads, optionally filtered by category."""
    sim = RedTeamSimulator()
    payloads = sim.get_attack_payloads()
    if categories:
        payloads = [p for p in payloads if p["category"] in categories]
    return {
        "count": len(payloads),
        "payloads": payloads,
        "categories": list({p["category"] for p in payloads}),
    }


class RedTeamAnalyzeRequest(BaseModel):
    model_name: str = Field(..., description="Name of the model under test")
    provider: str = Field(..., description="Model provider")
    responses: dict[str, str] = Field(..., description="Map of attack_name → model_response_text")


@app.post("/api/redteam/analyze", tags=["redteam"])
async def analyze_redteam_responses(
    body: RedTeamAnalyzeRequest,
    _auth: OrgContext = Depends(get_org_context),
) -> dict[str, Any]:
    """Analyse model responses to red team payloads and return a security report."""
    sim = RedTeamSimulator()
    report = sim.analyze_responses(body.model_name, body.provider, body.responses)
    return report.to_dict()


# ── Billing / revenue metering ─────────────────────────────────────────────────


@app.get("/api/billing/usage", tags=["billing"])
async def billing_usage(
    days: int = Query(30, ge=1, le=365, description="Lookback window in days"),
    _auth: OrgContext = Depends(get_org_context),
) -> dict[str, Any]:
    """Return usage and cost summary for billing and revenue reporting."""
    if not _cost_repo:
        raise HTTPException(503, "Cost repository not initialised")
    oid = _auth.org_id
    total_cost = await _ready(_cost_repo).total_cost(days=days, org_id=oid)
    total_tokens = await _ready(_cost_repo).total_tokens(days=days, org_id=oid)
    request_count = await _ready(_cost_repo).request_count(days=days, org_id=oid)
    model_breakdown = await _ready(_cost_repo).get_model_breakdown(days=days, org_id=oid)
    return {
        "period_days": days,
        "total_cost_usd": round(total_cost, 6),
        "total_requests": request_count,
        "total_tokens": total_tokens,
        "cost_by_model": {k: round(v, 6) for k, v in model_breakdown.items()},
        "timestamp": datetime.now(UTC).isoformat(),
    }


@app.get("/{spa_path:path}", response_class=HTMLResponse, include_in_schema=False)
async def whitepact_spa_not_found(spa_path: str) -> HTMLResponse:
    """Render the branded SPA 404 while preserving an actual HTTP 404 status."""
    if spa_path.startswith(("api/", ".well-known/", "static/")):
        raise HTTPException(404, "Not found")
    index = _static_dir / "whitepact" / "index.html"
    return HTMLResponse(content=index.read_text(), status_code=404)


@app.head("/{spa_path:path}", include_in_schema=False)
async def whitepact_spa_not_found_head(spa_path: str) -> Response:
    if spa_path.startswith(("api/", ".well-known/", "static/")):
        raise HTTPException(404, "Not found")
    return Response(status_code=404, media_type="text/html")
